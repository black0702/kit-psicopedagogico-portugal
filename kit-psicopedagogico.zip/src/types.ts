export interface SampleItem {
  id: string;
  code: string;
  category: string;
  title: string;
  description: string;
  badge: string;
  objectives: string[];
  features: string[];
}

export interface CategoryItem {
  number: string;
  title: string;
  description: string;
  iconName: string;
  sampleCount: string;
}

export interface BonusItem {
  number: number;
  title: string;
  subtitle: string;
  description: string;
  format: string;
}

export interface FAQItem {
  question: string;
  answer: string;
}

export interface BenefitItem {
  id: number;
  text: string;
}
