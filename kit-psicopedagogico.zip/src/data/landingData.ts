import { SampleItem, CategoryItem, BonusItem, FAQItem, BenefitItem } from '../types';

export const CONFIG = {
  checkoutLink: '[LINK_CHECKOUT]',
  termosLink: '[LINK_TERMOS]',
  privacidadeLink: '[LINK_PRIVACIDADE]',
  contatoLink: '[LINK_CONTATO]',
  supportEmail: 'contato@bibliotecapsico.com.br',
  productName: '+200 Recursos para Avaliação e Intervenção Psicopedagógica',
  offerPrice: '47,00',
  regularPrice: '97,00',
  currency: 'R$',
  guaranteeDays: 7,
};

export const IMMEDIATE_BENEFITS = [
  '+200 recursos organizados',
  'Material digital em PDF',
  'Consulta e impressão',
  'Acesso imediato após a compra',
];

export const SAMPLES_MAIN: SampleItem[] = [
  {
    id: 'sample-01',
    code: 'AMOSTRA 01',
    category: 'Organização e Preparação',
    title: 'Ficha de Rastreio Inicial e Observação Clínica',
    description: 'Instrumento estruturado para levantamento de queixas, histórico de desenvolvimento e mapeamento de rotina escolar.',
    badge: 'Ficha de Triagem',
    objectives: ['Mapeamento de queixas pedagógicas', 'Levantamento de rotinas familiares', 'Organização prévia da sessão'],
    features: ['Campos guiados para preenchimento', 'Indicadores observacionais', 'Pronto para impressão A4'],
  },
  {
    id: 'sample-02',
    code: 'AMOSTRA 02',
    category: 'Atenção e Concentração',
    title: 'Prancha de Rastreio Visual e Foco Sustentado',
    description: 'Atividade com estímulos padronizados para verificação da atenção concentrada, alternada e velocidade de processamento.',
    badge: 'Recurso de Atenção',
    objectives: ['Estímulo do foco contínuo', 'Discriminação de estímulos concorrentes', 'Medição qualitativa do tempo'],
    features: ['Grade visual de alta legibilidade', 'Instruções de aplicação direta', 'Níveis graduados de desafio'],
  },
  {
    id: 'sample-03',
    code: 'AMOSTRA 03',
    category: 'Memória e Sequência',
    title: 'Cartões de Sequenciação Lógica e Temporal',
    description: 'Conjunto de cartões narrativos para trabalhar ordenação temporal, evocação imediata e estruturação de pensamento.',
    badge: 'Cartões Narrativos',
    objectives: ['Compreensão de antes/durante/depois', 'Memória operacional de trabalho', 'Estruturação do raciocínio cronológico'],
    features: ['Ilustrações vetoriais limpas', 'Cartões recortáveis padronizados', 'Versão colorida e preto e branco'],
  },
  {
    id: 'sample-04',
    code: 'AMOSTRA 04',
    category: 'Percepção e Organização Visual',
    title: 'Guia de Pareamento de Formas e Orientação Espacial',
    description: 'Recurso visual focado na coordenação visomotora, discriminação figura-fundo e relações espaciais.',
    badge: 'Percepção Espacial',
    objectives: ['Discriminação figura-fundo', 'Orientação espacial (cima/baixo/lados)', 'Noção topológica fundamental'],
    features: ['Contraste visual equilibrado', 'Grade modular de respostas', 'Excelente para avaliação de apoio'],
  },
  {
    id: 'sample-05',
    code: 'AMOSTRA 05',
    category: 'Raciocínio e Resolução de Problemas',
    title: 'Matriz de Categorização e Dedução Conceitual',
    description: 'Atividades desafiadoras de classificação por atributos múltiplos, analogias e deduções lógicas práticas.',
    badge: 'Raciocínio Lógico',
    objectives: ['Classificação e agrupamento conceitual', 'Flexibilidade cognitiva', 'Identificação de regras implícitas'],
    features: ['Estrutura progressiva', 'Roteiro de intervenção rápida', 'Folha de registro integrada'],
  },
  {
    id: 'sample-06',
    code: 'AMOSTRA 06',
    category: 'Linguagem e Habilidades Acadêmicas',
    title: 'Roteiro Visual de Consciência Fonológica e Rimas',
    description: 'Prancha estruturada para apoio nas etapas de correspondência fonema-grafema, aliterações e segmentação silábica.',
    badge: 'Linguagem e Leitura',
    objectives: ['Segmentação silábica e fonêmica', 'Identificação de sons iniciais e rimas', 'Apoio à leitura inicial'],
    features: ['Ícones com significado direto', 'Sem poluição visual', 'Ideal para atendimentos individuais'],
  },
];

export const CATEGORIES: CategoryItem[] = [
  {
    number: '01',
    title: 'Organização e preparação',
    description: 'Fichas de acolhimento, triagem, organização do ambiente e planejamento da sessão.',
    iconName: 'ClipboardList',
    sampleCount: '28 recursos',
  },
  {
    number: '02',
    title: 'Atenção e concentração',
    description: 'Pranchas de rastreio, cancelamento, labirintos lógicos e estímulos de foco sustentado.',
    iconName: 'Eye',
    sampleCount: '26 recursos',
  },
  {
    number: '03',
    title: 'Memória e sequência',
    description: 'Cartões temporais, jogos de evocação imediata e sequenciamento de rotinas.',
    iconName: 'Sparkles',
    sampleCount: '24 recursos',
  },
  {
    number: '04',
    title: 'Percepção e organização visual',
    description: 'Atividades de figura-fundo, simetria, coordenação visomotora e relações espaciais.',
    iconName: 'Compass',
    sampleCount: '26 recursos',
  },
  {
    number: '05',
    title: 'Raciocínio e resolução de problemas',
    description: 'Matrizes de dedução lógica, analogias, seriação e desafios conceituais práticos.',
    iconName: 'BrainCircuit',
    sampleCount: '25 recursos',
  },
  {
    number: '06',
    title: 'Linguagem e habilidades acadêmicas',
    description: 'Consciência fonológica, pré-requisitos para leitura, escrita e noções numéricas.',
    iconName: 'BookOpen',
    sampleCount: '27 recursos',
  },
  {
    number: '07',
    title: 'Atividades práticas de intervenção',
    description: 'Intervenções lúdicas guiadas para mediação psicopedagógica e superação de barreiras.',
    iconName: 'Target',
    sampleCount: '25 recursos',
  },
  {
    number: '08',
    title: 'Materiais visuais e acompanhamento',
    description: 'Mapas de progresso da sessão, quadros de rotina visual e relatórios de observação.',
    iconName: 'BarChart3',
    sampleCount: '22 recursos',
  },
];

export const SAMPLES_EXPANDED: SampleItem[] = [
  {
    id: 'sample-07',
    code: 'AMOSTRA 07',
    category: 'Organização e Preparação',
    title: 'Checklist de Observação Comportamental em Sessão',
    description: 'Planilha prática para anotação rápida de engajamento, tolerância a frustrações e postura corporal.',
    badge: 'Checklist de Sessão',
    objectives: ['Registro objetivo de reações', 'Acompanhamento longitudinal', 'Síntese pós-atendimento'],
    features: ['Grade de checagem simplificada', 'Espaço para anotações descritivas', 'Formato A4'],
  },
  {
    id: 'sample-08',
    code: 'AMOSTRA 08',
    category: 'Atenção e Concentração',
    title: 'Grade de Cancelamento de Símbolos Alternados',
    description: 'Recurso clássico adaptado com símbolos neutros para verificação de atenção seletiva e omissões.',
    badge: 'Cancelamento Visual',
    objectives: ['Avaliação de omissões e acertos', 'Velocidade de escaneamento', 'Resistência à distração'],
    features: ['Espaçamento regulado', 'Sem sobrecarga cognitiva', 'Instrução clara ao aplicador'],
  },
  {
    id: 'sample-09',
    code: 'AMOSTRA 09',
    category: 'Memória e Sequência',
    title: 'Prancha de Associação Auditivo-Visual Direta',
    description: 'Exercícios visuais com pares conceituais para verificação e treino de memória semântica e imediata.',
    badge: 'Memória Semântica',
    objectives: ['Evocação de pares associados', 'Fixação de instruções verbais', 'Flexibilidade de resposta'],
    features: ['Pares temáticos claros', 'Cartões de reforço inclusos', 'Apoio à mediação'],
  },
  {
    id: 'sample-10',
    code: 'AMOSTRA 10',
    category: 'Percepção Visual',
    title: 'Desafios de Fechamento Visual e Integração',
    description: 'Páginas com partes incompletas de formas e objetos para estimular a capacidade de fechamento gestáltico.',
    badge: 'Fechamento Visual',
    objectives: ['Reconhecimento de padrões', 'Integração perceptiva global', 'Antecipação de imagens'],
    features: ['Linhas nítidas de alto contraste', 'Variação por grau de detalhe', 'Pronto para uso'],
  },
  {
    id: 'sample-11',
    code: 'AMOSTRA 11',
    category: 'Raciocínio Lógico',
    title: 'Labirintos Progressivos de Tomada de Decisão',
    description: 'Labirintos geométricos graduados com caminhos com restrições e regras para planejamento motor e cognitivo.',
    badge: 'Planejamento Cognitivo',
    objectives: ['Inibição de impulso motor', 'Planejamento prévio da rota', 'Resolução de impasses'],
    features: ['3 níveis de complexidade', 'Formato limpo e profissional', 'Fácil de imprimir'],
  },
  {
    id: 'sample-12',
    code: 'AMOSTRA 12',
    category: 'Linguagem',
    title: 'Cartões de Pareamento Sílaba Inicial e Objeto',
    description: 'Material visual manipulativo com cartões recortáveis para segmentação e identificação silábica.',
    badge: 'Consciência Silábica',
    objectives: ['Isolamento da sílaba inicial', 'Análise fonêmica preliminar', 'Ampliação de vocabulário'],
    features: ['Bordas de corte fáceis', 'Organização por famílias sonoras', 'Design contemporâneo'],
  },
  {
    id: 'sample-13',
    code: 'AMOSTRA 13',
    category: 'Intervenção Prática',
    title: 'Roteiro de Autocorreção e Verificação Passo a Passo',
    description: 'Ficha de apoio visual para que o aprendente acompanhe as etapas da sua própria atividade.',
    badge: 'Metacognição',
    objectives: ['Estímulo à autorregulação', 'Revisão antes da entrega', 'Redução da impulsividade'],
    features: ['Ícones intuitivos de checklist', 'Uso contínuo em sessões', 'Material plastificável'],
  },
  {
    id: 'sample-14',
    code: 'AMOSTRA 14',
    category: 'Acompanhamento',
    title: 'Quadro Visual de Linha do Tempo da Sessão',
    description: 'Painel visual de rotina para estruturar o início, desenvolvimento e encerramento do atendimento.',
    badge: 'Rotina de Sessão',
    objectives: ['Previsibilidade para o aprendente', 'Diminuição de ansiedade', 'Gestão do tempo compartilhado'],
    features: ['Slots visuais intercambiáveis', 'Design acolhedor e neutro', 'Instruções para o profissional'],
  },
  {
    id: 'sample-15',
    code: 'AMOSTRA 15',
    category: 'Habilidades Numéricas',
    title: 'Prancha de Estimativa Visual e Correspondência Numérica',
    description: 'Atividade de senso numérico inicial, subitização e contagem com apoio imagético equilibrado.',
    badge: 'Senso Numérico',
    objectives: ['Subitização até 6 elementos', 'Correspondência termo a termo', 'Representação ordinal e cardinal'],
    features: ['Grade limpa sem excessos', 'Cores suaves para não distrair', 'Aplicação simples'],
  },
  {
    id: 'sample-16',
    code: 'AMOSTRA 16',
    category: 'Acompanhamento',
    title: 'Ficha de Devolutiva e Síntese de Observações',
    description: 'Modelo de folha de síntese para estruturar pontos fortes, hipóteses levantadas e próximos passos.',
    badge: 'Síntese de Devolutiva',
    objectives: ['Clareza na comunicação pedagógica', 'Organização de dados coletados', 'Apoio no registro formal'],
    features: ['Blocos organizados por eixos', 'Espaço para recomendações', 'Padrão editorial executivo'],
  },
];

export const PROFESSIONAL_BENEFITS: BenefitItem[] = [
  { id: 1, text: 'Tenha recursos organizados em um único lugar.' },
  { id: 2, text: 'Reduza o tempo procurando materiais.' },
  { id: 3, text: 'Escolha atividades conforme o objetivo trabalhado.' },
  { id: 4, text: 'Consulte os materiais quando precisar.' },
  { id: 5, text: 'Tenha opções para diferentes tipos de atividades.' },
  { id: 6, text: 'Imprima os recursos que fizerem sentido para sua rotina.' },
];

export const PRODUCT_INCLUDED_LIST = [
  '+200 recursos digitais',
  '8 áreas de organização',
  'Materiais visuais',
  'Atividades práticas',
  'Fichas de acompanhamento',
  'Checklists e materiais de apoio',
  'Arquivos em PDF',
  'Organização para facilitar a consulta',
];

export const WHAT_YOU_RECEIVE_BLOCKS = [
  {
    title: 'Biblioteca principal',
    highlight: '+200 recursos',
    description: 'Acervo estruturado com pranchas, fichas e exercícios prontos para utilização pedagógica.',
    iconName: 'Library',
    tag: 'Acervo Completo',
  },
  {
    title: 'Organização por áreas',
    highlight: '8 categorias',
    description: 'Divisão clara por objetivos de intervenção e observação para facilitar a localização imediata.',
    iconName: 'FolderTree',
    tag: 'Estrutura Temática',
  },
  {
    title: 'Materiais de apoio',
    highlight: 'Checklists e fichas',
    description: 'Documentos rápidos para planejamento prévio de sessões e anotações essenciais.',
    iconName: 'CheckSquare',
    tag: 'Apoio Prático',
  },
  {
    title: 'Materiais visuais',
    highlight: 'Cartões e recursos de consulta',
    description: 'Estímulos visuais padronizados com alta legibilidade para mediação em consultório ou escola.',
    iconName: 'LayoutGrid',
    tag: 'Recursos Visuais',
  },
  {
    title: 'Acompanhamento',
    highlight: 'Fichas de registro e organização',
    description: 'Instrumentos organizacionais para registrar a evolução de cada plano de intervenção.',
    iconName: 'ClipboardCheck',
    tag: 'Gestão de Sessão',
  },
];

export const TARGET_AUDIENCE = [
  {
    title: 'Psicopedagogos',
    description: 'Que buscam um repertório prático e visual para dinamizar seus atendimentos clínicos ou institucionais.',
  },
  {
    title: 'Profissionais que realizam atividades de avaliação',
    description: 'Que necessitam de instrumentos de triagem, sondagem e observação de habilidades essenciais.',
  },
  {
    title: 'Profissionais que trabalham com intervenção',
    description: 'Que desejam recursos estruturados para estimular atenção, raciocínio, memória e linguagem.',
  },
  {
    title: 'Profissionais que buscam organizar melhor seus materiais',
    description: 'Que querem economizar horas de busca dispersa na internet e ter tudo reunido em um catálogo claro.',
  },
];

export const BONUSES: BonusItem[] = [
  {
    number: 1,
    title: 'Checklists de Preparação do Atendimento',
    subtitle: 'BÔNUS EXCLUSIVO 01',
    description: 'Modelos de checklist para organizar materiais, definir metas do dia e estruturar a sessão antes da chegada do aprendente.',
    format: 'PDF pronto para impressão',
  },
  {
    number: 2,
    title: 'Fichas de Registro e Acompanhamento',
    subtitle: 'BÔNUS EXCLUSIVO 02',
    description: 'Fichas objetivas para documentar respostas, manifestações e observações qualitativas durante as sessões.',
    format: 'PDF pronto para impressão',
  },
  {
    number: 3,
    title: 'Guia de Organização dos Recursos',
    subtitle: 'BÔNUS EXCLUSIVO 03',
    description: 'Orientações práticas de como categorizar, catalogar em pastas e organizar a rotina de impressão dos materiais.',
    format: 'Manual prático digital',
  },
  {
    number: 4,
    title: 'Pack de Atividades Rápidas',
    subtitle: 'BÔNUS EXCLUSIVO 04',
    description: 'Seleção de recursos de curta duração ideais para aquecimento inicial da sessão ou transições entre atividades.',
    format: 'PDF em alta resolução',
  },
  {
    number: 5,
    title: 'Pôsteres de Consulta Visual',
    subtitle: 'BÔNUS EXCLUSIVO 05',
    description: 'Pranchas informativas sintéticas para manter fixadas na mesa ou no consultório para consulta imediata.',
    format: 'PDF em alta resolução',
  },
];

export const HOW_IT_WORKS_STEPS = [
  {
    step: '01',
    title: 'Finalize sua compra',
    description: 'Processo seguro em ambiente protegido com confirmação rápida.',
  },
  {
    step: '02',
    title: 'Receba as instruções de acesso',
    description: 'Orientações de acesso enviadas diretamente para seu e-mail cadastrado.',
  },
  {
    step: '03',
    title: 'Acesse a biblioteca digital',
    description: 'Visualize todos os módulos e categorias organizadas na plataforma.',
  },
  {
    step: '04',
    title: 'Escolha os recursos que deseja consultar',
    description: 'Navegue pelas 8 áreas e selecione o material ideal para cada objetivo.',
  },
  {
    step: '05',
    title: 'Utilize ou imprima os materiais conforme sua rotina',
    description: 'Baixe em PDF de alta qualidade e imprima quantas vezes forem necessárias.',
  },
];

export const FAQ_LIST: FAQItem[] = [
  {
    question: 'O que está incluído na biblioteca?',
    answer: 'A biblioteca inclui mais de 200 recursos visuais em formato PDF organizados em 8 grandes áreas temáticas (como atenção, memória, raciocínio, linguagem e organização), além de 5 bônus com checklists, fichas de acompanhamento e guias práticos.',
  },
  {
    question: 'Quantos recursos vou receber?',
    answer: 'Você recebe acesso a mais de 200 recursos estruturados, além de todos os materiais complementares inclusos nos 5 bônus da biblioteca.',
  },
  {
    question: 'Como recebo o material?',
    answer: 'Após a confirmação do pagamento, você receberá por e-mail as instruções e dados para acessar a plataforma digital onde todos os arquivos em PDF estão disponíveis para consulta e download.',
  },
  {
    question: 'Os arquivos são digitais?',
    answer: 'Sim! Trata-se de um produto 100% digital em formato PDF de alta resolução, pronto para download imediato em seu computador, tablet ou celular.',
  },
  {
    question: 'Posso imprimir os materiais?',
    answer: 'Sim! Todos os materiais foram diagramados no padrão A4 com excelente legibilidade e margens adequadas, facilitando a impressão doméstica ou em gráfica rápida quantas vezes desejar.',
  },
  {
    question: 'Para quem o material é indicado?',
    answer: 'O material foi desenvolvido especialmente para psicopedagogos, pedagogos, mediadores e profissionais que realizam atendimentos, triagens ou intervenções psicopedagógicas.',
  },
  {
    question: 'Posso utilizar os recursos em diferentes atendimentos?',
    answer: 'Sim. Os recursos são versáteis e permitem a aplicação individualizada conforme os objetivos planejados para cada aprendente em sua rotina.',
  },
  {
    question: 'Os materiais substituem uma avaliação profissional?',
    answer: 'Não. Os materiais são recursos de apoio e não substituem avaliação, diagnóstico, orientação ou conduta profissional. Eles funcionam como instrumentos práticos para enriquecer a rotina do profissional capacitado.',
  },
  {
    question: 'Como funciona a garantia?',
    answer: 'Você conta com 7 dias de garantia incondicional. Se após acessar os materiais você entender que a biblioteca não atende às suas necessidades, poderá solicitar o reembolso integral dentro desse prazo.',
  },
];
