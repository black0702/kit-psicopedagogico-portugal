import React, { useState } from 'react';
import { ClonedPage } from './components/ClonedPage';
import { Download, X, Loader2 } from 'lucide-react';

export function App() {
  const [bannerVisible, setBannerVisible] = useState(true);
  const [downloading, setDownloading] = useState(false);

  const handleDownload = async () => {
    try {
      setDownloading(true);
      const res = await fetch('/projeto-kit-psicopedagogico.zip');
      if (!res.ok) throw new Error('Erro ao buscar o arquivo');
      const blob = await res.blob();
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.style.display = 'none';
      a.href = url;
      a.download = 'projeto-kit-psicopedagogico.zip';
      document.body.appendChild(a);
      a.click();
      setTimeout(() => {
        window.URL.revokeObjectURL(url);
        document.body.removeChild(a);
        setDownloading(false);
      }, 1000);
    } catch (err) {
      console.error(err);
      window.location.href = '/projeto-kit-psicopedagogico.zip';
      setDownloading(false);
    }
  };

  return (
    <div className="w-full min-h-screen relative">
      {/* Barra de Download Superior com Blob trigger para evitar bloqueios de iframe */}
      {bannerVisible && (
        <aside 
          aria-label="Download do Projeto"
          className="sticky top-0 z-50 bg-[#123C4A] text-white px-4 py-3 shadow-xl border-b border-[#25A69A]/30 flex flex-wrap items-center justify-between gap-3 text-xs sm:text-sm"
        >
          <div className="flex items-center gap-2">
            <span className="w-2.5 h-2.5 rounded-full bg-[#25A69A] animate-ping" />
            <span className="font-semibold text-white">
              Projeto Completo para a Vercel (.ZIP com todas as 44 imagens e código)
            </span>
          </div>

          <div className="flex items-center gap-2.5 ml-auto">
            <button
              onClick={handleDownload}
              disabled={downloading}
              className="inline-flex items-center gap-1.5 px-5 py-2 rounded-full bg-[#25A69A] hover:bg-[#1E8E84] text-white font-bold text-xs uppercase tracking-wider shadow-md hover:shadow-lg transition-transform active:scale-95 cursor-pointer disabled:opacity-50"
            >
              {downloading ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin" />
                  <span>A descarregar...</span>
                </>
              ) : (
                <>
                  <Download className="w-4 h-4" />
                  <span>CLIQUE AQUI PARA BAIXAR O ZIP</span>
                </>
              )}
            </button>

            <button
              onClick={() => setBannerVisible(false)}
              className="w-7 h-7 rounded-full bg-white/10 hover:bg-white/20 text-white flex items-center justify-center transition-colors cursor-pointer"
              title="Fechar aviso"
              aria-label="Fechar aviso"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </aside>
      )}

      {/* Página Clonada Completa */}
      <ClonedPage />
    </div>
  );
}

export default App;
