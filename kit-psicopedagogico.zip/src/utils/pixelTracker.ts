// Utilitário para rastreio ético de Meta Pixel sem quebrar se não estiver configurado
declare global {
  interface Window {
    fbq?: (...args: any[]) => void;
  }
}

export const trackPixelEvent = (
  eventName: 'ViewContent' | 'InitiateCheckout' | 'Lead' | 'Purchase',
  params?: Record<string, any>
) => {
  try {
    if (typeof window !== 'undefined' && typeof window.fbq === 'function') {
      window.fbq('track', eventName, params);
      console.log(`[Meta Pixel Event]: ${eventName}`, params);
    }
  } catch (err) {
    console.debug('Pixel track error:', err);
  }
};

export const getUtmParameters = (): Record<string, string> => {
  if (typeof window === 'undefined') return {};
  const searchParams = new URLSearchParams(window.location.search);
  const utms: Record<string, string> = {};
  ['utm_source', 'utm_medium', 'utm_campaign', 'utm_term', 'utm_content'].forEach((key) => {
    const val = searchParams.get(key);
    if (val) utms[key] = val;
  });
  return utms;
};

export const buildCheckoutUrlWithUtms = (baseUrl: string): string => {
  if (!baseUrl) return '#';
  try {
    const url = new URL(baseUrl);
    const utms = getUtmParameters();
    Object.entries(utms).forEach(([key, value]) => {
      url.searchParams.set(key, value);
    });
    return url.toString();
  } catch {
    return baseUrl;
  }
};
