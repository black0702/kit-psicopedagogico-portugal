export interface PlanPricing {
  id: string;
  name: string;
  badge?: string;
  priceFormatted: string;
  priceValue: number;
  currency: string;
  paymentType: string;
  checkoutUrl: string;
  highlighted: boolean;
  description: string;
  warningNote?: string;
  includedFeatures: string[];
  excludedFeatures?: string[];
  ctaText: string;
}

export const CHECKOUT_CONFIG = {
  currency: 'EUR',
  currencySymbol: '€',
  country: 'PT',
  countryName: 'Portugal',
  defaultPaymentMethods: ['Cartão de Crédito/Débito', 'MB WAY (via checkout)', 'Multibanco (suporte conforme gateway)'],
  supportEmail: 'contacto@kitpsicopedagogico.com',
  companyName: 'Recursos Psicopedagógicos Digitais',
  nifOrTaxNotice: 'Venda de bens digitais para a União Europeia sujeita a IVA conforme a regulamentação em vigor.',
  metaPixelId: '', // Configurável pelo proprietário do anúncio
  plans: {
    basico: {
      id: 'plano-basico',
      name: 'Plano Básico',
      badge: 'Essencial',
      priceFormatted: '4,90 €',
      priceValue: 4.90,
      currency: 'EUR',
      paymentType: 'pagamento único',
      checkoutUrl: 'https://pay.cakto.com.br/37xcsc9', // Link Cakto existente ou atualizável
      highlighted: false,
      description: 'Apostila Completa com mais de 50 testes e protocolos de apoio à aprendizagem.',
      warningNote: 'Atenção: versão sem o Guia Prático, sem o Kit Visual de Hábitos e sem os 3 Bónus de Autismo e Inclusão.',
      includedFeatures: [
        'Apostila completa em formato PDF',
        'Mais de 50 testes e fichas práticas',
        'Protocolos estruturados de observação',
        'Conteúdo teórico e orientações de apoio',
        'Ficheiros prontos a imprimir',
      ],
      excludedFeatures: [
        'Guia Prático Passo a Passo',
        'Kit Visual de Hábitos e Regulação',
        'Drive Profissional com documentos editáveis em Word',
        '1.500 Atividades Infantis complementares',
        '3 E-books sobre Autismo e Inclusão Escolar',
      ],
      ctaText: 'Quero o Plano Básico (€4,90)',
    } as PlanPricing,
    combo: {
      id: 'combo-profissional',
      name: 'Combo Profissional Completo',
      badge: 'Mais Recomendado',
      priceFormatted: '9,90 €',
      priceValue: 9.90,
      currency: 'EUR',
      paymentType: 'pagamento único',
      checkoutUrl: 'https://pay.cakto.com.br/9ciz86f', // Link Cakto do Combo
      highlighted: true,
      description: 'O acervo digital completo com todos os cadernos, testes, modelos editáveis e bónus exclusivos.',
      includedFeatures: [
        'Apostila Completa com +50 testes em PDF',
        'Guia Prático: da queixa inicial ao plano de apoio',
        'Kit Visual de Hábitos, Rotina e Autorregulação',
        'Bónus 1: Drive Profissional com modelos 100% editáveis em Word',
        'Bónus 2: 1.500 Atividades Infantis para apoio pedagógico',
        'Bónus 3: 3 E-books completos sobre Autismo e Regulação',
        'Planeamento anual e grelhas de evolução do aluno',
        'Acesso imediato e vitalício aos ficheiros descarregados',
        'Garantia total de 7 dias sem qualquer risco',
      ],
      ctaText: 'Quero o Kit Completo (€9,90)',
    } as PlanPricing,
    ofertaEspecial: {
      id: 'oferta-especial',
      name: 'Kit Completo (Oferta Especial)',
      priceFormatted: '9,90 €',
      checkoutUrl: 'https://pay.cakto.com.br/wjmgsqr',
    }
  }
};
