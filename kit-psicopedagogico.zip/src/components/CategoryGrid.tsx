import React from 'react';
import { 
  ClipboardList, 
  Eye, 
  Sparkles, 
  Compass, 
  BrainCircuit, 
  BookOpen, 
  Target, 
  BarChart3 
} from 'lucide-react';
import { CATEGORIES } from '../data/landingData';

// Map icon names to components
const iconMap: Record<string, React.FC<{ className?: string }>> = {
  ClipboardList,
  Eye,
  Sparkles,
  Compass,
  BrainCircuit,
  BookOpen,
  Target,
  BarChart3,
};

export const CategoryGrid: React.FC = () => {
  return (
    <section className="py-14 sm:py-20 px-4 bg-[#F1EFF9] border-y border-[#E9E5F8]">
      <div className="max-w-6xl mx-auto">
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-10 sm:mb-14">
          <span className="text-xs font-bold text-[#6657C8] uppercase tracking-wider bg-white px-3 py-1 rounded-full border border-[#E9E5F8] mb-3 inline-block">
            ESTRUTURA COMPLETA
          </span>
          <h2 className="text-2xl sm:text-3xl md:text-4xl font-extrabold text-[#30264D] mb-3 font-display">
            +200 recursos organizados para facilitar sua consulta
          </h2>
          <p className="text-sm sm:text-base text-slate-600 leading-relaxed">
            Encontre materiais por objetivo e escolha com mais facilidade o que utilizar em cada momento.
          </p>
        </div>

        {/* 8 Cards Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 sm:gap-6">
          {CATEGORIES.map((cat) => {
            const IconComponent = iconMap[cat.iconName] || ClipboardList;
            return (
              <div
                key={cat.number}
                className="bg-white rounded-2xl p-5 border border-[#E9E5F8] shadow-xs hover:shadow-md hover:border-[#6657C8]/40 transition-all duration-200 flex flex-col justify-between"
              >
                <div>
                  {/* Top Bar with Number and Icon */}
                  <div className="flex items-center justify-between mb-4">
                    <span className="text-xl font-extrabold text-[#6657C8] font-display">
                      {cat.number}
                    </span>
                    <div className="w-10 h-10 rounded-xl bg-[#F7F5FC] text-[#6657C8] border border-[#E9E5F8] flex items-center justify-center">
                      <IconComponent className="w-5 h-5" />
                    </div>
                  </div>

                  {/* Title */}
                  <h3 className="text-base font-bold text-[#30264D] mb-2 leading-snug">
                    {cat.title}
                  </h3>

                  {/* Description */}
                  <p className="text-xs text-slate-600 leading-relaxed">
                    {cat.description}
                  </p>
                </div>

                {/* Bottom Tag */}
                <div className="mt-4 pt-3 border-t border-slate-100 flex items-center justify-between text-[11px] text-slate-500">
                  <span className="text-[#36B77A] font-semibold">Organizado em PDF</span>
                  <span className="text-slate-400 font-mono text-[10px]">{cat.sampleCount}</span>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
};
