import React from 'react';
import { Sparkles, CheckCircle2, ArrowRight } from 'lucide-react';

interface InteractiveKitShowcaseProps {
  onCtaClick: () => void;
}

export const InteractiveKitShowcase: React.FC<InteractiveKitShowcaseProps> = ({ onCtaClick }) => {
  return (
    <section className="py-14 sm:py-20 px-4 bg-[#F1EFF9] border-y border-[#E9E5F8]">
      <div className="max-w-6xl mx-auto">
        
        {/* Bloco 2 Colunas */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 sm:gap-12 items-center">
          
          {/* Mockup do Kit Visual à Esquerda */}
          <div className="lg:col-span-5 flex justify-center">
            <div className="relative w-full max-w-sm">
              <div className="absolute inset-0 bg-[#36B77A]/15 rounded-3xl blur-xl transform rotate-2" />
              <div className="relative bg-white p-3 rounded-3xl border border-[#E9E5F8] shadow-xl">
                <img
                  src="/src/assets/images/mockup_kit_ptbr_1790625433365.jpg"
                  alt="Kit Visual de Hábitos, Rotina e Regulação"
                  referrerPolicy="no-referrer"
                  className="w-full h-auto rounded-2xl object-cover"
                />
                <div className="p-3 bg-[#F7F5FC] rounded-xl mt-2 flex items-center justify-between text-xs text-[#30264D] font-medium">
                  <span className="flex items-center gap-1.5 font-bold text-[#36B77A]">
                    <Sparkles className="w-3.5 h-3.5" />
                    Kit de Regulação Incluso
                  </span>
                  <span className="text-[10px] bg-[#6657C8]/15 text-[#6657C8] px-2 py-0.5 rounded-full font-bold">
                    Pronto para Plastificar
                  </span>
                </div>
              </div>
            </div>
          </div>

          {/* Texto Explicativo à Direita */}
          <div className="lg:col-span-7 space-y-5 text-left">
            <div>
              <span className="text-xs font-bold text-[#36B77A] uppercase tracking-wider bg-white px-3.5 py-1.5 rounded-full border border-[#E9E5F8] inline-block mb-3">
                NOVO RECURSO COMPLEMENTAR
              </span>
              <h2 className="text-2xl sm:text-3xl md:text-4xl font-extrabold text-[#30264D] font-display leading-tight">
                Além do Guia, você também recebe um Kit Visual pronto para usar
              </h2>
              <p className="text-xs sm:text-sm font-semibold text-[#6657C8] mt-1">
                Kit Visual de Rotina, Hábitos, Comunicação e Autorregulação
              </p>
            </div>

            <p className="text-sm sm:text-base text-slate-600 leading-relaxed">
              Um conjunto de recursos visuais criado para transformar orientações abstratas em ferramentas práticas que podem ser consultadas e utilizadas no dia a dia em sala, consultório ou em casa.
            </p>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-1">
              {[
                'Rotina visual e previsibilidade',
                'Quadro de necessidades e escolhas',
                'Cantinho da calma e respiração',
                'Registro de observação comportamental',
                'Comunicação funcional direta',
                'Emoções e autorregulação guiada',
                'Transições sem estresse ou atrito',
                'Mapas e orientações para família',
              ].map((text, i) => (
                <div key={i} className="flex items-center gap-2 text-xs sm:text-sm text-[#30264D]">
                  <CheckCircle2 className="w-4 h-4 text-[#36B77A] shrink-0" />
                  <span>{text}</span>
                </div>
              ))}
            </div>

            <div className="bg-white p-3.5 rounded-xl border border-[#E9E5F8] text-xs text-slate-600 flex items-center justify-between">
              <span>Material visual • Aplicação prática • Consulta rápida</span>
              <span className="text-[#36B77A] font-bold text-[11px]">100% Digital em PDF</span>
            </div>

            <div>
              <button
                onClick={onCtaClick}
                className="w-full sm:w-auto px-7 py-3.5 bg-[#36B77A] hover:bg-[#2FA56D] text-white font-bold text-sm rounded-xl shadow-md transition-all cursor-pointer flex items-center justify-center gap-2"
              >
                <span>QUERO ACESSAR TODO O MATERIAL</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          </div>

        </div>

      </div>
    </section>
  );
};
