import React from 'react';
import { ShieldCheck } from 'lucide-react';
import { CONFIG } from '../data/landingData';

export const Guarantee: React.FC = () => {
  return (
    <section className="py-14 sm:py-18 px-4 bg-[#F1EFF9] border-y border-[#E9E5F8]">
      <div className="max-w-4xl mx-auto">
        <div className="bg-white rounded-3xl p-6 sm:p-10 border border-[#E9E5F8] shadow-sm flex flex-col md:flex-row items-center gap-6 sm:gap-10">
          
          {/* Selo Visual: 7 DIAS DE GARANTIA */}
          <div className="shrink-0 text-center">
            <div className="w-24 h-24 sm:w-28 sm:h-28 rounded-3xl bg-gradient-to-br from-[#6657C8] to-[#30264D] text-white p-3 shadow-md flex flex-col items-center justify-center border-2 border-[#E9E5F8]">
              <ShieldCheck className="w-7 h-7 sm:w-8 sm:h-8 text-[#36B77A] mb-1" />
              <div className="text-xl sm:text-2xl font-black font-display leading-none">
                7 DIAS
              </div>
              <div className="text-[9px] font-bold uppercase tracking-wider text-slate-200 mt-1">
                DE GARANTIA
              </div>
            </div>
          </div>

          {/* Copy */}
          <div className="text-center md:text-left space-y-2">
            <span className="text-[11px] font-bold uppercase tracking-wider text-[#36B77A] bg-[#36B77A]/10 px-2.5 py-0.5 rounded-full inline-block">
              GARANTIA INCONDICIONAL
            </span>
            <h2 className="text-xl sm:text-2xl md:text-3xl font-extrabold text-[#30264D] font-display">
              Você tem 7 dias para conhecer o material
            </h2>
            <p className="text-xs sm:text-sm text-slate-600 leading-relaxed max-w-xl">
              Você pode acessar e conhecer o material dentro do prazo da garantia. Se entender que ele não é adequado para sua necessidade, poderá solicitar o reembolso dentro dos 7 dias.
            </p>
          </div>

        </div>
      </div>
    </section>
  );
};
