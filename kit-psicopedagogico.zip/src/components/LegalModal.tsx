import React from 'react';
import { X, ShieldCheck, Mail, FileText } from 'lucide-react';
import { CONFIG } from '../data/landingData';

interface LegalModalProps {
  type: 'termos' | 'privacidade' | 'contato' | null;
  onClose: () => void;
}

export const LegalModal: React.FC<LegalModalProps> = ({ type, onClose }) => {
  if (!type) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-[#30264D]/60 backdrop-blur-xs animate-in fade-in duration-200">
      <div 
        className="bg-white w-full max-w-xl rounded-2xl md:rounded-3xl border border-[#E9E5F8] shadow-2xl overflow-hidden flex flex-col max-h-[85vh]"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="flex items-center justify-between p-4 sm:p-5 border-b border-slate-100 bg-[#F7F5FC]">
          <div className="flex items-center gap-2">
            {type === 'contato' ? (
              <Mail className="w-5 h-5 text-[#6657C8]" />
            ) : type === 'privacidade' ? (
              <ShieldCheck className="w-5 h-5 text-[#36B77A]" />
            ) : (
              <FileText className="w-5 h-5 text-[#6657C8]" />
            )}
            <h3 className="font-bold text-[#30264D] text-base">
              {type === 'termos' && 'Termos de Uso'}
              {type === 'privacidade' && 'Política de Privacidade'}
              {type === 'contato' && 'Canal de Atendimento e Suporte'}
            </h3>
          </div>
          <button 
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-white border border-slate-200 text-slate-500 hover:text-slate-900 flex items-center justify-center transition-colors"
            aria-label="Fechar"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Content */}
        <div className="p-5 sm:p-6 overflow-y-auto text-xs sm:text-sm text-slate-600 space-y-4 leading-relaxed">
          {type === 'termos' && (
            <>
              <p>
                <strong>1. Natureza do Material:</strong> O produto <em>{CONFIG.productName}</em> é uma biblioteca visual de recursos de apoio pedagógico e psicopedagógico em formato digital (PDF).
              </p>
              <p>
                <strong>2. Não Substituição:</strong> Os materiais têm caráter instrumental e de apoio prático à organização e mediação. Eles <strong>não substituem</strong> avaliação clínica individualizada, diagnóstico formal, acompanhamento multiprofissional ou orientação médica/psicológica.
              </p>
              <p>
                <strong>3. Uso Permitido:</strong> A aquisição concede licença de uso pessoal e profissional para utilização com seus aprendentes em sessões de atendimento e para impressão das fichas em sua rotina. É vedada a revenda, rateio ou distribuição pública dos arquivos.
              </p>
              <p>
                <strong>4. Garantia:</strong> Garantia legal e incondicional de 7 dias a partir da data de confirmação do pagamento.
              </p>
            </>
          )}

          {type === 'privacidade' && (
            <>
              <p>
                <strong>1. Privacidade de Dados:</strong> Respeitamos a sua privacidade. Os dados fornecidos no momento da compra (como nome e e-mail) são utilizados estritamente para envio do acesso aos arquivos digitais e comunicações pertinentes à biblioteca.
              </p>
              <p>
                <strong>2. Segurança:</strong> O processamento financeiro é executado por plataformas seguras de pagamento com certificação SSL. Dados de cartão de crédito não são armazenados em nossos servidores.
              </p>
              <p>
                <strong>3. Seus Direitos:</strong> Você pode a qualquer momento solicitar a atualização ou exclusão de seus dados de nossa base de comunicados através do canal de suporte.
              </p>
            </>
          )}

          {type === 'contato' && (
            <div className="space-y-4">
              <p>
                Dúvidas sobre o conteúdo, acesso aos arquivos ou solicitação de suporte? Estamos à disposição para ajudar.
              </p>
              <div className="bg-[#F7F5FC] p-4 rounded-xl border border-[#E9E5F8] space-y-2">
                <div className="text-xs font-semibold text-[#6657C8] uppercase tracking-wider">
                  E-mail Oficial de Atendimento:
                </div>
                <div className="text-base font-bold text-[#30264D] select-all">
                  {CONFIG.supportEmail}
                </div>
                <div className="text-xs text-slate-500 pt-1">
                  Atendimento de segunda a sexta-feira, das 09h às 18h.
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="p-4 border-t border-slate-100 bg-[#F7F5FC] flex justify-end">
          <button
            onClick={onClose}
            className="px-5 py-2 text-xs font-semibold text-slate-700 bg-white border border-slate-200 rounded-xl hover:bg-slate-50 transition-colors"
          >
            Entendido
          </button>
        </div>
      </div>
    </div>
  );
};
