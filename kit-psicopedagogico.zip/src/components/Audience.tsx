import React from 'react';
import { CheckCircle2, AlertCircle } from 'lucide-react';
import { TARGET_AUDIENCE } from '../data/landingData';

export const Audience: React.FC = () => {
  return (
    <section className="py-14 sm:py-20 px-4 bg-[#F1EFF9] border-y border-[#E9E5F8]">
      <div className="max-w-5xl mx-auto">
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-10 sm:mb-14">
          <span className="text-xs font-bold text-[#6657C8] uppercase tracking-wider bg-white px-3 py-1 rounded-full border border-[#E9E5F8] mb-3 inline-block">
            PÚBLICO-ALVO
          </span>
          <h2 className="text-2xl sm:text-3xl md:text-4xl font-extrabold text-[#30264D] mb-3 font-display">
            Para quem este material foi pensado?
          </h2>
          <p className="text-sm sm:text-base text-slate-600 leading-relaxed">
            Feito para profissionais que desejam aliar qualidade técnica, organização e praticidade.
          </p>
        </div>

        {/* 4 Cards */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 sm:gap-6 mb-8">
          {TARGET_AUDIENCE.map((item, index) => (
            <div
              key={index}
              className="bg-white rounded-2xl p-5 border border-[#E9E5F8] shadow-xs hover:shadow-md transition-all duration-200 flex items-start gap-4"
            >
              <div className="w-8 h-8 rounded-full bg-[#36B77A]/15 text-[#36B77A] flex items-center justify-center shrink-0 mt-0.5">
                <CheckCircle2 className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-base font-bold text-[#30264D] mb-1.5 leading-snug">
                  {item.title}
                </h3>
                <p className="text-xs sm:text-sm text-slate-600 leading-relaxed">
                  {item.description}
                </p>
              </div>
            </div>
          ))}
        </div>

        {/* Disclaimer Box */}
        <div className="bg-white/80 rounded-2xl p-4 sm:p-5 border border-[#E9E5F8] text-center max-w-2xl mx-auto flex items-center justify-center gap-2.5 text-xs text-slate-600">
          <AlertCircle className="w-4 h-4 text-[#6657C8] shrink-0" />
          <span>
            <strong>Observação importante:</strong> O material é um recurso de apoio e não substitui avaliação, diagnóstico ou orientação profissional.
          </span>
        </div>
      </div>
    </section>
  );
};
