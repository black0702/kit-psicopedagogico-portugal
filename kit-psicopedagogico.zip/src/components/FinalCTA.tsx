import React from 'react';
import { Sparkles, ShieldCheck } from 'lucide-react';

interface FinalCTAProps {
  onCtaClick: () => void;
}

export const FinalCTA: React.FC<FinalCTAProps> = ({ onCtaClick }) => {
  return (
    <section className="py-16 sm:py-24 px-4 bg-[#F1EFF9] border-t border-[#E9E5F8] text-center">
      <div className="max-w-3xl mx-auto">
        <div className="inline-flex items-center gap-1.5 bg-white text-[#6657C8] text-xs font-bold px-3.5 py-1.5 rounded-full uppercase tracking-wider mb-4 border border-[#E9E5F8]">
          <Sparkles className="w-3.5 h-3.5 text-[#36B77A]" />
          ACESSO COMPLETO
        </div>

        <h2 className="text-2xl sm:text-3xl md:text-4xl font-extrabold text-[#30264D] mb-4 font-display leading-tight text-balance">
          Organize seus recursos psicopedagógicos em um só lugar
        </h2>

        <p className="text-sm sm:text-base text-slate-600 mb-8 max-w-xl mx-auto leading-relaxed text-balance">
          Tenha uma biblioteca visual com +200 recursos para consultar e utilizar conforme sua rotina.
        </p>

        <div className="mb-6">
          <button
            onClick={onCtaClick}
            className="w-full sm:w-auto px-10 py-4 text-base sm:text-lg font-bold text-white bg-[#6657C8] hover:bg-[#5545B3] rounded-2xl shadow-xl hover:shadow-2xl hover:-translate-y-0.5 active:translate-y-0 transition-all duration-200 cursor-pointer"
          >
            QUERO ACESSAR OS +200 RECURSOS
          </button>
        </div>

        <div className="text-xs text-slate-500 font-medium flex items-center justify-center flex-wrap gap-2">
          <span>Pagamento único</span>
          <span>•</span>
          <span>Acesso digital</span>
          <span>•</span>
          <span className="flex items-center gap-1">
            <ShieldCheck className="w-3.5 h-3.5 text-[#36B77A]" />
            7 dias de garantia
          </span>
        </div>
      </div>
    </section>
  );
};
