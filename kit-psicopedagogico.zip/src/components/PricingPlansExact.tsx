import React, { useState } from 'react';
import { Sparkles, CheckCircle2, ShieldCheck, Lock, ArrowRight } from 'lucide-react';
import { CONFIG } from '../data/landingData';

interface PricingPlansExactProps {
  onSelectPlan?: (planName: string, price: string) => void;
  onOpenCheckout?: () => void;
}

export const PricingPlansExact: React.FC<PricingPlansExactProps> = ({
  onSelectPlan,
  onOpenCheckout,
}) => {
  return (
    <section id="oferta" className="py-16 sm:py-24 px-4 bg-gradient-to-b from-[#F7F5FC] to-white">
      <div className="max-w-4xl mx-auto text-center">
        <h2 className="text-3xl sm:text-4xl font-extrabold text-[#30264D] font-display mb-10 sm:mb-14">
          Escolha seu <span className="text-[#6657C8]">acesso</span>
        </h2>

        {/* 2 Planos lado a lado idênticos à referência */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 sm:gap-8 items-stretch text-left">
          
          {/* Card 1: Apostila Completa */}
          <div className="bg-white rounded-3xl p-6 sm:p-8 border border-slate-200 shadow-lg flex flex-col justify-between hover:shadow-xl transition-shadow">
            <div>
              <div className="text-center pb-4 border-b border-slate-100">
                <h3 className="text-lg font-bold text-[#30264D]">
                  Apostila Completa
                </h3>
                <span className="text-xs text-slate-400">Avaliação Psicopedagógica</span>
                <div className="mt-4">
                  <div className="text-3xl sm:text-4xl font-extrabold text-[#30264D]">
                    <span className="text-lg font-semibold mr-1">R$</span>10<span className="text-base font-normal">,00</span>
                  </div>
                  <span className="text-[11px] text-slate-400">Pagamento único</span>
                </div>
              </div>

              {/* Lista de Entregáveis */}
              <div className="py-5 space-y-3 text-xs text-slate-700">
                {[
                  'Apostila completa em PDF',
                  'Mais de 50 testes psicopedagógicos',
                  'Protocolos de avaliação',
                  'Conteúdo teórico e prático',
                ].map((item, i) => (
                  <div key={i} className="flex items-center gap-2">
                    <span className="w-1.5 h-1.5 rounded-full bg-[#36B77A]" />
                    <span>{item}</span>
                  </div>
                ))}
              </div>
            </div>

            <div>
              <button
                onClick={onOpenCheckout}
                className="w-full py-3.5 bg-[#36B77A] hover:bg-[#2FA56D] text-white font-bold text-xs uppercase tracking-wider rounded-xl transition-all cursor-pointer shadow-sm text-center block"
              >
                QUERO APENAS A APOSTILA
              </button>

              <div className="mt-3 flex items-center justify-center gap-3 text-[10px] text-slate-400">
                <span className="flex items-center gap-1">
                  <Lock className="w-3 h-3" /> Compra Segura
                </span>
                <span>•</span>
                <span>Garantia 7 dias</span>
                <span>•</span>
                <span>Acesso Imediato</span>
              </div>
            </div>
          </div>

          {/* Card 2: Combo Profissional (MAIS VENDIDO) */}
          <div className="bg-white rounded-3xl p-6 sm:p-8 border-2 border-[#6657C8] shadow-2xl relative flex flex-col justify-between">
            {/* Tag Mais Vendido */}
            <div className="absolute -top-3 left-1/2 -translate-x-1/2 bg-[#6657C8] text-white text-[11px] font-bold py-1 px-4 rounded-full uppercase tracking-wider shadow-sm flex items-center gap-1">
              <Sparkles className="w-3 h-3 text-yellow-300" />
              MAIS VENDIDO
            </div>

            <div>
              <div className="text-center pb-4 border-b border-slate-100">
                <h3 className="text-xl font-extrabold text-[#30264D]">
                  Combo Profissional Psicopedagógico
                </h3>
                <span className="text-xs text-[#6657C8] font-semibold">Tudo que você precisa em um só lugar</span>
                <div className="mt-4">
                  <div className="text-4xl sm:text-5xl font-extrabold text-[#6657C8]">
                    <span className="text-lg font-semibold mr-1">R$</span>27<span className="text-lg font-normal">,90</span>
                  </div>
                  <span className="text-[11px] text-slate-400">Pagamento único</span>
                </div>
              </div>

              {/* Lista Completa com Destaques */}
              <div className="py-5 space-y-2.5 text-xs text-slate-700">
                {[
                  'Apostila Completa de Avaliação e Intervenção Psicopedagógica',
                  'NOVO: Guia Prático 2026 - 30+ páginas com mapas, fluxos e checklists',
                  'NOVO: Kit Visual de Hábitos, Comunicação e Regulação',
                  '1500 Atividades Infantis em PDF',
                  '20 Jogos Educativos',
                  '3 Super Bônus Exclusivos sobre Autismo',
                ].map((item, i) => (
                  <div key={i} className="flex items-start gap-2">
                    <span className="w-1.5 h-1.5 rounded-full bg-[#6657C8] mt-1.5 shrink-0" />
                    <span className={i < 3 ? 'font-semibold text-[#30264D]' : ''}>{item}</span>
                  </div>
                ))}

                {/* Bloco Destaque Drive */}
                <div className="mt-3 p-3 bg-[#F1EFF9] rounded-xl border border-[#E9E5F8] text-[11px] space-y-1 text-slate-600">
                  <span className="font-bold text-[#6657C8] block">
                    ✓ Sistema Completo de Aprendizagem — Drive Profissional:
                  </span>
                  <div className="pl-2 space-y-0.5 text-[10px]">
                    <div>• Triagem Clínica: Dislexia, Disgrafia, Discalculia, TDAH</div>
                    <div>• Checklists, escalas e protocolos de rastreio</div>
                    <div>• Fichas de avaliação psicomotora e escalas de leitura</div>
                    <div>• Relatórios, anamnese e documentos editáveis (Word)</div>
                    <div>• Guias de intervenção e apoio terapêutico</div>
                  </div>
                </div>
              </div>
            </div>

            <div>
              <button
                onClick={onOpenCheckout}
                className="w-full py-4 bg-[#6657C8] hover:bg-[#5545B3] text-white font-extrabold text-sm uppercase tracking-wider rounded-xl transition-all cursor-pointer shadow-lg hover:shadow-xl text-center flex items-center justify-center gap-2"
              >
                <span>QUERO O COMBO COMPLETO</span>
                <ArrowRight className="w-4 h-4" />
              </button>

              <div className="mt-2 text-center text-[10px] text-[#36B77A] font-semibold flex items-center justify-center gap-1">
                <Sparkles className="w-3 h-3" />
                Oferta com acesso imediato após a compra
              </div>

              <div className="mt-2 flex items-center justify-center gap-3 text-[10px] text-slate-400">
                <span className="flex items-center gap-1">
                  <ShieldCheck className="w-3 h-3 text-[#36B77A]" /> Compra Segura
                </span>
                <span>•</span>
                <span>Garantia 7 dias</span>
                <span>•</span>
                <span>Acesso Imediato</span>
              </div>
            </div>
          </div>

        </div>
      </div>
    </section>
  );
};
