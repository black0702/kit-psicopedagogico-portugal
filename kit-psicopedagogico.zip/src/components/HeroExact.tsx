import React from 'react';
import { ArrowRight, Lock, Sparkles, FolderDown, FileText, CheckCircle2, Heart, Award, Printer } from 'lucide-react';

interface HeroExactProps {
  onCtaClick: () => void;
}

export const HeroExact: React.FC<HeroExactProps> = ({ onCtaClick }) => {
  return (
    <section className="pt-6 sm:pt-10 pb-12 sm:pb-16 px-4 bg-gradient-to-b from-[#F7F5FC] via-white to-[#F7F5FC] text-center relative overflow-hidden">
      
      {/* Elementos decorativos de fundo suaves e dinâmicos */}
      <div className="absolute top-12 left-10 w-48 h-48 bg-purple-200/30 rounded-full blur-3xl -z-10 pointer-events-none" />
      <div className="absolute top-20 right-10 w-56 h-56 bg-amber-200/30 rounded-full blur-3xl -z-10 pointer-events-none" />
      <div className="absolute bottom-10 left-1/3 w-64 h-64 bg-emerald-200/25 rounded-full blur-3xl -z-10 pointer-events-none" />

      <div className="max-w-5xl mx-auto">
        
        {/* Rótulo superior com gradiente e estrelinhas */}
        <div className="inline-block mb-3.5">
          <span className="text-xs sm:text-sm font-extrabold text-[#6657C8] uppercase tracking-wider bg-gradient-to-r from-[#E9E5F8] via-[#F4EFFF] to-[#E9E5F8] px-4 py-1.5 rounded-full inline-flex items-center gap-2 border border-[#6657C8]/20 shadow-xs">
            <Sparkles className="w-4 h-4 text-amber-500 fill-amber-400" />
            EDIÇÃO 2026 e 2027 • ATUALIZADA & COLORIDA
            <Sparkles className="w-4 h-4 text-amber-500 fill-amber-400" />
          </span>
        </div>

        {/* Título Principal */}
        <h1 className="text-3xl sm:text-4xl md:text-5xl lg:text-6xl font-black text-[#30264D] leading-[1.12] font-display mb-4">
          Apostila Completa de Avaliação e Intervenção{' '}
          <span className="text-transparent bg-clip-text bg-gradient-to-r from-[#6657C8] via-[#854CE6] to-[#36B77A]">
            Psicopedagógica
          </span>
        </h1>

        {/* Subtítulo dinâmico */}
        <p className="text-base sm:text-lg md:text-xl text-[#27243A]/90 max-w-3xl mx-auto mb-3 leading-relaxed">
          Receba mais de <strong>50 testes sistematizados</strong>, fichas lúdicas, jogos pedagógicos e recursos manipulativos prontos para imprimir e aplicar.
        </p>

        {/* Linha de Destaque com Ícones Coloridos */}
        <div className="inline-flex items-center flex-wrap justify-center gap-2 text-xs sm:text-sm font-bold text-[#6657C8] bg-white border border-[#E9E5F8] px-4 py-2 rounded-2xl shadow-xs mb-8">
          <span className="flex items-center gap-1 text-emerald-600">
            <span className="w-2 h-2 rounded-full bg-emerald-500" /> +200 Páginas Visuais
          </span>
          <span className="text-slate-300">•</span>
          <span className="flex items-center gap-1 text-purple-600">
            <span className="w-2 h-2 rounded-full bg-purple-500" /> Jogos & Dinâmicas
          </span>
          <span className="text-slate-300">•</span>
          <span className="flex items-center gap-1 text-amber-600">
            <span className="w-2 h-2 rounded-full bg-amber-500" /> Mapas Mentais
          </span>
          <span className="text-slate-300">•</span>
          <span className="flex items-center gap-1 text-rose-600">
            <span className="w-2 h-2 rounded-full bg-rose-500" /> Inclusão & AEE
          </span>
        </div>

        {/* MOCKUP CENTRAL SUPER COLORIDO E DINÂMICO (NOVA IMAGEM COMPLETA 2026 e 2027) */}
        <div className="relative max-w-4xl mx-auto mb-8 group">
          {/* Brilho de Fundo Colorido */}
          <div className="absolute -inset-1.5 bg-gradient-to-r from-purple-500 via-amber-400 to-emerald-400 rounded-3xl blur-xl opacity-35 group-hover:opacity-60 transition duration-500 -z-10" />

          {/* Moldura da Imagem */}
          <div className="bg-white p-2.5 sm:p-4 rounded-3xl border border-slate-200/80 shadow-2xl overflow-hidden">
            <img
              src="/src/assets/images/hero_psico_ptbr_1790625402053.jpg"
              alt="Kit Psicopedagógica 2026 e 2027 - Materiais, Estratégias e Recursos Coloridos"
              referrerPolicy="no-referrer"
              className="w-full h-auto rounded-2xl object-cover transform group-hover:scale-[1.01] transition-transform duration-300"
            />
          </div>

          <div className="mt-4 text-xs sm:text-sm font-medium text-slate-600 max-w-2xl mx-auto flex items-center justify-center gap-2">
            <span className="w-2 h-2 rounded-full bg-[#36B77A] animate-ping" />
            <span>Materiais visuais, lúdicos e estruturados para apoiar o desenvolvimento e a aprendizagem com alegria e técnica.</span>
          </div>
        </div>

        {/* Botão de Ação Imediato */}
        <div className="pt-2">
          <button
            onClick={onCtaClick}
            className="w-full sm:w-auto px-9 py-4 bg-gradient-to-r from-[#36B77A] to-[#2BA068] hover:from-[#2FA56D] hover:to-[#248957] text-white font-black text-base sm:text-lg uppercase tracking-wider rounded-2xl shadow-xl hover:shadow-2xl hover:-translate-y-0.5 active:translate-y-0 transition-all cursor-pointer inline-flex items-center justify-center gap-2.5 border-b-4 border-[#248957]"
          >
            <span>QUERO GARANTIR MINHA APOSTILA COMPLETA</span>
            <ArrowRight className="w-5 h-5" />
          </button>
          
          <div className="mt-3 text-xs text-slate-500 flex items-center justify-center gap-3 flex-wrap">
            <span className="flex items-center gap-1 text-[#30264D] font-medium">
              <Lock className="w-3.5 h-3.5 text-[#36B77A]" /> Acesso Imediato
            </span>
            <span>•</span>
            <span className="flex items-center gap-1 text-[#30264D] font-medium">
              <Sparkles className="w-3.5 h-3.5 text-amber-500" /> Edição 2026/2027
            </span>
            <span>•</span>
            <span className="flex items-center gap-1 text-[#30264D] font-medium">
              <Award className="w-3.5 h-3.5 text-[#6657C8]" /> 7 Dias de Garantia
            </span>
          </div>
        </div>

      </div>
    </section>
  );
};
