import React, { useState } from 'react';
import { X, CheckCircle2, ShieldCheck, ArrowRight, Check } from 'lucide-react';
import { CONFIG } from '../data/landingData';

interface CheckoutModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const CheckoutModal: React.FC<CheckoutModalProps> = ({ isOpen, onClose }) => {
  const [copied, setCopied] = useState(false);
  const [proceeded, setProceeded] = useState(false);

  if (!isOpen) return null;

  const handleProceed = () => {
    setProceeded(true);
    setTimeout(() => {
      setProceeded(false);
      onClose();
    }, 2200);
  };

  const handleCopyLink = () => {
    navigator.clipboard?.writeText(CONFIG.checkoutLink);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-[#30264D]/60 backdrop-blur-xs animate-in fade-in duration-200">
      <div 
        className="bg-white w-full max-w-md rounded-3xl border border-[#E9E5F8] shadow-2xl overflow-hidden"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="bg-[#6657C8] text-white p-5 text-center relative">
          <button
            onClick={onClose}
            className="absolute top-4 right-4 w-7 h-7 rounded-full bg-white/20 hover:bg-white/30 text-white flex items-center justify-center transition-colors cursor-pointer"
            aria-label="Fechar"
          >
            <X className="w-4 h-4" />
          </button>
          <div className="w-12 h-12 mx-auto rounded-2xl bg-white/10 flex items-center justify-center mb-2">
            <CheckCircle2 className="w-6 h-6 text-[#36B77A]" />
          </div>
          <h3 className="text-lg font-bold font-display text-white">
            Ambiente de Compra
          </h3>
          <p className="text-xs text-slate-200 mt-0.5">
            {CONFIG.productName}
          </p>
        </div>

        {/* Content */}
        <div className="p-6 space-y-4">
          <div className="bg-[#F7F5FC] p-4 rounded-2xl border border-[#E9E5F8] text-center">
            <span className="text-xs text-slate-500 uppercase tracking-wider font-semibold">
              Valor Promocional
            </span>
            <div className="text-3xl font-extrabold text-[#6657C8] font-display mt-0.5">
              R$ {CONFIG.offerPrice}
            </div>
            <span className="text-[11px] text-slate-500">
              Pagamento único • Acesso imediato aos PDFs
            </span>
          </div>

          <div className="space-y-2 text-xs text-slate-600">
            <div className="flex items-center justify-between bg-slate-50 p-2.5 rounded-xl border border-slate-200">
              <div>
                <span className="text-[10px] text-slate-400 block">Link de checkout:</span>
                <code className="font-mono text-xs text-[#6657C8] font-semibold">{CONFIG.checkoutLink}</code>
              </div>
              <button
                onClick={handleCopyLink}
                className="px-2.5 py-1 text-[10px] font-semibold bg-white border border-slate-200 rounded-lg text-slate-600 hover:text-slate-900 transition-colors flex items-center gap-1 cursor-pointer"
              >
                {copied ? <Check className="w-3 h-3 text-[#36B77A]" /> : null}
                <span>{copied ? 'Copiado!' : 'Copiar'}</span>
              </button>
            </div>
            <div className="flex items-center gap-2 pt-1">
              <ShieldCheck className="w-4 h-4 text-[#36B77A] shrink-0" />
              <span>Garantia total incondicional de 7 dias com reembolso integral</span>
            </div>
          </div>

          {proceeded ? (
            <div className="bg-[#36B77A]/10 text-[#36B77A] p-3 rounded-xl text-center text-xs font-bold flex items-center justify-center gap-2 animate-in fade-in">
              <Check className="w-4 h-4" />
              <span>Redirecionando para o checkout com segurança...</span>
            </div>
          ) : (
            <div className="pt-2">
              <button
                onClick={handleProceed}
                className="w-full py-3.5 px-4 bg-[#6657C8] hover:bg-[#5545B3] text-white font-bold text-sm rounded-xl shadow-md transition-colors flex items-center justify-center gap-2 cursor-pointer"
              >
                <span>Prosseguir para o Pagamento</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          )}
        </div>

        <div className="bg-[#F7F5FC] px-6 py-3 border-t border-slate-100 text-center text-[10px] text-slate-400">
          Transação segura com criptografia ponta a ponta
        </div>
      </div>
    </div>
  );
};
