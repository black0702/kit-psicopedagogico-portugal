import React from 'react';
import { 
  FileText, 
  BrainCircuit, 
  Sparkles, 
  BookOpen, 
  Target, 
  CheckCircle2, 
  FolderTree, 
  Layers, 
  Clock, 
  Users 
} from 'lucide-react';

export const ContentCardsGrid: React.FC = () => {
  const cards = [
    {
      title: 'Áreas avaliativas completas com orientações detalhadas',
      desc: 'Roteiros estruturados para cada etapa do processo diagnóstico psicopedagógico.',
      icon: Target,
      tag: 'Avaliação',
      imageSrc: '/src/assets/images/bib_areas_avaliativas_ptbr_1790626060725.jpg',
    },
    {
      title: 'Documentos administrativos psicopedagógicos prontos',
      desc: 'Contratos pedagógicos, fichas de acolhimento e formulários para uso clínico e institucional.',
      icon: FileText,
      tag: 'Organização',
      imageSrc: '/src/assets/images/bib_docs_admin_ptbr_1790626073569.jpg',
    },
    {
      title: 'Avaliação de leitura e escrita com critérios claros',
      desc: 'Sondagens com textos padronizados e protocolos objetivos de análise de erros.',
      icon: BookOpen,
      tag: 'Alfabetização',
      imageSrc: '/src/assets/images/bib_leitura_escrita_ptbr_1790626085796.jpg',
    },
    {
      title: 'Avaliação da atenção e memória com instrumentos',
      desc: 'Testes validados qualitativamente para identificação de oscilações de foco e memória de trabalho.',
      icon: BrainCircuit,
      tag: 'Cognição',
      imageSrc: '/src/assets/images/bib_atencao_memoria_ptbr_1790626099697.jpg',
    },
    {
      title: 'Bateria de rastreio para dificuldades de aprendizagem',
      desc: 'Indicadores preliminares relacionados a dislexia, discalculia e disortografia.',
      icon: Sparkles,
      tag: 'Rastreio',
      imageSrc: '/src/assets/images/bib_rastreio_dificuldades_ptbr_1790626109414.jpg',
    },
    {
      title: 'Avaliação da consciência fonológica com atividades',
      desc: 'Pranchas práticas com critérios claros de análise silábica, rimas e aliterações.',
      icon: Layers,
      tag: 'Consciência Fonológica',
      imageSrc: '/src/assets/images/bib_fonologica_ptbr_1790626119399.jpg',
    },
    {
      title: 'Modelos de devolutiva psicopedagógica completa',
      desc: 'Sínteses compreensíveis e editáveis para comunicação com pais e equipe escolar.',
      icon: Users,
      tag: 'Devolutiva',
      imageSrc: '/src/assets/images/bib_devolutiva_escola_ptbr_1790626133349.jpg',
    },
    {
      title: 'Encaminhamento para próximos passos com orientações',
      desc: 'Modelos de relatório com orientações claras para a intervenção e mediação contínua.',
      icon: CheckCircle2,
      tag: 'Intervenção',
      imageSrc: '/src/assets/images/bib_encaminhamento_ptbr_1790626145496.jpg',
    },
    {
      title: 'Fichas de acompanhamento e frequência por sessão',
      desc: 'Controle de evolução e engajamento para registro formal do processo.',
      icon: Clock,
      tag: 'Gestão',
      imageSrc: '/src/assets/images/bib_fichas_gestao_ptbr_1790626154418.jpg',
    },
  ];

  return (
    <section className="py-14 sm:py-20 px-4 bg-[#F7F5FC]">
      <div className="max-w-6xl mx-auto">
        <div className="text-center max-w-3xl mx-auto mb-10 sm:mb-14">
          <span className="text-xs font-bold text-[#6657C8] uppercase tracking-wider bg-[#E9E5F8] px-3.5 py-1.5 rounded-full inline-block mb-3">
            ACERVO COMPLETO
          </span>
          <h2 className="text-2xl sm:text-3xl md:text-4xl font-extrabold text-[#30264D] font-display">
            O que você encontrará dentro da Biblioteca
          </h2>
          <p className="text-sm sm:text-base text-slate-600 mt-2">
            Material organizado de forma prática, ilustrada e pronta para facilitar sua aplicação no dia a dia clínico ou escolar.
          </p>
        </div>

        {/* Grade de 9 Cards com Imagens Ilustradas em Cada Tópico */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5 sm:gap-6 mb-12">
          {cards.map((card, i) => {
            const Icon = card.icon;
            return (
              <div
                key={i}
                className="bg-white rounded-2xl overflow-hidden border border-[#E9E5F8] shadow-xs hover:shadow-lg transition-all duration-300 flex flex-col justify-between group hover:-translate-y-1"
              >
                <div>
                  {/* Imagem Ilustrada Superior do Card */}
                  <div className="relative aspect-[16/9] w-full overflow-hidden bg-slate-100 border-b border-slate-100">
                    <img
                      src={card.imageSrc}
                      alt={card.title}
                      referrerPolicy="no-referrer"
                      className="w-full h-full object-cover transform group-hover:scale-105 transition-transform duration-500"
                    />
                    <div className="absolute top-2.5 left-2.5 bg-white/95 backdrop-blur-xs text-[#6657C8] text-[10px] font-bold px-2 py-0.5 rounded-md shadow-xs border border-slate-200">
                      {card.tag}
                    </div>
                    <div className="absolute top-2.5 right-2.5 w-6 h-6 rounded-full bg-white/95 text-[#6657C8] flex items-center justify-center shadow-xs">
                      <Icon className="w-3.5 h-3.5" />
                    </div>
                  </div>

                  {/* Conteúdo Escrito Estruturado */}
                  <div className="p-4 sm:p-5">
                    <h3 className="text-sm font-bold text-[#30264D] mb-1.5 leading-snug group-hover:text-[#6657C8] transition-colors">
                      {card.title}
                    </h3>
                    <p className="text-xs text-slate-600 leading-relaxed">
                      {card.desc}
                    </p>
                  </div>
                </div>

                <div className="px-4 pb-4 sm:px-5 sm:pb-5 pt-0">
                  <div className="pt-2.5 border-t border-slate-100 text-[11px] text-[#36B77A] font-semibold flex items-center justify-between">
                    <span className="flex items-center gap-1">
                      <CheckCircle2 className="w-3.5 h-3.5" />
                      Pronto para imprimir e aplicar
                    </span>
                    <span className="text-[10px] bg-[#36B77A]/10 text-[#36B77A] px-2 py-0.5 rounded-full font-bold">
                      PDF & Word
                    </span>
                  </div>
                </div>
              </div>
            );
          })}
        </div>

        {/* Imagem da Mesa de Trabalho / Organização Real */}
        <div className="relative rounded-3xl overflow-hidden border border-[#E9E5F8] shadow-xl bg-white p-3 sm:p-5">
          <img
            src="/src/assets/images/mesa_trabalho_colorida_1790623660925.jpg"
            alt="Mesa de trabalho psicopedagógica organizada e colorida"
            referrerPolicy="no-referrer"
            className="w-full h-auto rounded-2xl object-cover max-h-[480px]"
          />
          <div className="p-4 text-center">
            <p className="text-xs sm:text-sm font-semibold text-slate-700">
              Tudo organizado de forma prática, lúdica e estruturada para facilitar sua aplicação no dia a dia clínico ou escolar.
            </p>
          </div>
        </div>

      </div>
    </section>
  );
};
