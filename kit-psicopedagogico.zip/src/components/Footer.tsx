import React from 'react';
import { CONFIG } from '../data/landingData';

interface FooterProps {
  onOpenLegal: (type: 'termos' | 'privacidade' | 'contato') => void;
}

export const Footer: React.FC<FooterProps> = ({ onOpenLegal }) => {
  const currentYear = new Date().getFullYear();

  return (
    <footer className="bg-[#30264D] text-white py-12 px-4 border-t border-white/10 text-center">
      <div className="max-w-4xl mx-auto space-y-6">
        {/* Product Title */}
        <div className="text-base sm:text-lg font-bold text-white font-display">
          {CONFIG.productName}
        </div>

        {/* Legal Links */}
        <div className="flex flex-wrap items-center justify-center gap-6 text-xs text-slate-300">
          <button
            onClick={() => onOpenLegal('termos')}
            className="hover:text-white transition-colors cursor-pointer underline-offset-4 hover:underline"
          >
            Termos de Uso
          </button>
          <span className="text-slate-600">•</span>
          <button
            onClick={() => onOpenLegal('privacidade')}
            className="hover:text-white transition-colors cursor-pointer underline-offset-4 hover:underline"
          >
            Política de Privacidade
          </button>
          <span className="text-slate-600">•</span>
          <button
            onClick={() => onOpenLegal('contato')}
            className="hover:text-white transition-colors cursor-pointer underline-offset-4 hover:underline"
          >
            Contato
          </button>
        </div>

        {/* Disclaimer */}
        <p className="text-[11px] text-slate-400 max-w-2xl mx-auto leading-relaxed">
          Este material é um produto digital composto por recursos pedagógicos de apoio prático. O material não substitui acompanhamento, avaliação clínica ou conduta multiprofissional. Todos os direitos reservados.
        </p>

        <div className="text-[10px] text-slate-500 pt-2 border-t border-white/5">
          © {currentYear} • Biblioteca Visual Psicopedagógica
        </div>
      </div>
    </footer>
  );
};
