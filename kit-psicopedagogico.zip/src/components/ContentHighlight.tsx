import React from 'react';
import { Layers, FileText, CheckCircle2, Sparkles } from 'lucide-react';

export const ContentHighlight: React.FC = () => {
  return (
    <section className="py-14 sm:py-20 px-4 bg-[#F7F5FC]">
      <div className="max-w-5xl mx-auto">
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-10 sm:mb-14">
          <span className="text-xs font-bold text-[#6657C8] uppercase tracking-wider bg-[#E9E5F8] px-3 py-1 rounded-full mb-3 inline-block">
            ACERVO ESTRUTURADO
          </span>
          <h2 className="text-2xl sm:text-3xl md:text-4xl font-extrabold text-[#30264D] mb-3 font-display">
            Uma biblioteca pensada para facilitar sua rotina
          </h2>
          <p className="text-sm sm:text-base text-slate-600 leading-relaxed">
            Tenha em mãos os recursos organizados em alta resolução para aplicar com segurança.
          </p>
        </div>

        {/* Central Card with [MOCKUP PRINCIPAL] */}
        <div className="bg-white rounded-3xl p-6 sm:p-10 border border-[#E9E5F8] shadow-lg mb-10">
          {/* Top Tag */}
          <div className="flex items-center justify-between pb-3 mb-6 border-b border-slate-100 text-xs font-bold text-[#6657C8]">
            <span className="flex items-center gap-1.5 font-mono">
              <Layers className="w-4 h-4 text-[#6657C8]" />
              [MOCKUP PRINCIPAL]
            </span>
            <span className="bg-[#36B77A]/10 text-[#36B77A] px-2.5 py-0.5 rounded-full">
              Padrão Editorial
            </span>
          </div>

          {/* Big Visual Composition */}
          <div className="bg-gradient-to-br from-[#30264D] via-[#3C3060] to-[#261E3D] rounded-2xl p-6 sm:p-10 text-white shadow-xl relative overflow-hidden text-center mb-8">
            <div className="inline-flex items-center gap-1.5 bg-[#6657C8] text-white text-[11px] font-bold px-3 py-1 rounded-full uppercase tracking-wider mb-4">
              <Sparkles className="w-3.5 h-3.5 text-yellow-300" />
              Kit Completo de Avaliação & Intervenção
            </div>

            <h3 className="text-2xl sm:text-3xl font-extrabold mb-3 text-white font-display">
              Biblioteca Visual Psicopedagógica
            </h3>

            <p className="text-xs sm:text-sm text-slate-300 max-w-lg mx-auto mb-6 leading-relaxed">
              Materiais diagramados com cuidado visual, clareza tipográfica e foco na aplicabilidade prática.
            </p>

            {/* Inner Preview Deck */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 max-w-2xl mx-auto pt-4 border-t border-white/10 text-center">
              <div className="bg-white/10 backdrop-blur-sm p-3 rounded-xl border border-white/10">
                <div className="text-xs font-bold text-white mb-0.5">Triagem</div>
                <div className="text-[10px] text-slate-400">Fichas iniciais</div>
              </div>
              <div className="bg-white/10 backdrop-blur-sm p-3 rounded-xl border border-white/10">
                <div className="text-xs font-bold text-[#36B77A] mb-0.5">Cognição</div>
                <div className="text-[10px] text-slate-400">Atenção e foco</div>
              </div>
              <div className="bg-white/10 backdrop-blur-sm p-3 rounded-xl border border-white/10">
                <div className="text-xs font-bold text-white mb-0.5">Memória</div>
                <div className="text-[10px] text-slate-400">Cartões e séries</div>
              </div>
              <div className="bg-white/10 backdrop-blur-sm p-3 rounded-xl border border-white/10">
                <div className="text-xs font-bold text-yellow-300 mb-0.5">Intervenção</div>
                <div className="text-[10px] text-slate-400">Práticas guiadas</div>
              </div>
            </div>
          </div>

          {/* 3 Grandes Números */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 pt-4 text-center">
            <div className="p-4 bg-[#F7F5FC] rounded-2xl border border-[#E9E5F8]">
              <div className="text-3xl sm:text-4xl font-black text-[#6657C8] font-display mb-1">
                +200
              </div>
              <div className="text-xs sm:text-sm font-bold text-[#30264D] uppercase tracking-wider">
                RECURSOS
              </div>
              <div className="text-[11px] text-slate-500 mt-1">
                Materiais práticos organizados
              </div>
            </div>

            <div className="p-4 bg-[#F7F5FC] rounded-2xl border border-[#E9E5F8]">
              <div className="text-3xl sm:text-4xl font-black text-[#36B77A] font-display mb-1">
                8
              </div>
              <div className="text-xs sm:text-sm font-bold text-[#30264D] uppercase tracking-wider">
                ÁREAS
              </div>
              <div className="text-[11px] text-slate-500 mt-1">
                Classificadas por objetivo
              </div>
            </div>

            <div className="p-4 bg-[#F7F5FC] rounded-2xl border border-[#E9E5F8]">
              <div className="text-3xl sm:text-4xl font-black text-[#30264D] font-display mb-1">
                PDF
              </div>
              <div className="text-xs sm:text-sm font-bold text-[#30264D] uppercase tracking-wider">
                FORMATO DIGITAL
              </div>
              <div className="text-[11px] text-slate-500 mt-1">
                Pronto para impressão e consulta
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
