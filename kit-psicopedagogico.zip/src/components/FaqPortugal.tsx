import React, { useState } from 'react';
import { ChevronDown, HelpCircle } from 'lucide-react';

interface FaqItem {
  q: string;
  a: string;
}

export const FaqPortugal: React.FC = () => {
  const [openIndex, setOpenIndex] = useState<number | null>(0);

  const faqs: FaqItem[] = [
    {
      q: 'Como e quando recebo o acesso ao material?',
      a: 'Assim que o pagamento for confirmado pela plataforma de pagamento, os dados e o link de acesso aos ficheiros digitais são enviados imediatamente para o seu endereço de e-mail registado. Verifique também a pasta de spam ou promoções.'
    },
    {
      q: 'Os ficheiros são digitais ou recebo algum livro físico em casa?',
      a: 'O produto é 100% digital. Isto permite-lhe descarregar os ficheiros instantaneamente para o seu computador ou telemóvel e imprimir as páginas sempre que necessário, sem custos de portes ou tempos de espera de entrega postal.'
    },
    {
      q: 'Os documentos podem ser editados no computador?',
      a: 'Sim. A maior parte das fichas de atividades e testes está em formato PDF de alta resolução pronta a imprimir. Adicionalmente, os modelos do Drive Profissional (anamnese, PEI, relatórios e fichas de frequência) estão em formato Word (.docx), permitindo-lhe personalizar textos, logótipos e dados do aluno.'
    },
    {
      q: 'O material é adequado para o contexto escolar em Portugal?',
      a: 'Sim. As fichas contemplam competências universais de desenvolvimento: leitura, escrita, consciência fonológica, raciocínio lógico-matemático, atenção seletiva e funções executivas, amplamente trabalhadas no 1.º e 2.º ciclos do ensino básico e na educação especial em Portugal.'
    },
    {
      q: 'Posso imprimir quantas vezes quiser?',
      a: 'Sim, tem total liberdade para imprimir tantas cópias quantas as necessárias para os seus alunos ou pacientes no âmbito da sua atividade profissional individual.'
    },
    {
      q: 'Quais são as formas de pagamento disponíveis em Portugal?',
      a: 'O checkout aceita os principais cartões de crédito e débito internacionais (Visa, Mastercard, etc.). Dependendo da disponibilidade do gateway de pagamento, métodos locais como MB WAY e Multibanco podem estar disponíveis no ecrã de finalização.'
    },
    {
      q: 'O pagamento é único ou há alguma mensalidade?',
      a: 'O pagamento é estritamente único. Não existem assinaturas, anuidades ou qualquer cobrança recorrente no seu cartão.'
    },
    {
      q: 'Como funciona a garantia de 7 dias?',
      a: 'Conforme a nossa política de satisfação e as normas de consumo aplicáveis a conteúdos digitais, se dentro de 7 dias a contar da compra considerar que o material não atende às suas expectativas, basta contactar o nosso suporte por e-mail para solicitar a devolução de 100% do montante pago.'
    },
  ];

  const toggle = (idx: number) => {
    setOpenIndex(openIndex === idx ? null : idx);
  };

  return (
    <section id="faq" className="py-16 sm:py-24 px-4 bg-[#FFFFFF]">
      <div className="max-w-4xl mx-auto">
        
        <div className="text-center mb-14">
          <span className="text-xs font-bold text-[#25A69A] uppercase tracking-wider bg-[#E8F4F2] px-3.5 py-1.5 rounded-full inline-block mb-3 border border-[#C5E4DD]">
            ESCLARECIMENTOS
          </span>
          <h2 className="font-heading font-black text-2xl sm:text-4xl text-[#123C4A] leading-tight mb-4">
            Perguntas Frequentes
          </h2>
          <p className="text-sm sm:text-base text-[#5D737E]">
            Tudo o que precisa de saber sobre o acesso, formatos e utilização dos materiais.
          </p>
        </div>

        {/* Acordeão Interativo e Acessível */}
        <div className="space-y-3.5">
          {faqs.map((faq, i) => {
            const isOpen = openIndex === i;
            return (
              <div
                key={i}
                className="bg-[#F8FAF9] rounded-2xl border border-[#E2EBE8] overflow-hidden transition-all duration-200"
              >
                <button
                  type="button"
                  onClick={() => toggle(i)}
                  className="w-full py-4.5 px-6 text-left flex items-center justify-between gap-4 font-heading font-bold text-sm sm:text-base text-[#182B35] hover:text-[#25A69A] transition-colors cursor-pointer"
                  aria-expanded={isOpen}
                >
                  <span>{faq.q}</span>
                  <div className={`w-8 h-8 rounded-full bg-white flex items-center justify-center shrink-0 border border-slate-200 text-[#123C4A] transition-transform duration-300 ${isOpen ? 'rotate-180 bg-[#E8F4F2] text-[#25A69A]' : ''}`}>
                    <ChevronDown className="w-4 h-4" />
                  </div>
                </button>

                {isOpen && (
                  <div className="px-6 pb-5 pt-1 text-xs sm:text-sm text-[#5D737E] leading-relaxed border-t border-slate-100 bg-white">
                    {faq.a}
                  </div>
                )}
              </div>
            );
          })}
        </div>

      </div>
    </section>
  );
};
