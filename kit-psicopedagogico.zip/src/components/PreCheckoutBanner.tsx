import React from 'react';
import { ArrowRight, CheckCircle2 } from 'lucide-react';

interface PreCheckoutBannerProps {
  onCtaClick: () => void;
}

export const PreCheckoutBanner: React.FC<PreCheckoutBannerProps> = ({ onCtaClick }) => {
  return (
    <section className="py-12 sm:py-16 px-4 bg-[#F7F5FC] border-t border-[#E9E5F8]">
      <div className="max-w-4xl mx-auto bg-white rounded-3xl p-6 sm:p-10 border border-[#E9E5F8] shadow-lg">
        <div className="grid grid-cols-1 md:grid-cols-12 gap-8 items-center">
          
          {/* Mockup do Kit à Esquerda */}
          <div className="md:col-span-5 flex justify-center">
            <div className="relative max-w-xs">
              <img
                src="/src/assets/images/mockup_kit_ptbr_1790625433365.jpg"
                alt="Kit Visual de Hábitos e Regulação"
                referrerPolicy="no-referrer"
                className="w-full h-auto rounded-2xl shadow-md border border-slate-100"
              />
            </div>
          </div>

          {/* Chamada e Botão à Direita */}
          <div className="md:col-span-7 text-left space-y-3">
            <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">
              VOCÊ TAMBÉM RECEBE
            </span>
            <h3 className="text-xl sm:text-2xl font-extrabold text-[#30264D] font-display">
              Kit Visual de Hábitos, Comunicação e Regulação
            </h3>
            <p className="text-xs text-slate-500 leading-relaxed">
              Recursos visuais prontos para rotina, comunicação, emoções, transições, autorregulação e acompanhamento.
            </p>

            <div className="space-y-1.5 pt-1 text-xs text-slate-700">
              <div className="flex items-center gap-2">
                <span className="text-[#36B77A] font-bold">✓</span>
                <span>Material digital</span>
              </div>
              <div className="flex items-center gap-2">
                <span className="text-[#36B77A] font-bold">✓</span>
                <span>Pronto para imprimir</span>
              </div>
              <div className="flex items-center gap-2">
                <span className="text-[#36B77A] font-bold">✓</span>
                <span>Consulta prática</span>
              </div>
              <div className="flex items-center gap-2">
                <span className="text-[#36B77A] font-bold">✓</span>
                <span>Uso em atendimentos e contextos educativos/familiares</span>
              </div>
            </div>

            <div className="pt-3">
              <button
                onClick={onCtaClick}
                className="w-full sm:w-auto px-7 py-3.5 bg-[#36B77A] hover:bg-[#2FA56D] text-white font-bold text-xs uppercase tracking-wider rounded-xl transition-all shadow-md cursor-pointer flex items-center justify-center gap-2"
              >
                <span>QUERO O ACESSO COMPLETO</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          </div>

        </div>
      </div>
    </section>
  );
};
