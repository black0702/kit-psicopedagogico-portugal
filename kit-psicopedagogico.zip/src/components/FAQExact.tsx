import React, { useState } from 'react';
import { ChevronDown } from 'lucide-react';

export const FAQExact: React.FC = () => {
  const faqs = [
    {
      q: 'Como recebo o material?',
      a: 'Assim que o pagamento for confirmado, você receberá imediatamente no seu e-mail cadastrado os dados de acesso para download de todos os arquivos em PDF e do Drive Profissional.',
    },
    {
      q: 'O material é digital ou físico?',
      a: 'O material é 100% digital, disponível em PDF de altíssima resolução. Você pode consultar no computador, tablet, celular ou imprimir quantas cópias desejar para seus atendimentos.',
    },
    {
      q: 'Posso imprimir?',
      a: 'Sim! Todos os arquivos foram diagramados em padrão A4, prontos para impressão comum ou encadernação e plastificação.',
    },
    {
      q: 'O acesso é vitalício?',
      a: 'Sim, o acesso é vitalício. Você pode baixar os arquivos para seu computador e consultar para sempre sem mensalidades ou taxas extras.',
    },
    {
      q: 'Funciona mesmo se eu estiver começando na área?',
      a: 'Com certeza. Os recursos e o Guia Prático foram estruturados com linguagem clara e objetiva para orientar desde o profissional experiente até quem está realizando seus primeiros atendimentos.',
    },
    {
      q: 'E se o material não servir para mim?',
      a: 'Você conta com nossa Garantia Incondicional de 7 Dias. Se por qualquer motivo não gostar do material, basta nos enviar um e-mail que devolveremos 100% do seu dinheiro.',
    },
    {
      q: 'Serve apenas para psicopedagogos?',
      a: 'Não. É amplamente utilizado por neuropsicopedagogos, psicólogos infantis, professores de AEE, pedagogos e pais que desejam apoiar o desenvolvimento escolar dos filhos.',
    },
    {
      q: 'Não tenho muito tempo. Consigo aplicar?',
      a: 'Essa é a maior vantagem: os materiais estão 100% prontos para imprimir e aplicar. Você economiza as horas que gastava criando fichas do zero.',
    },
    {
      q: 'O material está atualizado com as normas atuais?',
      a: 'Sim, todos os instrumentos foram revisados de acordo com os parâmetros atuais de avaliação psicopedagógica e neurocognitiva.',
    },
    {
      q: 'A compra é segura?',
      a: 'Totalmente segura. O pagamento é processado através de plataforma com criptografia bancária de ponta a ponta.',
    },
    {
      q: 'Preciso ter formação específica para usar?',
      a: 'Os recursos são de apoio pedagógico e estimulação cognitiva. Para laudos formais exige-se registro profissional na área competente, mas para mediação e intervenção qualquer profissional da educação pode aplicar.',
    },
    {
      q: 'Tem suporte se eu tiver dúvidas?',
      a: 'Sim! Disponibilizamos suporte via e-mail e WhatsApp para tirar dúvidas de acesso ou download a qualquer momento.',
    },
  ];

  const [openIndex, setOpenIndex] = useState<number | null>(0);

  const toggle = (i: number) => {
    setOpenIndex(openIndex === i ? null : i);
  };

  return (
    <section className="py-16 sm:py-24 px-4 bg-[#F7F5FC]">
      <div className="max-w-2xl mx-auto text-center">
        <h2 className="text-2xl sm:text-3xl font-extrabold text-[#30264D] font-display mb-8">
          Perguntas <span className="text-[#6657C8]">Frequentes</span>
        </h2>

        <div className="space-y-2.5 text-left">
          {faqs.map((faq, i) => {
            const isOpen = openIndex === i;
            return (
              <div
                key={i}
                className="bg-white rounded-xl border border-[#E9E5F8] overflow-hidden shadow-2xs transition-all"
              >
                <button
                  onClick={() => toggle(i)}
                  className="w-full p-4 text-xs sm:text-sm font-semibold text-[#30264D] flex items-center justify-between gap-3 text-left cursor-pointer hover:bg-slate-50 transition-colors"
                >
                  <span>{faq.q}</span>
                  <ChevronDown
                    className={`w-4 h-4 text-slate-400 transition-transform duration-200 shrink-0 ${
                      isOpen ? 'rotate-180 text-[#6657C8]' : ''
                    }`}
                  />
                </button>

                {isOpen && (
                  <div className="px-4 pb-4 pt-1 text-xs text-slate-600 leading-relaxed border-t border-slate-50">
                    {faq.a}
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
};
