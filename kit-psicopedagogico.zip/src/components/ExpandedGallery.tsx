import React from 'react';
import { SAMPLES_EXPANDED } from '../data/landingData';
import { SamplePlaceholderCard } from './MockupElements';
import { SampleItem } from '../types';

interface ExpandedGalleryProps {
  onSelectSample: (sample: SampleItem) => void;
}

export const ExpandedGallery: React.FC<ExpandedGalleryProps> = ({ onSelectSample }) => {
  return (
    <section className="py-14 sm:py-20 px-4 bg-[#F7F5FC]">
      <div className="max-w-6xl mx-auto">
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-10 sm:mb-12">
          <span className="text-xs font-bold text-[#6657C8] uppercase tracking-wider bg-[#E9E5F8] px-3 py-1 rounded-full mb-3 inline-block">
            VISÃO GERAL DO ACERVO
          </span>
          <h2 className="text-2xl sm:text-3xl md:text-4xl font-extrabold text-[#30264D] mb-3 font-display">
            Veja por dentro da Biblioteca Visual Psicopedagógica
          </h2>
          <p className="text-sm sm:text-base text-slate-600 leading-relaxed">
            Os recursos foram pensados para facilitar a consulta, a preparação e a utilização dos materiais.
          </p>
        </div>

        {/* 10 Placeholders Grid: [AMOSTRA 07] to [AMOSTRA 16] */}
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-4 sm:gap-5">
          {SAMPLES_EXPANDED.map((sample) => (
            <SamplePlaceholderCard
              key={sample.id}
              sample={sample}
              onPreviewClick={onSelectSample}
            />
          ))}
        </div>

        <div className="text-center mt-8 text-xs text-slate-500">
          Clique em qualquer amostra para visualizar seus objetivos pedagógicos e especificações de impressão.
        </div>
      </div>
    </section>
  );
};
