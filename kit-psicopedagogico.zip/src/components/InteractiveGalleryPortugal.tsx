import React, { useState } from 'react';
import { ZoomIn, X, ChevronLeft, ChevronRight, Sparkles, Pause, Play } from 'lucide-react';

interface SampleItem {
  id: number;
  src: string;
  title: string;
  category: string;
  description: string;
}

export const InteractiveGalleryPortugal: React.FC = () => {
  const [selectedImage, setSelectedImage] = useState<SampleItem | null>(null);
  const [isPaused, setIsPaused] = useState(false);

  // Amostras reais com os ficheiros extraídos do kit
  const samplesRow1: SampleItem[] = [
    {
      id: 8,
      src: '/site_images/site_img_8.jpg',
      title: 'Caderno de Avaliação Prática',
      category: 'Avaliação & Anamnese',
      description: 'Estrutura completa com protocolos de observação e grelhas de competências.'
    },
    {
      id: 9,
      src: '/site_images/site_img_9.jpg',
      title: 'Plano de Intervenção Pedagógico',
      category: 'Intervenção & Metas',
      description: 'Modelos de intervenção estruturada com estratégias lúdicas e acompanhamento contínuo.'
    },
    {
      id: 10,
      src: '/site_images/site_img_10.jpg',
      title: 'Atividades de Estímulo Cognitivo',
      category: 'Estimulação Cognitiva',
      description: 'Pranchas de exercícios para treino de raciocínio lógico, foco e percepção visual.'
    },
    {
      id: 11,
      src: '/site_images/site_img_11.jpg',
      title: 'Recursos Lúdicos e Manipulativos',
      category: 'Recursos Lúdicos',
      description: 'Jogos de mesa, fichas para recortar e dinâmicas pedagógicas atrativas.'
    },
    {
      id: 12,
      src: '/site_images/site_img_12.jpg',
      title: 'Jogos Pedagógicos em PDF',
      category: 'Jogos Didáticos',
      description: 'Jogos prontos para plastificar e aplicar no consultório ou em sala de aula.'
    },
    {
      id: 13,
      src: '/site_images/site_img_13.jpg',
      title: 'Sequência Didática de Habilidades',
      category: 'Sequências Didáticas',
      description: 'Passo a passo progressivo para o desenvolvimento de competências essenciais.'
    },
    {
      id: 14,
      src: '/site_images/site_img_14.jpg',
      title: 'Registo de Evolução e Frequência',
      category: 'Gestão & Documentação',
      description: 'Fichas organizadas para registo sessão a sessão da evolução do aluno.'
    },
  ];

  const samplesRow2: SampleItem[] = [
    {
      id: 15,
      src: '/site_images/site_img_15.jpg',
      title: 'Kit Psicopedagógico Completo',
      category: 'Apostila Geral',
      description: 'Caderno integrador com visão global do processo de avaliação e intervenção.'
    },
    {
      id: 16,
      src: '/site_images/site_img_16.jpg',
      title: 'Planeamento Anual e Semestral',
      category: 'Planeamento Educativo',
      description: 'Grelha temporal para organizar objetivos ao longo do ano letivo.'
    },
    {
      id: 17,
      src: '/site_images/site_img_17.jpg',
      title: 'Cartões de Estímulos Cognitivos',
      category: 'Cartões de Estimulação',
      description: 'Cards ilustrados de acesso rápido para sessões de intervenção breve.'
    },
    {
      id: 18,
      src: '/site_images/site_img_18.jpg',
      title: 'Técnicas de Intervenção Pedagógica',
      category: 'Metodologia Prática',
      description: 'Roteiros de aplicação prática para mediação de dificuldades na leitura e cálculo.'
    },
    {
      id: 19,
      src: '/site_images/site_img_19.jpg',
      title: 'Dinâmicas e Atividades em Grupo',
      category: 'Atividades Coletivas',
      description: 'Dinâmicas para trabalho colaborativo e desenvolvimento de competências sociais.'
    },
    {
      id: 20,
      src: '/site_images/site_img_20.jpg',
      title: 'Guia de Inclusão e Apoio Especial',
      category: 'Inclusão & Apoio',
      description: 'Orientações práticas de mediação e adaptação curricular em ambiente escolar.'
    },
    {
      id: 21,
      src: '/site_images/site_img_21.jpg',
      title: 'Projetos de Intervenção Pedagógica',
      category: 'Projetos Práticos',
      description: 'Modelos de projetos temáticos estruturados com início, meio e fim.'
    },
    {
      id: 22,
      src: '/site_images/site_img_22.jpg',
      title: 'Passo a Passo da Aplicação',
      category: 'Orientações Clínicas',
      description: 'Instruções claras de aplicação de testes e análise dos resultados.'
    },
  ];

  const allSamples = [...samplesRow1, ...samplesRow2];

  const handleNext = () => {
    if (!selectedImage) return;
    const currentIndex = allSamples.findIndex((s) => s.id === selectedImage.id);
    const nextIndex = (currentIndex + 1) % allSamples.length;
    setSelectedImage(allSamples[nextIndex]);
  };

  const handlePrev = () => {
    if (!selectedImage) return;
    const currentIndex = allSamples.findIndex((s) => s.id === selectedImage.id);
    const prevIndex = (currentIndex - 1 + allSamples.length) % allSamples.length;
    setSelectedImage(allSamples[prevIndex]);
  };

  return (
    <section id="galeria" className="py-16 sm:py-24 bg-[#FFFFFF] overflow-hidden border-b border-[#E2EBE8]">
      <div className="max-w-6xl mx-auto px-4 mb-10 sm:mb-14">
        
        {/* Título da Secção */}
        <div className="max-w-3xl mx-auto text-center">
          <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-[#FBF7EE] border border-[#F3E7D0] text-[#D5AD68] text-xs font-bold uppercase tracking-wider mb-3">
            <Sparkles className="w-3.5 h-3.5" />
            <span>TRANSPARÊNCIA TOTAL • ALTA DEFINIÇÃO</span>
          </div>
          <h2 className="font-heading font-black text-2xl sm:text-4xl text-[#123C4A] leading-tight mb-4">
            Amostras reais do material em carrossel contínuo
          </h2>
          <p className="text-sm sm:text-base text-[#5D737E] leading-relaxed">
            As páginas passam automaticamente de forma fluida. Passe o cursor (ou toque) para pausar e clique em qualquer página para ampliar em alta resolução com o lightbox.
          </p>

          {/* Botão de controlo de pausa / reprodução */}
          <div className="mt-4 flex items-center justify-center gap-2 text-xs text-[#5D737E]">
            <button
              onClick={() => setIsPaused(!isPaused)}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-[#F0F5F3] hover:bg-[#E2EBE8] text-[#123C4A] font-semibold transition-colors cursor-pointer"
            >
              {isPaused ? <Play className="w-3.5 h-3.5 text-[#25A69A]" /> : <Pause className="w-3.5 h-3.5 text-[#25A69A]" />}
              <span>{isPaused ? 'Retomar movimento contínuo' : 'Pausar movimento'}</span>
            </button>
            <span className="hidden sm:inline">•</span>
            <span className="hidden sm:inline text-[11px] text-[#829CA3]">Mais de 200 páginas prontas a imprimir</span>
          </div>
        </div>

      </div>

      {/* ÁREA FLUTUANTE DE CARROSSEL CONTÍNUO (MARQUEE BIDIRECIONAL) */}
      <div 
        className="space-y-6 relative"
        onMouseEnter={() => setIsPaused(true)}
        onMouseLeave={() => setIsPaused(false)}
      >
        {/* Máscara de desvanecimento lateral sutil */}
        <div className="pointer-events-none absolute inset-y-0 left-0 w-12 sm:w-28 bg-gradient-to-r from-white to-transparent z-10" />
        <div className="pointer-events-none absolute inset-y-0 right-0 w-12 sm:w-28 bg-gradient-to-l from-white to-transparent z-10" />

        {/* Linha 1: Movimento para a Esquerda */}
        <div className="overflow-hidden flex">
          <div 
            className={`animate-marquee-left flex gap-5 py-2 px-3 ${isPaused ? '!animate-none' : ''}`}
          >
            {[...samplesRow1, ...samplesRow1, ...samplesRow1].map((item, index) => (
              <div
                key={`row1-${item.id}-${index}`}
                onClick={() => setSelectedImage(item)}
                className="group w-[220px] sm:w-[260px] shrink-0 bg-[#F8FAF9] rounded-2xl p-2.5 sm:p-3 border border-[#E2EBE8] hover:border-[#25A69A] shadow-xs hover:shadow-xl hover:-translate-y-1 transition-all duration-300 cursor-pointer flex flex-col justify-between"
              >
                <div className="relative aspect-[3/4] overflow-hidden rounded-xl bg-white mb-2.5 shadow-inner">
                  <img
                    src={item.src}
                    alt={item.title}
                    className="w-full h-full object-cover transform group-hover:scale-105 transition-transform duration-500"
                    loading="lazy"
                  />
                  <div className="absolute inset-0 bg-[#123C4A]/50 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center backdrop-blur-2xs">
                    <span className="px-3 py-1.5 bg-white text-[#123C4A] font-bold text-xs rounded-full shadow-md flex items-center gap-1.5">
                      <ZoomIn className="w-3.5 h-3.5 text-[#25A69A]" />
                      Ampliar Página
                    </span>
                  </div>
                </div>

                <div>
                  <span className="text-[10px] font-bold text-[#25A69A] uppercase tracking-wider block mb-0.5">
                    {item.category}
                  </span>
                  <h4 className="font-bold text-xs sm:text-sm text-[#182B35] leading-snug line-clamp-1 group-hover:text-[#25A69A] transition-colors">
                    {item.title}
                  </h4>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Linha 2: Movimento para a Direita */}
        <div className="overflow-hidden flex">
          <div 
            className={`animate-marquee-right flex gap-5 py-2 px-3 ${isPaused ? '!animate-none' : ''}`}
          >
            {[...samplesRow2, ...samplesRow2, ...samplesRow2].map((item, index) => (
              <div
                key={`row2-${item.id}-${index}`}
                onClick={() => setSelectedImage(item)}
                className="group w-[220px] sm:w-[260px] shrink-0 bg-[#F8FAF9] rounded-2xl p-2.5 sm:p-3 border border-[#E2EBE8] hover:border-[#25A69A] shadow-xs hover:shadow-xl hover:-translate-y-1 transition-all duration-300 cursor-pointer flex flex-col justify-between"
              >
                <div className="relative aspect-[3/4] overflow-hidden rounded-xl bg-white mb-2.5 shadow-inner">
                  <img
                    src={item.src}
                    alt={item.title}
                    className="w-full h-full object-cover transform group-hover:scale-105 transition-transform duration-500"
                    loading="lazy"
                  />
                  <div className="absolute inset-0 bg-[#123C4A]/50 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center backdrop-blur-2xs">
                    <span className="px-3 py-1.5 bg-white text-[#123C4A] font-bold text-xs rounded-full shadow-md flex items-center gap-1.5">
                      <ZoomIn className="w-3.5 h-3.5 text-[#25A69A]" />
                      Ampliar Página
                    </span>
                  </div>
                </div>

                <div>
                  <span className="text-[10px] font-bold text-[#25A69A] uppercase tracking-wider block mb-0.5">
                    {item.category}
                  </span>
                  <h4 className="font-bold text-xs sm:text-sm text-[#182B35] leading-snug line-clamp-1 group-hover:text-[#25A69A] transition-colors">
                    {item.title}
                  </h4>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Modal / Lightbox de Ampliação em Alta Resolução */}
      {selectedImage && (
        <div
          role="dialog"
          aria-modal="true"
          className="fixed inset-0 z-50 bg-[#123C4A]/80 backdrop-blur-sm flex items-center justify-center p-4 animate-fadeIn"
          onClick={() => setSelectedImage(null)}
        >
          <div
            className="relative max-w-2xl w-full bg-white rounded-3xl p-4 sm:p-6 shadow-2xl border border-white/20 flex flex-col items-center"
            onClick={(e) => e.stopPropagation()}
          >
            {/* Botão Fechar */}
            <button
              onClick={() => setSelectedImage(null)}
              className="absolute top-3 right-3 sm:top-4 sm:right-4 w-10 h-10 rounded-full bg-[#F0F5F3] hover:bg-[#E2EBE8] text-[#123C4A] flex items-center justify-center transition-colors cursor-pointer z-10"
              aria-label="Fechar ampliação"
            >
              <X className="w-5 h-5" />
            </button>

            {/* Botões Navegação Anterior/Próximo */}
            <button
              onClick={handlePrev}
              className="absolute left-2 sm:left-4 top-1/2 -translate-y-1/2 w-10 h-10 rounded-full bg-white/90 hover:bg-white text-[#123C4A] shadow-md flex items-center justify-center transition-all cursor-pointer z-10"
              aria-label="Amostra anterior"
            >
              <ChevronLeft className="w-6 h-6" />
            </button>

            <button
              onClick={handleNext}
              className="absolute right-2 sm:right-4 top-1/2 -translate-y-1/2 w-10 h-10 rounded-full bg-white/90 hover:bg-white text-[#123C4A] shadow-md flex items-center justify-center transition-all cursor-pointer z-10"
              aria-label="Próxima amostra"
            >
              <ChevronRight className="w-6 h-6" />
            </button>

            {/* Imagem Ampliada */}
            <div className="max-h-[65vh] w-auto overflow-hidden rounded-2xl mb-4 bg-slate-50 flex items-center justify-center">
              <img
                src={selectedImage.src}
                alt={selectedImage.title}
                className="max-h-[65vh] w-auto object-contain rounded-xl shadow-md"
              />
            </div>

            {/* Detalhes da Amostra */}
            <div className="w-full text-center">
              <span className="text-xs font-bold text-[#25A69A] uppercase tracking-wider bg-[#E8F4F2] px-3 py-1 rounded-full inline-block mb-1">
                {selectedImage.category}
              </span>
              <h3 className="font-heading font-black text-lg sm:text-xl text-[#123C4A]">
                {selectedImage.title}
              </h3>
              <p className="text-xs sm:text-sm text-[#5D737E] max-w-lg mx-auto mt-1">
                {selectedImage.description}
              </p>
            </div>
          </div>
        </div>
      )}
    </section>
  );
};
