import React from 'react';
import { CheckCircle2 } from 'lucide-react';
import { IMMEDIATE_BENEFITS } from '../data/landingData';

export const BenefitStrip: React.FC = () => {
  return (
    <section className="bg-white border-y border-[#E9E5F8] py-5 px-4 shadow-xs">
      <div className="max-w-5xl mx-auto">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3 sm:gap-6">
          {IMMEDIATE_BENEFITS.map((benefit, index) => (
            <div 
              key={index}
              className="flex items-center gap-2.5 text-xs sm:text-sm font-semibold text-[#30264D]"
            >
              <div className="w-5 h-5 rounded-full bg-[#36B77A]/15 text-[#36B77A] flex items-center justify-center shrink-0">
                <CheckCircle2 className="w-3.5 h-3.5" />
              </div>
              <span className="leading-snug">{benefit}</span>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};
