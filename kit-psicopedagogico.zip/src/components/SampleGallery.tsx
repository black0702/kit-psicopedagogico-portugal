import React from 'react';
import { SAMPLES_MAIN } from '../data/landingData';
import { SamplePlaceholderCard } from './MockupElements';
import { SampleItem } from '../types';

interface SampleGalleryProps {
  onSelectSample: (sample: SampleItem) => void;
  onCtaClick: () => void;
}

export const SampleGallery: React.FC<SampleGalleryProps> = ({ onSelectSample, onCtaClick }) => {
  return (
    <section className="py-14 sm:py-20 px-4 bg-[#F7F5FC]">
      <div className="max-w-6xl mx-auto">
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-10 sm:mb-12">
          <span className="text-xs font-bold text-[#6657C8] uppercase tracking-wider bg-[#E9E5F8] px-3 py-1 rounded-full mb-3 inline-block">
            AMOSTRAS DA BIBLIOTECA
          </span>
          <h2 className="text-2xl sm:text-3xl md:text-4xl font-extrabold text-[#30264D] mb-3 font-display">
            Veja alguns dos recursos que fazem parte da biblioteca
          </h2>
          <p className="text-sm sm:text-base text-slate-600 leading-relaxed">
            Uma seleção visual para você entender como os materiais são organizados.
          </p>
        </div>

        {/* 6 Grid Cards: [AMOSTRA 01] to [AMOSTRA 06] */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5 sm:gap-6 mb-10 sm:mb-12">
          {SAMPLES_MAIN.map((sample) => (
            <SamplePlaceholderCard 
              key={sample.id} 
              sample={sample} 
              onPreviewClick={onSelectSample}
            />
          ))}
        </div>

        {/* Section CTA */}
        <div className="text-center">
          <button
            onClick={onCtaClick}
            className="w-full sm:w-auto px-8 py-3.5 text-sm sm:text-base font-bold text-white bg-[#6657C8] hover:bg-[#5545B3] rounded-2xl shadow-md hover:shadow-lg transition-all duration-200 cursor-pointer"
          >
            QUERO VER TODOS OS RECURSOS
          </button>
        </div>
      </div>
    </section>
  );
};
