import React from 'react';
import { X, CheckCircle2, FileText, Printer, Download, Sparkles, Layers } from 'lucide-react';
import { SampleItem } from '../types';

interface SamplePreviewModalProps {
  sample: SampleItem | null;
  onClose: () => void;
  onCheckout: () => void;
}

export const SamplePreviewModal: React.FC<SamplePreviewModalProps> = ({
  sample,
  onClose,
  onCheckout,
}) => {
  if (!sample) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-[#30264D]/60 backdrop-blur-xs animate-in fade-in duration-200">
      <div 
        className="bg-white w-full max-w-2xl rounded-2xl md:rounded-3xl border border-[#E9E5F8] shadow-2xl overflow-hidden flex flex-col max-h-[90vh]"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Modal Header */}
        <div className="flex items-center justify-between p-4 sm:p-5 border-b border-slate-100 bg-[#F7F5FC]">
          <div className="flex items-center gap-2">
            <span className="bg-[#6657C8] text-white text-xs font-mono font-bold px-2.5 py-1 rounded">
              [{sample.code}]
            </span>
            <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider">
              {sample.category}
            </span>
          </div>
          <button 
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-white border border-slate-200 text-slate-500 hover:text-slate-900 hover:bg-slate-50 flex items-center justify-center transition-colors"
            aria-label="Fechar modal"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-5 sm:p-6 overflow-y-auto space-y-5">
          {/* Main Title & Description */}
          <div>
            <h3 className="text-xl font-bold text-[#30264D] leading-snug mb-2 font-display">
              {sample.title}
            </h3>
            <p className="text-sm text-slate-600 leading-relaxed">
              {sample.description}
            </p>
          </div>

          {/* Realistic Document Canvas Placeholder */}
          <div className="bg-gradient-to-b from-[#F1EFF9] to-white p-5 rounded-2xl border-2 border-dashed border-[#6657C8]/30 relative">
            <div className="bg-white p-5 rounded-xl border border-[#E9E5F8] shadow-sm space-y-4">
              <div className="flex items-center justify-between border-b border-slate-100 pb-3">
                <div className="flex items-center gap-2.5">
                  <div className="w-8 h-8 rounded-lg bg-[#6657C8]/10 text-[#6657C8] flex items-center justify-center">
                    <FileText className="w-4 h-4" />
                  </div>
                  <div>
                    <div className="text-xs font-bold text-[#30264D]">FICHA TÉCNICA E PRÁTICA</div>
                    <div className="text-[10px] text-slate-400">Padrão A4 • Alta Definição Vetorial</div>
                  </div>
                </div>
                <span className="text-xs font-semibold text-[#36B77A] bg-[#36B77A]/10 px-2 py-0.5 rounded-full flex items-center gap-1">
                  <CheckCircle2 className="w-3.5 h-3.5" />
                  Pronto para imprimir
                </span>
              </div>

              {/* Objectives Breakdown */}
              <div>
                <h4 className="text-xs font-bold text-[#6657C8] uppercase tracking-wider mb-2 flex items-center gap-1.5">
                  <Target className="w-3.5 h-3.5" />
                  Objetivos Principais
                </h4>
                <ul className="space-y-1.5">
                  {sample.objectives.map((obj, i) => (
                    <li key={i} className="text-xs text-slate-700 flex items-start gap-2">
                      <span className="text-[#36B77A] font-bold mt-0.5">✓</span>
                      <span>{obj}</span>
                    </li>
                  ))}
                </ul>
              </div>

              {/* Key Features */}
              <div className="pt-2 border-t border-slate-100">
                <h4 className="text-xs font-bold text-[#30264D] uppercase tracking-wider mb-2 flex items-center gap-1.5">
                  <Layers className="w-3.5 h-3.5 text-[#30264D]" />
                  Especificações do Material
                </h4>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs text-slate-600">
                  {sample.features.map((feat, i) => (
                    <div key={i} className="bg-[#F7F5FC] p-2 rounded-lg border border-slate-100 flex items-center gap-1.5">
                      <div className="w-1.5 h-1.5 rounded-full bg-[#6657C8]" />
                      <span className="truncate">{feat}</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>

          {/* Quick Notice */}
          <div className="bg-[#F7F5FC] rounded-xl p-3 border border-[#E9E5F8] text-xs text-slate-600 flex items-center gap-2">
            <Sparkles className="w-4 h-4 text-[#6657C8] shrink-0" />
            <span>
              Este recurso faz parte do módulo <strong>{sample.category}</strong> e está incluso no acervo completo com +200 recursos em PDF.
            </span>
          </div>
        </div>

        {/* Modal Footer */}
        <div className="p-4 sm:p-5 border-t border-slate-100 bg-[#F7F5FC] flex flex-col sm:flex-row items-center justify-between gap-3">
          <div className="text-xs text-slate-500 text-center sm:text-left">
            Disponível para download imediato em PDF após a adesão.
          </div>
          <div className="flex items-center gap-2 w-full sm:w-auto">
            <button
              onClick={onClose}
              className="flex-1 sm:flex-initial px-4 py-2 text-xs font-semibold text-slate-600 hover:text-slate-900 bg-white border border-slate-200 rounded-xl transition-colors"
            >
              Fechar
            </button>
            <button
              onClick={() => {
                onClose();
                onCheckout();
              }}
              className="flex-1 sm:flex-initial px-5 py-2 text-xs font-bold text-white bg-[#6657C8] hover:bg-[#5545B3] rounded-xl shadow-md transition-colors whitespace-nowrap"
            >
              Quero Acessar Todos os Recursos
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

function Target(props: React.SVGProps<SVGSVGElement>) {
  return (
    <svg
      {...props}
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      <circle cx="12" cy="12" r="10" />
      <circle cx="12" cy="12" r="6" />
      <circle cx="12" cy="12" r="2" />
    </svg>
  );
}
