import React from 'react';

export const HeaderBar: React.FC = () => {
  return (
    <div className="bg-[#30264D] text-white text-[11px] sm:text-xs py-2 px-4 text-center font-medium tracking-wide">
      <div className="max-w-6xl mx-auto flex items-center justify-center gap-2">
        <span className="w-1.5 h-1.5 rounded-full bg-[#36B77A] shrink-0" />
        <span>ACESSO DIGITAL • MATERIAL PARA CONSULTA E IMPRESSÃO</span>
      </div>
    </div>
  );
};
