import React from 'react';
import { BONUSES } from '../data/landingData';
import { BonusMockupCard } from './MockupElements';

export const Bonuses: React.FC = () => {
  return (
    <section className="py-14 sm:py-20 px-4 bg-[#F1EFF9] border-y border-[#E9E5F8]">
      <div className="max-w-6xl mx-auto">
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-10 sm:mb-14">
          <span className="text-xs font-bold text-[#36B77A] uppercase tracking-wider bg-white px-3 py-1 rounded-full border border-[#E9E5F8] mb-3 inline-block">
            MATERIAIS EXCLUSIVOS
          </span>
          <h2 className="text-2xl sm:text-3xl md:text-4xl font-extrabold text-[#30264D] mb-3 font-display">
            Além dos +200 recursos, você também recebe
          </h2>
          <p className="text-sm sm:text-base text-slate-600 leading-relaxed">
            Materiais complementares para aproveitar melhor a biblioteca.
          </p>
        </div>

        {/* 5 Bonus Cards */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-5 gap-5">
          {BONUSES.map((bonus) => (
            <BonusMockupCard
              key={bonus.number}
              number={bonus.number}
              title={bonus.title}
              subtitle={bonus.subtitle}
              description={bonus.description}
              format={bonus.format}
            />
          ))}
        </div>
      </div>
    </section>
  );
};
