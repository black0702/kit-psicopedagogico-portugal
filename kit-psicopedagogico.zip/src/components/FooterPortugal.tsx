import React, { useState } from 'react';
import { ShieldCheck, Mail, FileText, Lock } from 'lucide-react';
import { CHECKOUT_CONFIG } from '../config/checkoutConfig';

export const FooterPortugal: React.FC = () => {
  const [modalContent, setModalContent] = useState<{ title: string; body: string } | null>(null);

  const legalTexts = {
    termos: {
      title: 'Termos e Condições de Utilização',
      body: `1. Objeto e Âmbito
Estes Termos e Condições regem o acesso e a utilização dos materiais e conteúdos digitais disponibilizados através desta página ("Kit Psicopedagógico").

2. Licença de Utilização de Conteúdo Digital
A aquisição de qualquer um dos planos confere ao comprador uma licença individual, pessoal e intransferível de utilização para fins educativos, pedagógicos e profissionais. Não é permitida a revenda, sublicenciamento, cópia não autorizada, partilha pública em redes sociais, servidores públicos ou grupos de mensagens.

3. Caráter Educativo e Limitação de Responsabilidade
Os materiais têm natureza exclusivamente pedagógica, didática e de apoio educativo. A aplicação de instrumentos de diagnóstico clínico formal reserva-se a profissionais legalmente habilitados pelas respetivas entidades reguladoras em Portugal. Os recursos não substituem intervenções médicas ou diagnósticos clínicos formais.

4. Apoio ao Cliente
Para esclarecimento de dúvidas sobre os ficheiros ou suporte ao descarregamento, utilize o e-mail: ${CHECKOUT_CONFIG.supportEmail}.`
    },
    privacidade: {
      title: 'Política de Privacidade e Proteção de Dados (RGPD)',
      body: `1. Enquadramento e Conformidade
Em conformidade com o Regulamento Geral sobre a Proteção de Dados (RGPD - Regulamento UE 2016/679), informamos que os dados pessoais fornecidos (nome e e-mail) destinam-se exclusivamente ao processamento da transação, envio do acesso aos ficheiros digitais adquiridos e comunicação de suporte.

2. Tratamento e Segurança
Os dados não são vendidos nem cedidos a terceiros. As transações de pagamento são processadas por entidades e gateways seguras com encriptação SSL.

3. Direitos do Titular dos Dados
Tem o direito de solicitar a consulta, retificação ou eliminação dos seus dados a qualquer momento, bastando enviar um pedido para ${CHECKOUT_CONFIG.supportEmail}.`
    },
    reembolso: {
      title: 'Política de Reembolso e Livre Resolução',
      body: `1. Direito de Livre Resolução e Garantia de 7 Dias
Oferecemos uma garantia de satisfação de 7 (sete) dias corridos a contar da data da compra. Se considerar que os ficheiros não atendem às suas necessidades pedagógicas, pode solicitar o reembolso total dentro deste prazo.

2. Procedimento de Pedido
Para exercer a garantia, envie uma mensagem para ${CHECKOUT_CONFIG.supportEmail} indicando o endereço de e-mail utilizado na compra. O reembolso será processado pelo mesmo método de pagamento utilizado na transação original.`
    }
  };

  return (
    <footer className="bg-[#0F2D37] text-[#9FB3BA] py-14 px-4 text-xs border-t border-[#1D4B59]">
      <div className="max-w-6xl mx-auto flex flex-col items-center text-center space-y-6">
        
        {/* Identificação do Projeto */}
        <div className="flex items-center gap-2 text-white font-heading font-black text-lg">
          <span>Kit Psicopedagógico Digital</span>
          <span className="text-[#25A69A] text-xs font-normal border border-[#25A69A]/40 px-2 py-0.5 rounded-full">
            Portugal 🇵🇹
          </span>
        </div>

        {/* Informação Legal e Direitos de Autor */}
        <p className="max-w-2xl text-[11px] leading-relaxed text-[#829CA3]">
          Material protegido pela legislação europeia e nacional de direitos de autor e propriedade intelectual. A aquisição confere uma licença de utilização individual e profissional. Conteúdo de natureza pedagógica e complementar que não substitui avaliações ou diagnósticos formais de entidades clínicas especializadas.
        </p>

        {/* Links Legais e Modal */}
        <div className="flex flex-wrap items-center justify-center gap-4 text-xs font-semibold text-white">
          <button 
            onClick={() => setModalContent(legalTexts.termos)}
            className="hover:text-[#25A69A] underline cursor-pointer"
          >
            Termos de Utilização
          </button>
          <span>•</span>
          <button 
            onClick={() => setModalContent(legalTexts.privacidade)}
            className="hover:text-[#25A69A] underline cursor-pointer"
          >
            Privacidade & RGPD
          </button>
          <span>•</span>
          <button 
            onClick={() => setModalContent(legalTexts.reembolso)}
            className="hover:text-[#25A69A] underline cursor-pointer"
          >
            Política de Reembolso (7 Dias)
          </button>
        </div>

        {/* Contacto e Suporte */}
        <div className="pt-4 border-t border-[#1D4B59] w-full max-w-md text-[11px] text-[#7A959D] flex flex-col sm:flex-row items-center justify-between gap-2">
          <span>Contacto de Suporte: <strong>{CHECKOUT_CONFIG.supportEmail}</strong></span>
          <span>© 2026 Todos os direitos reservados.</span>
        </div>

      </div>

      {/* Modal Legal */}
      {modalContent && (
        <div 
          className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4 text-left"
          onClick={() => setModalContent(null)}
        >
          <div 
            className="bg-white text-[#182B35] rounded-3xl max-w-xl w-full p-6 sm:p-8 max-h-[80vh] overflow-y-auto shadow-2xl relative"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center justify-between border-b border-slate-100 pb-3 mb-4">
              <h3 className="font-heading font-black text-lg text-[#123C4A]">
                {modalContent.title}
              </h3>
              <button 
                onClick={() => setModalContent(null)}
                className="w-8 h-8 rounded-full bg-slate-100 hover:bg-slate-200 text-slate-700 flex items-center justify-center text-sm font-bold cursor-pointer"
              >
                ✕
              </button>
            </div>
            <div className="text-xs sm:text-sm text-[#5D737E] leading-relaxed whitespace-pre-line space-y-2">
              {modalContent.body}
            </div>
            <div className="mt-6 pt-4 border-t border-slate-100 text-right">
              <button
                onClick={() => setModalContent(null)}
                className="px-5 py-2 bg-[#123C4A] text-white rounded-full text-xs font-bold hover:bg-[#25A69A] transition-colors cursor-pointer"
              >
                Compreendi
              </button>
            </div>
          </div>
        </div>
      )}
    </footer>
  );
};
