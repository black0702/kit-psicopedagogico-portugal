import React from 'react';
import { CheckCircle2 } from 'lucide-react';

export const AudienceSectionExact: React.FC = () => {
  const list = [
    'Psicopedagogos clínicos ou institucionais',
    'Professores da educação infantil e fundamental',
    'Neuropsicopedagogos',
    'Estudantes de pedagogia e psicopedagogia',
    'Profissionais que trabalham com dificuldades de aprendizagem',
  ];

  return (
    <section className="py-14 sm:py-20 px-4 bg-white">
      <div className="max-w-3xl mx-auto text-center">
        <h2 className="text-2xl sm:text-3xl font-extrabold text-[#30264D] font-display mb-8">
          Para quem é este <span className="text-[#6657C8]">material?</span>
        </h2>

        {/* Caixas Horizontais com Borda e Ícone Verde */}
        <div className="space-y-3 mb-8">
          {list.map((item, idx) => (
            <div
              key={idx}
              className="w-full bg-[#F7F5FC] hover:bg-[#F1EFF9] p-4 rounded-xl border border-[#E9E5F8] text-left flex items-center gap-3 transition-colors"
            >
              <div className="w-5 h-5 rounded-full bg-[#36B77A]/15 text-[#36B77A] flex items-center justify-center shrink-0">
                <CheckCircle2 className="w-4 h-4" />
              </div>
              <span className="text-xs sm:text-sm font-semibold text-[#30264D]">
                {item}
              </span>
            </div>
          ))}
        </div>

        {/* Caixa de Destaque Inferior */}
        <div className="bg-[#F1EFF9] p-4 sm:p-5 rounded-2xl border border-[#E9E5F8] text-xs sm:text-sm text-slate-700 leading-relaxed max-w-2xl mx-auto">
          Se você precisa <strong>avaliar dificuldades de aprendizagem com mais segurança e profissionalismo</strong>, este material foi desenvolvido para facilitar todo o processo avaliativo.
        </div>
      </div>
    </section>
  );
};
