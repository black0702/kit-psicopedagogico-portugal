import React, { useState } from 'react';
import { 
  ChevronLeft, 
  ChevronRight, 
  Sparkles, 
  CheckCircle2, 
  Compass, 
  BookOpen, 
  BrainCircuit, 
  Layers, 
  ArrowRight,
  Maximize2,
  FileText
} from 'lucide-react';
import { SampleItem } from '../types';

interface InteractiveBookPreviewProps {
  onCtaClick: () => void;
  onSelectSample?: (sample: SampleItem) => void;
}

export const InteractiveBookPreview: React.FC<InteractiveBookPreviewProps> = ({
  onCtaClick,
}) => {
  // 5 Páginas Reais do Guia Prático com Imagens de Alta Definição Editorial
  const guidePages = [
    {
      id: 1,
      tag: '01. SUMÁRIO & FLUXO',
      title: 'Sumário & Mapeamento de Etapas',
      badge: 'Visão Geral do Processo',
      imageSrc: '/src/assets/images/guia_sumario_alta_definicao_1790624685007.jpg',
      desc: 'Fluxograma sequencial para conduzir a avaliação da queixa inicial até a devolutiva sem pular etapas.',
      highlights: ['Fluxograma visual guiado', 'Checklist de entrada', 'Divisão por idade'],
    },
    {
      id: 2,
      tag: '02. ANAMNESE INTELIGENTE',
      title: 'Roteiro de Anamnese com a Família',
      badge: 'Entrevista Guiada',
      imageSrc: '/src/assets/images/guia_anamnese_alta_definicao_1790624695209.jpg',
      desc: 'Perguntas estruturadas para mapear marcos de desenvolvimento, rotina de sono e queixas escolares com precisão.',
      highlights: ['Marcos do desenvolvimento', 'Mapeamento de rotina', 'Histórico pedagógico'],
    },
    {
      id: 3,
      tag: '03. MAPAS COGNITIVOS',
      title: 'Mapa Mental de Funções Executivas',
      badge: 'Atenção & Cognição',
      imageSrc: '/src/assets/images/guia_mapa_ptbr_1790625501567.jpg',
      desc: 'Infográfico prático para correlacionar comportamento observado com atenção, memória e flexibilidade cognitiva.',
      highlights: ['Memória operacional', 'Controle inibitório', 'Atenção sustentada'],
    },
    {
      id: 4,
      tag: '04. LEITURA E ESCRITA',
      title: 'Roteiro de Rastreio de Alfabetização',
      badge: 'Sondagem de Linguagem',
      imageSrc: '/src/assets/images/guia_rastreio_alta_definicao_1790624715560.jpg',
      desc: 'Protocolo visual com indicadores de análise fonológica, hipóteses de escrita e análise de erros.',
      highlights: ['Critérios de correção', 'Consciência fonológica', 'Fluência leitora'],
    },
    {
      id: 5,
      tag: '05. DEVOLUTIVA E PLANO',
      title: 'Plano de Intervenção e Devolutiva',
      badge: 'Estruturação Prática',
      imageSrc: '/src/assets/images/guia_plano_alta_definicao_1790624723999.jpg',
      desc: 'Modelo pronto para sintetizar hipóteses levantadas, orientações para a escola e metas terapêuticas semanais.',
      highlights: ['Metas alcançáveis', 'Comunicação com a escola', 'Relatório amigável'],
    },
  ];

  const [activePageIndex, setActivePageIndex] = useState(0);
  const activePage = guidePages[activePageIndex];

  const next = () => setActivePageIndex((prev) => (prev + 1) % guidePages.length);
  const prev = () => setActivePageIndex((prev) => (prev - 1 + guidePages.length) % guidePages.length);

  return (
    <section className="py-14 sm:py-20 px-4 bg-gradient-to-b from-[#F7F5FC] via-white to-[#F7F5FC] border-t border-[#E9E5F8]">
      <div className="max-w-6xl mx-auto">
        
        {/* Bloco Superior: Alinhamento Direto com a Referência Clube de Avaliação */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 sm:gap-12 items-center mb-16">
          
          {/* Imagem do Guia Prático à Esquerda */}
          <div className="lg:col-span-5 flex justify-center">
            <div className="relative w-full max-w-sm">
              <div className="absolute inset-0 bg-[#6657C8]/15 rounded-3xl blur-xl transform -rotate-2" />
              <div className="relative bg-white p-3 rounded-3xl border border-[#E9E5F8] shadow-xl">
                <img
                  src="/src/assets/images/mockup_guia_ptbr_1790625417979.jpg"
                  alt="Guia Prático de Avaliação e Intervenção Psicopedagógica"
                  referrerPolicy="no-referrer"
                  className="w-full h-auto rounded-2xl object-cover"
                />
                <div className="p-3 bg-[#F7F5FC] rounded-xl mt-2 flex items-center justify-between text-xs text-[#30264D] font-medium">
                  <span className="flex items-center gap-1.5 font-bold text-[#6657C8]">
                    <Sparkles className="w-3.5 h-3.5" />
                    Guia Prático Incluso
                  </span>
                  <span className="text-[10px] bg-[#36B77A]/15 text-[#36B77A] px-2 py-0.5 rounded-full font-bold">
                    PDF A4
                  </span>
                </div>
              </div>
            </div>
          </div>

          {/* Texto Explicativo e Mapas Mentais à Direita */}
          <div className="lg:col-span-7 space-y-5 text-left">
            <div>
              <span className="text-xs font-bold text-[#6657C8] uppercase tracking-wider bg-[#E9E5F8] px-3.5 py-1.5 rounded-full inline-block mb-3">
                MATERIAL DE CONSULTA RÁPIDA
              </span>
              <h2 className="text-2xl sm:text-3xl md:text-4xl font-extrabold text-[#30264D] font-display leading-tight">
                Além da Apostila, você recebe um Guia Prático para consultar durante suas avaliações
              </h2>
              <p className="text-xs sm:text-sm font-semibold text-[#6657C8] mt-1">
                Guia Prático da Avaliação Psicopedagógica 2026 • Da Queixa ao Plano de Intervenção
              </p>
            </div>

            <p className="text-sm sm:text-base text-slate-600 leading-relaxed">
              <strong>Um mapa para saber o que observar, investigar e fazer a seguir.</strong> Enquanto a Apostila reúne os instrumentos e protocolos, o Guia Prático ajuda você a visualizar o caminho com mais segurança e agilidade.
            </p>

            {/* Checklist de Recursos Visuais */}
            <div className="space-y-2.5">
              {[
                'Organize a avaliação da queixa à devolutiva sem perder etapas.',
                'Saiba quais áreas precisam ser investigadas em cada perfil.',
                'Consulte mapas de leitura, escrita, cálculo e funções cognitivas.',
                'Entenda os sinais e manifestações mais comuns em sala e consultório.',
                'Organize hipóteses pedagógicas com clareza antes da devolutiva.',
                'Transforme os achados em um plano de intervenção aplicável.',
              ].map((text, i) => (
                <div key={i} className="flex items-start gap-2.5 text-xs sm:text-sm text-[#30264D]">
                  <span className="text-[#36B77A] font-bold mt-0.5">✓</span>
                  <span>{text}</span>
                </div>
              ))}
            </div>

            <div className="bg-[#F1EFF9] p-4 rounded-2xl border border-[#E9E5F8] text-xs text-slate-700">
              <span className="font-bold text-[#6657C8] uppercase tracking-wider text-[11px] block mb-1">
                NA PRÁTICA:
              </span>
              <strong>Apostila Completa:</strong> +50 testes sistematizados e protocolos de avaliação em PDF. <br />
              <strong>Guia Prático:</strong> visão geral, fluxogramas organizados e consulta rápida na mesa.
            </div>

            <div>
              <button
                onClick={onCtaClick}
                className="w-full sm:w-auto px-7 py-3.5 bg-[#6657C8] hover:bg-[#5545B3] text-white font-bold text-sm rounded-xl shadow-md transition-all cursor-pointer flex items-center justify-center gap-2"
              >
                <span>QUERO ACESSAR O MATERIAL COMPLETO</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          </div>

        </div>

        {/* Bloco Interativo: Veja algumas páginas do Guia Prático por dentro (COM IMAGENS REAIS E VISUALIZADOR) */}
        <div className="bg-white rounded-3xl p-6 sm:p-10 border border-[#E9E5F8] shadow-xl text-center">
          <div className="max-w-2xl mx-auto mb-8">
            <span className="text-xs font-bold text-[#6657C8] uppercase tracking-wider bg-[#E9E5F8] px-3.5 py-1.5 rounded-full inline-block mb-2">
              PÁGINAS ILUSTRADAS
            </span>
            <h3 className="text-2xl sm:text-3xl font-extrabold text-[#30264D] font-display">
              Veja algumas páginas do Guia Prático por dentro
            </h3>
            <p className="text-xs sm:text-sm text-slate-500 mt-1">
              Arraste ou clique nas páginas abaixo para visualizar as ilustrações, fluxogramas e tabelas prontas para consulta.
            </p>
          </div>

          {/* Display Principal Interativo com Imagem Real da Página do Guia */}
          <div className="max-w-4xl mx-auto bg-gradient-to-br from-[#F7F5FC] to-[#F1EFF9] rounded-2xl p-4 sm:p-8 border border-[#E9E5F8] relative mb-8">
            <div className="grid grid-cols-1 md:grid-cols-12 gap-6 items-center">
              
              {/* Imagem Real da Página do Guia Prático com Acabamento Editorial */}
              <div className="md:col-span-6 flex justify-center">
                <div className="relative w-full max-w-xs sm:max-w-sm bg-white p-3 rounded-2xl shadow-2xl border border-slate-200/90 group transition-all duration-300 hover:shadow-purple-500/10">
                  <div className="overflow-hidden rounded-xl bg-white shadow-inner border border-slate-100 relative">
                    <img
                      src={activePage.imageSrc}
                      alt={activePage.title}
                      referrerPolicy="no-referrer"
                      className="w-full h-auto object-cover transform group-hover:scale-105 transition-transform duration-500"
                    />
                    
                    {/* Badge sutil sobreposto */}
                    <div className="absolute top-2.5 right-2.5 bg-white/95 backdrop-blur-xs text-[#30264D] text-[10px] font-bold px-2 py-0.5 rounded-md shadow-xs border border-slate-200 flex items-center gap-1">
                      <span className="w-1.5 h-1.5 rounded-full bg-[#6657C8]" />
                      Página do Guia Prático
                    </div>
                  </div>

                  <div className="mt-2.5 text-center text-[10px] text-slate-500 font-medium flex items-center justify-center gap-1.5">
                    <CheckCircle2 className="w-3.5 h-3.5 text-[#36B77A]" />
                    Padrão Editorial de Impressão • Formato A4
                  </div>
                </div>
              </div>

              {/* Informações da Página Ativa */}
              <div className="md:col-span-6 text-left space-y-4">
                <div className="flex items-center justify-between pb-2 border-b border-slate-200">
                  <span className="bg-[#6657C8] text-white text-[10px] font-bold px-3 py-1 rounded-full uppercase tracking-wider">
                    {activePage.tag}
                  </span>
                  <span className="text-xs text-slate-400 font-medium">
                    Página 0{activePageIndex + 1} de 0{guidePages.length}
                  </span>
                </div>

                <div>
                  <span className="text-xs font-bold text-[#36B77A] uppercase tracking-wider block mb-1">
                    {activePage.badge}
                  </span>
                  <h4 className="text-xl font-bold text-[#30264D] leading-snug font-display">
                    {activePage.title}
                  </h4>
                </div>

                <p className="text-xs sm:text-sm text-slate-600 leading-relaxed">
                  {activePage.desc}
                </p>

                {/* Bullets de destaque visual */}
                <div className="space-y-1.5 pt-2 border-t border-slate-200 text-xs">
                  {activePage.highlights.map((h, i) => (
                    <div key={i} className="flex items-center gap-2 text-slate-700">
                      <span className="text-[#36B77A] font-bold">✓</span>
                      <span>{h}</span>
                    </div>
                  ))}
                </div>

                <div className="pt-2">
                  <button
                    onClick={onCtaClick}
                    className="w-full sm:w-auto px-6 py-2.5 bg-[#6657C8] hover:bg-[#5545B3] text-white font-bold text-xs rounded-xl shadow-md transition-colors cursor-pointer"
                  >
                    Quero Acessar o Guia Completo
                  </button>
                </div>
              </div>

            </div>

            {/* Setas Laterais de Navegação */}
            <button
              onClick={prev}
              aria-label="Página anterior"
              className="absolute left-1 sm:left-3 top-1/2 -translate-y-1/2 w-9 h-9 rounded-full bg-white shadow-md border border-slate-200 text-slate-700 hover:text-[#6657C8] hover:bg-slate-50 flex items-center justify-center cursor-pointer transition-colors"
            >
              <ChevronLeft className="w-5 h-5" />
            </button>
            <button
              onClick={next}
              aria-label="Próxima página"
              className="absolute right-1 sm:right-3 top-1/2 -translate-y-1/2 w-9 h-9 rounded-full bg-white shadow-md border border-slate-200 text-slate-700 hover:text-[#6657C8] hover:bg-slate-50 flex items-center justify-center cursor-pointer transition-colors"
            >
              <ChevronRight className="w-5 h-5" />
            </button>
          </div>

          {/* Miniaturas Visuais das 5 Páginas em Grade (com imagens Reais) */}
          <div className="grid grid-cols-2 sm:grid-cols-5 gap-3 max-w-4xl mx-auto mb-10">
            {guidePages.map((page, idx) => (
              <div
                key={page.id}
                onClick={() => setActivePageIndex(idx)}
                className={`p-2 rounded-2xl border transition-all duration-200 cursor-pointer text-left flex flex-col justify-between ${
                  activePageIndex === idx
                    ? 'bg-[#F7F5FC] border-[#6657C8] shadow-md scale-102 ring-2 ring-[#6657C8]/20'
                    : 'bg-white border-slate-200 hover:border-[#6657C8]/50 hover:shadow-xs'
                }`}
              >
                <div className="aspect-[3/4] overflow-hidden rounded-xl bg-slate-100 mb-2 border border-slate-100">
                  <img
                    src={page.imageSrc}
                    alt={page.title}
                    referrerPolicy="no-referrer"
                    className="w-full h-full object-cover"
                  />
                </div>
                <div>
                  <span className="text-[9px] font-bold text-[#6657C8] uppercase block truncate">
                    {page.tag}
                  </span>
                  <span className="text-[11px] font-semibold text-[#30264D] line-clamp-1">
                    {page.title}
                  </span>
                </div>
              </div>
            ))}
          </div>

          {/* Grade com os 8 Mapas Práticos (Idêntico ao Clube de Avaliação) */}
          <div className="pt-8 border-t border-slate-100">
            <h4 className="text-sm font-bold text-[#30264D] uppercase tracking-wider mb-4">
              Alguns dos mapas que você terá em mãos
            </h4>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
              {[
                { label: 'Funções Executivas', icon: BrainCircuit },
                { label: 'Leitura', icon: BookOpen },
                { label: 'Escrita', icon: FileText },
                { label: 'Matemática', icon: Compass },
                { label: 'TEA', icon: Sparkles },
                { label: 'TDAH', icon: Layers },
                { label: 'Hipóteses', icon: CheckCircle2 },
                { label: 'Plano de Intervenção', icon: ArrowRight },
              ].map((mapItem, idx) => {
                const Icon = mapItem.icon;
                return (
                  <div
                    key={idx}
                    className="p-3 bg-[#F7F5FC] hover:bg-[#F1EFF9] rounded-xl border border-[#E9E5F8] text-center transition-colors flex flex-col items-center justify-center gap-1.5"
                  >
                    <div className="w-7 h-7 rounded-lg bg-white text-[#6657C8] flex items-center justify-center shadow-2xs">
                      <Icon className="w-4 h-4" />
                    </div>
                    <span className="text-xs font-semibold text-[#30264D]">
                      {mapItem.label}
                    </span>
                  </div>
                );
              })}
            </div>
            <p className="text-[11px] text-slate-400 mt-3">
              + diversos outros mapas, fluxos e checklists.
            </p>
          </div>

        </div>

      </div>
    </section>
  );
};
