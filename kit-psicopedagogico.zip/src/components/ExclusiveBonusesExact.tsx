import React from 'react';
import { Sparkles, FolderDown, FileText, CheckCircle2 } from 'lucide-react';

export const ExclusiveBonusesExact: React.FC = () => {
  return (
    <section className="py-14 sm:py-20 px-4 bg-white">
      <div className="max-w-4xl mx-auto text-center">
        
        {/* Header da seção */}
        <div className="mb-12">
          <span className="text-2xl sm:text-3xl font-extrabold text-[#30264D] font-display flex items-center justify-center gap-2">
            <span>🎁</span> Você leva bônus exclusivos
          </span>
          <p className="text-xs sm:text-sm text-slate-500 mt-2 max-w-lg mx-auto">
            Ao adquirir o material hoje, você também poderá receber materiais extras que irão complementar suas avaliações e intervenções psicopedagógicas.
          </p>
        </div>

        {/* BÔNUS 1: Sistema Completo de Aprendizagem - Drive Profissional */}
        <div className="bg-[#F7F5FC] rounded-3xl p-6 sm:p-10 border border-[#E9E5F8] shadow-sm mb-12 text-left">
          <div className="text-center mb-6">
            <span className="text-[11px] font-bold text-[#6657C8] uppercase tracking-wider bg-[#E9E5F8] px-3 py-1 rounded-full">
              BÔNUS 1
            </span>
            <h3 className="text-xl sm:text-2xl font-extrabold text-[#30264D] mt-2 font-display">
              Sistema Completo de Aprendizagem — Drive Profissional
            </h3>
            <p className="text-xs text-slate-500 mt-1">
              Um drive online com instrumentos profissionais para avaliação, diagnóstico e intervenção psicopedagógica.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-12 gap-8 items-center">
            {/* Mockup do Drive */}
            <div className="md:col-span-5 flex justify-center">
              <div className="bg-white p-3 rounded-2xl border border-slate-200 shadow-md max-w-xs">
                <img
                  src="/src/assets/images/bonus1_drive_prof_1790622309731.jpg"
                  alt="Sistema Completo de Aprendizagem - Drive Profissional"
                  referrerPolicy="no-referrer"
                  className="w-full h-auto rounded-xl object-cover"
                />
              </div>
            </div>

            {/* Lista dos 4 Pilares do Drive */}
            <div className="md:col-span-7 space-y-3">
              <div className="text-xs font-bold text-[#30264D] flex items-center gap-1.5 pb-2 border-b border-slate-200">
                <Sparkles className="w-4 h-4 text-[#36B77A]" />
                Tudo o que você vai receber nesse combo completo:
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-[11px]">
                <div className="bg-white p-3 rounded-xl border border-slate-100">
                  <span className="font-bold text-[#6657C8] block mb-1">Rastreio e Triagem Clínica</span>
                  <ul className="text-slate-600 space-y-0.5">
                    <li>• Dislexia e Disgrafia</li>
                    <li>• Discalculia e TDAH</li>
                    <li>• Escalas e protocolos de observação</li>
                  </ul>
                </div>

                <div className="bg-white p-3 rounded-xl border border-slate-100">
                  <span className="font-bold text-[#6657C8] block mb-1">Avaliação Psicopedagógica</span>
                  <ul className="text-slate-600 space-y-0.5">
                    <li>• Fichas psicomotoras</li>
                    <li>• Escalas de leitura e escrita</li>
                    <li>• Reconhecimento de padrões</li>
                  </ul>
                </div>

                <div className="bg-white p-3 rounded-xl border border-slate-100">
                  <span className="font-bold text-[#6657C8] block mb-1">Documentação Editável</span>
                  <ul className="text-slate-600 space-y-0.5">
                    <li>• Modelos de relatórios em Word</li>
                    <li>• Fichas de anamnese</li>
                    <li>• Contratos de atendimento</li>
                  </ul>
                </div>

                <div className="bg-white p-3 rounded-xl border border-slate-100">
                  <span className="font-bold text-[#6657C8] block mb-1">Intervenção e Apoio</span>
                  <ul className="text-slate-600 space-y-0.5">
                    <li>• Estratégias e exercícios direcionados</li>
                    <li>• Pranchas de apoio terapêutico</li>
                    <li>• Orientações para pais e escola</li>
                  </ul>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* BÔNUS 2: 1500 Atividades Infantis em PDF */}
        <div className="bg-[#F7F5FC] rounded-3xl p-6 sm:p-10 border border-[#E9E5F8] shadow-sm mb-12 text-left">
          <div className="text-center mb-6">
            <span className="text-[11px] font-bold text-[#36B77A] uppercase tracking-wider bg-[#36B77A]/10 px-3 py-1 rounded-full">
              BÔNUS 2
            </span>
            <h3 className="text-xl sm:text-2xl font-extrabold text-[#30264D] mt-2 font-display">
              1500 Atividades Infantis em PDF
            </h3>
            <p className="text-xs text-slate-500 mt-1">
              Uma coleção completa de atividades pedagógicas para estimular o aprendizado.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-12 gap-8 items-center">
            {/* Mockup das 1500 Atividades */}
            <div className="md:col-span-5 flex justify-center">
              <div className="bg-white p-3 rounded-2xl border border-slate-200 shadow-md max-w-xs">
                <img
                  src="/src/assets/images/bonus2_1500_atividades_1790622323916.jpg"
                  alt="1500 Atividades Infantis em PDF"
                  referrerPolicy="no-referrer"
                  className="w-full h-auto rounded-xl object-cover"
                />
              </div>
            </div>

            <div className="md:col-span-7 space-y-3">
              <div className="flex flex-wrap gap-2">
                {[
                  'Linguagem',
                  'Raciocínio Lógico',
                  'Alfabetização',
                  'Coordenação Motora',
                  'Habilidades Cognitivas',
                ].map((tag, i) => (
                  <span
                    key={i}
                    className="bg-white px-3 py-1 rounded-lg border border-slate-200 text-xs font-semibold text-[#30264D] flex items-center gap-1.5"
                  >
                    <CheckCircle2 className="w-3.5 h-3.5 text-[#36B77A]" />
                    {tag}
                  </span>
                ))}
              </div>
              <p className="text-xs sm:text-sm text-slate-600 leading-relaxed pt-2">
                Ideal para complementar sessões, tarefas de casa estruturadas e reforço de habilidades básicas em crianças da Educação Infantil e Anos Iniciais.
              </p>
            </div>
          </div>
        </div>

        {/* 3 SUPER BÔNUS EXCLUSIVOS (3 Cards Amarelos/Dourados lado a lado) */}
        <div>
          <div className="mb-6">
            <h4 className="text-lg font-extrabold text-[#30264D] flex items-center justify-center gap-1.5 font-display">
              <span>🎁</span> VOCÊ LEVA 03 SUPER BÔNUS EXCLUSIVOS
            </h4>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-left">
            {[
              {
                title: 'Foco e Concentração no Autismo: 20 Estratégias Comprovadas',
                desc: 'Técnicas práticas para apoiar crianças com TEA a manter o foco e lidar com momentos de crise.',
                priceBefore: 'De R$ 67',
                now: 'HOJE: GRÁTIS',
              },
              {
                title: 'Guia Zero Comportamentos Críticos no Autismo',
                desc: 'Orientações claras para prever e lidar com comportamentos desafiadores no dia a dia da criança.',
                priceBefore: 'De R$ 87',
                now: 'HOJE: GRÁTIS',
              },
              {
                title: 'Manual Prático do Autismo para Pais e Profissionais',
                desc: 'Entenda os principais sinais do TEA e saiba como estimular o desenvolvimento com mais segurança e empatia.',
                priceBefore: 'De R$ 97',
                now: 'HOJE: GRÁTIS',
              },
            ].map((bonus, i) => (
              <div
                key={i}
                className="bg-gradient-to-b from-[#FFFDF5] to-white p-5 rounded-2xl border border-amber-200 shadow-xs flex flex-col justify-between"
              >
                <div>
                  <span className="text-[10px] font-bold text-amber-700 bg-amber-100 px-2 py-0.5 rounded uppercase">
                    SUPER BÔNUS 0{i + 1}
                  </span>
                  <h5 className="font-bold text-xs sm:text-sm text-[#30264D] mt-2 mb-1.5 leading-snug">
                    {bonus.title}
                  </h5>
                  <p className="text-[11px] text-slate-500 leading-relaxed">
                    {bonus.desc}
                  </p>
                </div>

                <div className="mt-4 pt-2 border-t border-amber-100 flex items-center justify-between text-[11px]">
                  <span className="text-slate-400 line-through">{bonus.priceBefore}</span>
                  <span className="font-extrabold text-[#36B77A]">{bonus.now}</span>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Bloco "Com este material você poderá" */}
        <div className="mt-14 max-w-2xl mx-auto bg-[#F7F5FC] p-6 rounded-3xl border border-[#E9E5F8] text-left">
          <h4 className="text-base sm:text-lg font-bold text-[#30264D] text-center mb-4">
            Com este material você <span className="text-[#6657C8]">poderá:</span>
          </h4>
          <div className="space-y-2.5 text-xs sm:text-sm text-slate-700">
            {[
              'Aplicar avaliações psicopedagógicas com mais segurança',
              'Identificar dificuldades de aprendizagem com mais clareza',
              'Utilizar instrumentos profissionais de avaliação',
              'Economizar horas de preparação de material',
              'Ter materiais organizados para atendimento clínico ou escolar',
            ].map((text, i) => (
              <div key={i} className="flex items-center gap-2.5">
                <span className="w-4 h-4 rounded-full bg-[#36B77A]/15 text-[#36B77A] flex items-center justify-center shrink-0">
                  ✓
                </span>
                <span>{text}</span>
              </div>
            ))}
          </div>
        </div>

      </div>
    </section>
  );
};
