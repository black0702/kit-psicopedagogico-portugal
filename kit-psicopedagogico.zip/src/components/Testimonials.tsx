import React from 'react';
import { MessageSquareText } from 'lucide-react';

export const Testimonials: React.FC = () => {
  return (
    <section className="py-14 sm:py-18 px-4 bg-[#F1EFF9] border-y border-[#E9E5F8]">
      <div className="max-w-5xl mx-auto">
        {/* Section Header */}
        <div className="text-center max-w-2xl mx-auto mb-8 sm:mb-10">
          <span className="text-xs font-bold text-slate-500 uppercase tracking-wider bg-white px-3 py-1 rounded-full border border-[#E9E5F8] mb-3 inline-block">
            AVALIAÇÕES E DEPOIMENTOS
          </span>
          <h2 className="text-xl sm:text-2xl font-bold text-[#30264D] mb-2 font-display">
            Experiências de Profissionais
          </h2>
          <p className="text-xs sm:text-sm text-slate-500">
            Espaço reservado exclusivamente para relatos e retornos reais de quem utiliza a biblioteca na prática.
          </p>
        </div>

        {/* 3 Honest Placeholders */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 sm:gap-6">
          {['01', '02', '03'].map((num) => (
            <div
              key={num}
              className="bg-white rounded-2xl p-5 border border-dashed border-[#C8C1EC] text-center flex flex-col justify-center items-center min-h-[160px]"
            >
              <div className="w-10 h-10 rounded-full bg-[#F7F5FC] text-[#6657C8] flex items-center justify-center mb-3">
                <MessageSquareText className="w-5 h-5 opacity-60" />
              </div>
              <span className="font-mono text-xs font-bold text-[#6657C8] mb-1">
                [DEPOIMENTO REAL {num}]
              </span>
              <p className="text-[11px] text-slate-400 max-w-xs">
                Depoimentos reais de psicopedagogos serão adicionados aqui conforme autorização dos profissionais.
              </p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};
