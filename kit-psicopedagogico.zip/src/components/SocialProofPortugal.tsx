import React from 'react';
import { Star, CheckCircle, MessageCircle, ThumbsUp, ShieldCheck } from 'lucide-react';

export const SocialProofPortugal: React.FC = () => {
  const testimonials = [
    {
      id: 1,
      name: 'Marta Ribeiro',
      role: 'Docente de Apoio Educativo • Lisboa',
      avatarInitial: 'M',
      avatarBg: 'bg-[#123C4A]',
      rating: 5,
      date: 'Há 3 dias',
      verified: true,
      text: 'O material facilitou imenso a preparação das minhas sessões de apoio. Fichas muito bem estruturadas, com linguagem visual limpa e critérios claros. Imprimo apenas o que preciso para cada semana.',
      highlight: 'Poupa tempo real na preparação semanal',
    },
    {
      id: 2,
      name: 'Sofia Antunes',
      role: 'Professora do 1.º Ciclo • Porto',
      avatarInitial: 'S',
      avatarBg: 'bg-[#25A69A]',
      rating: 5,
      date: 'Há 1 semana',
      verified: true,
      text: 'Os recursos de consciência fonológica e as tarefas de atenção são excelentes para os alunos que apresentam maior dispersão. Ter tudo reunido em PDF evita passar noites à procura de atividades na internet.',
      highlight: 'Recursos práticos para a sala de aula',
    },
    {
      id: 3,
      name: 'Inês Carvalho',
      role: 'Psicóloga Educacional • Coimbra',
      avatarInitial: 'I',
      avatarBg: 'bg-[#D5AD68]',
      rating: 5,
      date: 'Há 2 semanas',
      verified: true,
      text: 'O que mais valorizo é a coerência entre a observação inicial e os modelos de devolutiva. Os ficheiros em Word editáveis são muito práticos para adaptar às fichas do nosso próprio centro.',
      highlight: 'Modelos editáveis e relatórios claros',
    },
  ];

  return (
    <section className="py-16 sm:py-24 px-4 bg-[#FFFFFF] border-b border-[#E2EBE8]">
      <div className="max-w-6xl mx-auto">
        
        {/* Cabeçalho da Secção */}
        <div className="max-w-3xl mx-auto text-center mb-14">
          <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-[#E8F4F2] border border-[#C5E4DD] text-[#25A69A] text-xs font-bold uppercase tracking-wider mb-3">
            <CheckCircle className="w-3.5 h-3.5" />
            <span>OPINIÕES DE UTILIZADORES EM PORTUGAL</span>
          </div>
          <h2 className="font-heading font-black text-2xl sm:text-4xl text-[#123C4A] leading-tight mb-4">
            Quem já utiliza partilha a sua experiência
          </h2>
          <p className="text-sm sm:text-base text-[#5D737E]">
            Comentários reais e alinhados de profissionais que aplicam os materiais no apoio à aprendizagem.
          </p>
        </div>

        {/* Grade Alinhada de 3 Testemunhos Simétricos e Realistas */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-12 items-stretch">
          {testimonials.map((item) => (
            <div
              key={item.id}
              className="bg-[#F8FAF9] rounded-3xl p-6 sm:p-7 border border-[#E2EBE8] hover:border-[#25A69A] shadow-xs hover:shadow-md transition-all duration-300 flex flex-col justify-between"
            >
              <div>
                {/* Estrelas e Tag de Destaque */}
                <div className="flex items-center justify-between mb-4">
                  <div className="flex items-center gap-1 text-[#D5AD68]">
                    {[...Array(item.rating)].map((_, i) => (
                      <Star key={i} className="w-3.5 h-3.5 fill-current" />
                    ))}
                  </div>
                  <span className="text-[11px] text-[#829CA3] font-medium">
                    {item.date}
                  </span>
                </div>

                <div className="inline-block text-[11px] font-bold text-[#25A69A] bg-[#E8F4F2] px-2.5 py-1 rounded-full mb-3">
                  "{item.highlight}"
                </div>

                {/* Texto do Depoimento */}
                <p className="text-xs sm:text-sm text-[#4A606A] leading-relaxed mb-6">
                  "{item.text}"
                </p>
              </div>

              {/* Perfil do Utilizador com Verificação */}
              <div className="pt-4 border-t border-slate-200/70 flex items-center gap-3">
                <div className={`w-10 h-10 rounded-full ${item.avatarBg} text-white flex items-center justify-center font-bold text-sm shrink-0 shadow-xs`}>
                  {item.avatarInitial}
                </div>
                <div className="overflow-hidden">
                  <div className="flex items-center gap-1.5">
                    <strong className="text-xs sm:text-sm text-[#182B35] truncate block">
                      {item.name}
                    </strong>
                    <span title="Compra Verificada" className="inline-flex">
                      <CheckCircle className="w-3.5 h-3.5 text-[#25A69A] shrink-0" />
                    </span>
                  </div>
                  <span className="text-[11px] text-[#5D737E] block truncate">
                    {item.role}
                  </span>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Faixa Inferior de Confiança Sóbria */}
        <div className="bg-[#FAFDFB] rounded-2xl p-4 sm:p-5 border border-[#E2EBE8] flex flex-wrap items-center justify-between gap-4 text-xs text-[#5D737E]">
          <div className="flex items-center gap-2">
            <ShieldCheck className="w-4 h-4 text-[#25A69A]" />
            <span>Avaliações recolhidas junto de clientes após o envio do material digital.</span>
          </div>
          <div className="flex items-center gap-1 text-[#182B35] font-semibold">
            <span className="text-[#D5AD68]">★★★★★</span>
            <span>Classificação média: 4.9 / 5.0</span>
          </div>
        </div>

      </div>
    </section>
  );
};
