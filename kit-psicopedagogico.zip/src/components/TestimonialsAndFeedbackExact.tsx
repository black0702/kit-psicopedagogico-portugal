import React, { useState } from 'react';
import { Star, ChevronLeft, ChevronRight, CheckCircle2 } from 'lucide-react';

export const TestimonialsAndFeedbackExact: React.FC = () => {
  const reviews = [
    {
      stars: 5,
      text: 'Esse material salvou meus atendimentos! Os testes são super organizados e prontos para usar. Recomendo demais para quem quer agilidade no diagnóstico.',
      author: 'Luciana M.',
      role: 'Psicopedagoga Clínica',
    },
    {
      text: 'Eu não imaginava que existia um material tão completo assim. As fichas de acompanhamento e os modelos de devolutiva me poupam horas de trabalho.',
      author: 'Carla S.',
      role: 'Professora do Fundamental',
    },
    {
      text: 'O combo com o drive profissional é incrível! Tenho instrumentos para dislexia, TDAH, discalculia — tudo num só lugar. Vale cada centavo.',
      author: 'Juliana C.',
      role: 'Neuropsicopedagoga',
    },
  ];

  return (
    <section className="py-14 sm:py-20 px-4 bg-white border-t border-slate-100">
      <div className="max-w-4xl mx-auto text-center">
        
        {/* Bloco 1: O que nossos membros dizem (3 Cards) */}
        <div className="mb-16">
          <h3 className="text-xl sm:text-2xl font-extrabold text-[#30264D] font-display mb-8">
            O que nossos <span className="text-[#6657C8]">membros dizem</span>
          </h3>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-left">
            {reviews.map((rev, i) => (
              <div
                key={i}
                className="bg-[#F7F5FC] p-5 rounded-2xl border border-[#E9E5F8] flex flex-col justify-between"
              >
                <div>
                  <div className="flex gap-1 text-amber-400 mb-3">
                    {[...Array(5)].map((_, s) => (
                      <Star key={s} className="w-3.5 h-3.5 fill-current" />
                    ))}
                  </div>
                  <p className="text-xs text-slate-600 leading-relaxed italic">
                    "{rev.text}"
                  </p>
                </div>

                <div className="mt-4 pt-3 border-t border-slate-200/60 flex items-center gap-2">
                  <div className="w-7 h-7 rounded-full bg-[#6657C8] text-white text-[11px] font-bold flex items-center justify-center">
                    {rev.author[0]}
                  </div>
                  <div>
                    <h5 className="text-xs font-bold text-[#30264D]">{rev.author}</h5>
                    <span className="text-[10px] text-slate-400 block">{rev.role}</span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Bloco 2: Feedbacks reais de clientes (Print de WhatsApp no Centro) */}
        <div>
          <h3 className="text-xl sm:text-2xl font-extrabold text-[#30264D] font-display mb-2">
            Feedbacks <span className="text-[#36B77A]">reais de clientes</span>
          </h3>
          <p className="text-xs text-slate-400 mb-8">
            Comentários e mensagens espontâneas enviadas por profissionais que já usam o material.
          </p>

          <div className="max-w-xs sm:max-w-sm mx-auto bg-white rounded-3xl p-3 border border-[#E9E5F8] shadow-2xl">
            <img
              src="/src/assets/images/whatsapp_ptbr_1790625523605.jpg"
              alt="Feedback real de cliente no WhatsApp em português"
              referrerPolicy="no-referrer"
              className="w-full h-auto rounded-2xl object-cover"
            />
          </div>
        </div>

      </div>
    </section>
  );
};
