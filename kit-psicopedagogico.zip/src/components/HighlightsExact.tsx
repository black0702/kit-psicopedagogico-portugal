import React from 'react';
import { FileText, BookOpen, Users } from 'lucide-react';

export const HighlightsExact: React.FC = () => {
  return (
    <section className="py-12 sm:py-16 px-4 bg-white border-b border-slate-100">
      <div className="max-w-4xl mx-auto text-center">
        <h3 className="text-xl sm:text-2xl font-extrabold text-[#30264D] font-display mb-10">
          Destaques da <span className="text-[#6657C8]">Apostila</span>
        </h3>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 text-center">
          {/* Card 1 */}
          <div className="p-6 rounded-2xl bg-[#F7F5FC] border border-[#E9E5F8]">
            <div className="w-10 h-10 rounded-xl bg-white text-[#6657C8] shadow-xs flex items-center justify-center mx-auto mb-3">
              <FileText className="w-5 h-5" />
            </div>
            <h4 className="text-sm font-bold text-[#30264D] mb-1">Formato Digital</h4>
            <p className="text-xs text-slate-500 leading-relaxed">
              Apostila completa em formato PDF • Tamanho: 137 páginas. Material enviado por e-mail e disponível imediatamente após a compra. Pode ser impresso quantas vezes desejar.
            </p>
          </div>

          {/* Card 2 */}
          <div className="p-6 rounded-2xl bg-[#F7F5FC] border border-[#E9E5F8]">
            <div className="w-10 h-10 rounded-xl bg-white text-[#6657C8] shadow-xs flex items-center justify-center mx-auto mb-3">
              <BookOpen className="w-5 h-5" />
            </div>
            <h4 className="text-sm font-bold text-[#30264D] mb-1">Conteúdo Teórico e Prático</h4>
            <p className="text-xs text-slate-500 leading-relaxed">
              Material estruturado para aprofundar e emitir triagem clínica: Dislexia, Disgrafia, Discalculia, TEA e TDAH relacionados a dificuldades como discalculia e disortografia.
            </p>
          </div>

          {/* Card 3 */}
          <div className="p-6 rounded-2xl bg-[#F7F5FC] border border-[#E9E5F8]">
            <div className="w-10 h-10 rounded-xl bg-white text-[#6657C8] shadow-xs flex items-center justify-center mx-auto mb-3">
              <Users className="w-5 h-5" />
            </div>
            <h4 className="text-sm font-bold text-[#30264D] mb-1">Material Utilizado por Profissionais</h4>
            <p className="text-xs text-slate-500 leading-relaxed">
              Este material já é utilizado por mais de 500 profissionais da área educacional e clínica em todo o Brasil.
            </p>
          </div>
        </div>
      </div>
    </section>
  );
};
