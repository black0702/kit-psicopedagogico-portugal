import React from 'react';
import { Check, X, ShieldCheck, ArrowRight, Zap, CreditCard, Sparkles } from 'lucide-react';
import { CHECKOUT_CONFIG } from '../config/checkoutConfig';
import { trackPixelEvent, buildCheckoutUrlWithUtms } from '../utils/pixelTracker';

export const PricingPlansPortugal: React.FC = () => {
  const { basico, combo } = CHECKOUT_CONFIG.plans;

  const handleCheckoutClick = (planName: string, url: string, value: number) => {
    trackPixelEvent('InitiateCheckout', {
      content_name: planName,
      value: value,
      currency: 'EUR',
    });
    window.location.href = buildCheckoutUrlWithUtms(url);
  };

  return (
    <section id="planos" className="py-16 sm:py-24 px-4 bg-[#FAF6EE] border-t border-[#E8E1D3]">
      <div className="max-w-6xl mx-auto">
        
        {/* Título da Oferta */}
        <div className="max-w-3xl mx-auto text-center mb-14">
          <span className="text-xs font-bold text-[#D5AD68] uppercase tracking-wider bg-[#FBF7EE] px-3.5 py-1.5 rounded-full inline-block mb-3 border border-[#F3E7D0]">
            PAGAMENTO ÚNICO EM EUROS
          </span>
          <h2 className="font-heading font-black text-2xl sm:text-4xl text-[#123C4A] leading-tight mb-4">
            Escolha o plano ideal para a sua prática educativa
          </h2>
          <p className="text-sm sm:text-base text-[#5D737E]">
            Acesso digital imediato. Sem mensalidades, sem renovações automáticas, sem custos surpresa.
          </p>
        </div>

        {/* Comparação dos Planos (Low Ticket Hipóteses: 4,90 € e 9,90 €) */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-stretch max-w-5xl mx-auto">
          
          {/* Plano Básico: €4,90 */}
          <div className="lg:col-span-5 bg-white rounded-3xl p-6 sm:p-8 border border-[#E2EBE8] shadow-xs flex flex-col justify-between">
            <div>
              <div className="flex items-center justify-between mb-4">
                <span className="text-xs font-bold uppercase tracking-wider text-[#5D737E] bg-[#F0F4F2] px-3 py-1 rounded-full">
                  {basico.badge}
                </span>
              </div>

              <h3 className="font-heading font-black text-xl text-[#182B35] mb-2">
                {basico.name}
              </h3>
              <p className="text-xs text-[#5D737E] mb-6">
                {basico.description}
              </p>

              {/* Preço */}
              <div className="mb-6 pb-6 border-b border-slate-100">
                <div className="flex items-baseline gap-1">
                  <span className="font-heading font-black text-4xl text-[#123C4A]">
                    {basico.priceFormatted}
                  </span>
                  <span className="text-xs text-[#5D737E] font-medium">
                    / {basico.paymentType}
                  </span>
                </div>
                <span className="text-[11px] text-[#25A69A] font-semibold block mt-1">
                  Download imediato em PDF
                </span>
              </div>

              {/* Aviso do que NÃO inclui */}
              <div className="bg-[#FFF9F8] p-3 rounded-xl border border-[#FADCD7] text-[11px] text-[#A4431F] font-medium mb-5">
                {basico.warningNote}
              </div>

              {/* Lista de Recursos Incluídos */}
              <div className="space-y-2.5 mb-6 text-xs text-[#182B35]">
                {basico.includedFeatures.map((feat, i) => (
                  <div key={i} className="flex items-start gap-2.5">
                    <Check className="w-4 h-4 text-[#25A69A] shrink-0 mt-0.5" />
                    <span>{feat}</span>
                  </div>
                ))}

                {basico.excludedFeatures?.map((ex, i) => (
                  <div key={i} className="flex items-start gap-2.5 text-[#98A7AE]">
                    <X className="w-4 h-4 text-[#C5D0D5] shrink-0 mt-0.5" />
                    <span className="line-through">{ex}</span>
                  </div>
                ))}
              </div>
            </div>

            {/* CTA Plano Básico */}
            <button
              onClick={() => handleCheckoutClick(basico.name, basico.checkoutUrl, basico.priceValue)}
              className="w-full py-3.5 px-5 rounded-full border-2 border-[#123C4A] hover:bg-[#123C4A] text-[#123C4A] hover:text-white font-bold text-xs uppercase tracking-wider transition-all duration-200 cursor-pointer text-center"
            >
              {basico.ctaText}
            </button>
          </div>

          {/* Combo Profissional: €9,90 (Destaque Principal) */}
          <div className="lg:col-span-7 bg-[#FFFFFF] rounded-3xl p-6 sm:p-9 border-2 border-[#25A69A] shadow-2xl relative flex flex-col justify-between overflow-hidden">
            {/* Faixa Superior de Destaque */}
            <div className="absolute top-0 right-0 bg-[#25A69A] text-white text-[10px] font-black uppercase tracking-widest px-6 py-1.5 rounded-bl-2xl shadow-sm flex items-center gap-1.5">
              <Sparkles className="w-3 h-3 text-[#D5AD68]" />
              <span>O Mais Escolhido</span>
            </div>

            <div>
              <div className="flex items-center gap-2 mb-3">
                <span className="text-xs font-bold uppercase tracking-wider text-[#25A69A] bg-[#E8F4F2] px-3.5 py-1 rounded-full">
                  {combo.badge}
                </span>
                <span className="text-xs font-semibold text-[#D5AD68]">
                  ★ Acervo Completo 2026/2027
                </span>
              </div>

              <h3 className="font-heading font-black text-2xl sm:text-3xl text-[#123C4A] mb-2">
                {combo.name}
              </h3>
              <p className="text-xs sm:text-sm text-[#5D737E] mb-6">
                {combo.description}
              </p>

              {/* Preço em Destaque */}
              <div className="mb-6 pb-6 border-b border-slate-100 bg-[#F0FAF7] -mx-6 sm:-mx-9 px-6 sm:px-9 py-5">
                <div className="flex items-baseline gap-2">
                  <span className="font-heading font-black text-4xl sm:text-5xl text-[#123C4A]">
                    {combo.priceFormatted}
                  </span>
                  <span className="text-xs sm:text-sm text-[#5D737E] font-medium">
                    / {combo.paymentType}
                  </span>
                </div>
                <div className="flex items-center gap-2 mt-1.5 text-xs text-[#25A69A] font-bold">
                  <span>✓ Acesso a todos os 3 bónus</span>
                  <span>•</span>
                  <span>✓ Modelos editáveis em Word</span>
                </div>
              </div>

              {/* Lista de Recursos Completos */}
              <div className="space-y-3 mb-8 text-xs sm:text-sm text-[#182B35]">
                {combo.includedFeatures.map((feat, i) => (
                  <div key={i} className="flex items-start gap-2.5">
                    <div className="w-4 h-4 rounded-full bg-[#25A69A] text-white flex items-center justify-center shrink-0 mt-0.5 text-[10px] font-bold">
                      ✓
                    </div>
                    <span className="font-medium">{feat}</span>
                  </div>
                ))}
              </div>
            </div>

            {/* CTA Combo Profissional */}
            <div>
              <button
                onClick={() => handleCheckoutClick(combo.name, combo.checkoutUrl, combo.priceValue)}
                className="w-full py-4 px-6 rounded-full bg-[#25A69A] hover:bg-[#1E8E84] text-white font-bold text-sm sm:text-base uppercase tracking-wider shadow-lg hover:shadow-xl hover:-translate-y-0.5 transition-all duration-200 cursor-pointer flex items-center justify-center gap-2"
              >
                <span>{combo.ctaText}</span>
                <ArrowRight className="w-4 h-4" />
              </button>

              <div className="mt-3 text-center text-[11px] text-[#5D737E] flex items-center justify-center gap-3">
                <span className="flex items-center gap-1">
                  <CreditCard className="w-3.5 h-3.5 text-[#25A69A]" />
                  Cartão / MB WAY
                </span>
                <span>•</span>
                <span>Garantia de 7 dias sem perguntas</span>
              </div>
            </div>
          </div>

        </div>

        {/* SECÇÃO 11 — Garantia Legal de 7 Dias */}
        <div className="mt-14 max-w-4xl mx-auto bg-white rounded-3xl p-6 sm:p-8 border border-[#E2EBE8] flex flex-col sm:flex-row items-center gap-6 shadow-xs">
          <div className="w-20 h-20 rounded-2xl bg-[#E8F4F2] text-[#25A69A] flex items-center justify-center shrink-0">
            <ShieldCheck className="w-10 h-10" />
          </div>
          <div className="space-y-1.5 text-center sm:text-left">
            <span className="text-xs font-bold text-[#25A69A] uppercase tracking-wider">
              GARANTIA DE TRANQUILIDADE
            </span>
            <h4 className="font-heading font-black text-lg sm:text-xl text-[#123C4A]">
              Experimente sem risco durante 7 dias
            </h4>
            <p className="text-xs sm:text-sm text-[#5D737E] leading-relaxed">
              Consulte e explore todos os ficheiros. Se considerar que o material não é adequado para o seu trabalho pedagógico, basta enviar uma mensagem de suporte dentro de 7 dias para o reembolso integral do valor pago.
            </p>
          </div>
        </div>

      </div>
    </section>
  );
};
