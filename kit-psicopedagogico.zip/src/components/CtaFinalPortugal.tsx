import React from 'react';
import { ArrowRight, CheckCircle2, ShieldCheck, Download, Sparkles } from 'lucide-react';

interface CtaFinalPortugalProps {
  onCtaClick: () => void;
}

export const CtaFinalPortugal: React.FC<CtaFinalPortugalProps> = ({ onCtaClick }) => {
  return (
    <section className="py-16 sm:py-24 px-4 bg-gradient-to-br from-[#123C4A] via-[#164657] to-[#123C4A] text-white relative overflow-hidden">
      {/* Luzes de fundo sutis */}
      <div className="absolute top-0 right-1/4 w-96 h-96 bg-[#25A69A]/20 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute bottom-0 left-1/4 w-96 h-96 bg-[#D5AD68]/15 rounded-full blur-3xl pointer-events-none" />

      <div className="max-w-4xl mx-auto text-center relative z-10">
        
        <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-white/10 backdrop-blur-md border border-white/20 text-[#25A69A] text-xs font-bold uppercase tracking-wider mb-6">
          <Sparkles className="w-3.5 h-3.5 text-[#D5AD68]" />
          <span>GARANTA O SEU ACESSO HOJE</span>
        </div>

        <h2 className="font-heading font-black text-2xl sm:text-4xl md:text-5xl text-white leading-tight mb-6">
          Poupe dezenas de horas de preparação e tenha sempre materiais estruturados à mão
        </h2>

        <p className="text-sm sm:text-lg text-[#CBDAD5] max-w-2xl mx-auto mb-8 leading-relaxed">
          Tenha acesso imediato a mais de 200 páginas de atividades, testes e modelos editáveis em formato digital para apoiar os seus alunos em Portugal.
        </p>

        {/* Resumo de Benefícios */}
        <div className="flex flex-wrap justify-center gap-4 sm:gap-6 text-xs sm:text-sm text-white mb-10">
          <span className="flex items-center gap-1.5">
            <CheckCircle2 className="w-4 h-4 text-[#25A69A]" />
            Acesso Imediato aos PDFs
          </span>
          <span className="flex items-center gap-1.5">
            <CheckCircle2 className="w-4 h-4 text-[#25A69A]" />
            Documentos em Word Editáveis
          </span>
          <span className="flex items-center gap-1.5">
            <CheckCircle2 className="w-4 h-4 text-[#25A69A]" />
            Garantia de 7 Dias
          </span>
        </div>

        <div className="flex flex-col sm:flex-row items-center justify-center gap-4 max-w-md mx-auto">
          <button
            onClick={onCtaClick}
            className="w-full sm:w-auto px-8 py-4 bg-[#25A69A] hover:bg-[#1E8E84] text-white font-bold text-base rounded-full shadow-xl hover:shadow-2xl hover:-translate-y-0.5 transition-all duration-200 cursor-pointer flex items-center justify-center gap-2 group"
          >
            <span>Ver Planos a partir de 4,90 €</span>
            <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
          </button>
        </div>

        <p className="text-[11px] text-[#A2B8B1] mt-4">
          Pagamento único em EUR • Envio imediato por correio eletrónico
        </p>

      </div>
    </section>
  );
};
