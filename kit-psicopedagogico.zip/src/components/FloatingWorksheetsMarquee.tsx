import React from 'react';
import { Sparkles, CheckCircle2, ArrowRight } from 'lucide-react';

interface FloatingWorksheetsMarqueeProps {
  onCtaClick: () => void;
  onSelectSheet?: (sheet: any) => void;
}

export const FloatingWorksheetsMarquee: React.FC<FloatingWorksheetsMarqueeProps> = ({
  onCtaClick,
  onSelectSheet,
}) => {
  const worksheets = [
    {
      id: 'ws-1',
      title: 'Atenção e Concentração',
      subtitle: 'Observe, Compare e Marque',
      tag: 'Atenção Seletiva',
      imageSrc: '/src/assets/images/prancha_atencao_ptbr_1790625450336.jpg',
      badgeColor: 'bg-[#6657C8]',
    },
    {
      id: 'ws-2',
      title: 'Memória & Sequência',
      subtitle: 'Antes, Durante e Depois',
      tag: 'Sequência Lógica',
      imageSrc: '/src/assets/images/prancha_sequencia_ptbr_1790625463996.jpg',
      badgeColor: 'bg-[#36B77A]',
    },
    {
      id: 'ws-3',
      title: 'Consciência Fonológica',
      subtitle: 'Caça aos Sons e Rimas',
      tag: 'Leitura & Escrita',
      imageSrc: '/src/assets/images/prancha_prof_linguagem_1790623980147.jpg',
      badgeColor: 'bg-[#6657C8]',
    },
    {
      id: 'ws-4',
      title: 'Percepção e Orientação',
      subtitle: 'Labirinto de Formas',
      tag: 'Visomotor',
      imageSrc: '/src/assets/images/prancha_prof_visomotor_1790623993376.jpg',
      badgeColor: 'bg-[#36B77A]',
    },
    {
      id: 'ws-5',
      title: 'Rotina e Autorregulação',
      subtitle: 'Minha Sessão Passo a Passo',
      tag: 'Regulação Emocional',
      imageSrc: '/src/assets/images/prancha_emocoes_ptbr_1790625478056.jpg',
      badgeColor: 'bg-[#6657C8]',
    },
  ];

  // Duplicamos os itens para garantir o loop infinito contínuo e sem emendas
  const duplicatedWorksheets = [...worksheets, ...worksheets, ...worksheets];

  return (
    <section className="py-12 sm:py-16 bg-gradient-to-b from-[#F7F5FC] via-white to-[#F7F5FC] border-y border-[#E9E5F8] overflow-hidden relative">
      {/* Background Soft Glow */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-3/4 h-64 bg-gradient-to-r from-[#6657C8]/10 via-[#36B77A]/10 to-[#6657C8]/10 rounded-full blur-3xl -z-10 pointer-events-none" />

      <div className="max-w-6xl mx-auto px-4 text-center mb-8 sm:mb-10">
        <div className="inline-flex items-center gap-1.5 bg-[#E9E5F8] text-[#6657C8] text-xs font-bold px-3.5 py-1.5 rounded-full uppercase tracking-wider mb-3">
          <Sparkles className="w-3.5 h-3.5 text-[#36B77A]" />
          ACERVO VISUAL EM MOVIMENTO
        </div>
        <h2 className="text-2xl sm:text-3xl md:text-4xl font-extrabold text-[#30264D] font-display">
          Atividades práticas prontas para imprimir
        </h2>
        <p className="text-xs sm:text-sm text-slate-500 max-w-xl mx-auto mt-2">
          Passe o mouse (ou toque) sobre os cartões para pausar e analisar cada detalhe dos materiais diagramados em padrão A4.
        </p>
      </div>

      {/* Faixa Superior: Deslocamento para a Esquerda */}
      <div className="relative w-full overflow-hidden mb-6 py-2">
        {/* Sombras laterais para fade suave */}
        <div className="absolute left-0 top-0 bottom-0 w-16 sm:w-32 bg-gradient-to-r from-[#F7F5FC] to-transparent z-10 pointer-events-none" />
        <div className="absolute right-0 top-0 bottom-0 w-16 sm:w-32 bg-gradient-to-l from-[#F7F5FC] to-transparent z-10 pointer-events-none" />

        <div className="animate-marquee-left flex gap-5 sm:gap-7 items-center">
          {duplicatedWorksheets.map((sheet, index) => (
            <div
              key={`${sheet.id}-left-${index}`}
              className="group relative w-60 sm:w-72 bg-white rounded-2xl sm:rounded-3xl p-3 border border-[#E9E5F8] shadow-md hover:shadow-2xl hover:-translate-y-2 transition-all duration-300 cursor-pointer shrink-0"
              onClick={() => onSelectSheet && onSelectSheet(sheet)}
            >
              {/* Moldura da Folha A4 */}
              <div className="relative aspect-[3/4] overflow-hidden rounded-xl sm:rounded-2xl bg-slate-100 border border-slate-100 shadow-inner">
                <img
                  src={sheet.imageSrc}
                  alt={sheet.title}
                  referrerPolicy="no-referrer"
                  className="w-full h-full object-cover transform group-hover:scale-105 transition-transform duration-500"
                />

                {/* Badge Flutuante no Topo da Imagem */}
                <div className="absolute top-2.5 left-2.5">
                  <span className={`${sheet.badgeColor} text-white text-[10px] font-bold px-2.5 py-0.5 rounded-full shadow-sm`}>
                    {sheet.tag}
                  </span>
                </div>

                {/* Overlay de hover com botão de ver detalhes */}
                <div className="absolute inset-0 bg-[#30264D]/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center p-4">
                  <span className="bg-white text-[#30264D] text-xs font-bold px-3 py-1.5 rounded-xl shadow-lg flex items-center gap-1.5 transform translate-y-2 group-hover:translate-y-0 transition-transform">
                    <span>PDF A4 Pronto</span>
                    <CheckCircle2 className="w-3.5 h-3.5 text-[#36B77A]" />
                  </span>
                </div>
              </div>

              {/* Informações da Folha */}
              <div className="pt-3 px-1">
                <h4 className="font-bold text-xs sm:text-sm text-[#30264D] group-hover:text-[#6657C8] transition-colors line-clamp-1">
                  {sheet.title}
                </h4>
                <p className="text-[11px] text-slate-500 line-clamp-1 mt-0.5">
                  {sheet.subtitle}
                </p>
                <div className="mt-2 pt-2 border-t border-slate-100 flex items-center justify-between text-[10px] text-slate-400">
                  <span className="font-mono">Padrão A4</span>
                  <span className="text-[#36B77A] font-semibold flex items-center gap-0.5">
                    ✓ Alta Resolução
                  </span>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Faixa Inferior de Tags e Benefícios Correndo em Sentido Oposto */}
      <div className="relative w-full overflow-hidden py-1 mb-8">
        <div className="absolute left-0 top-0 bottom-0 w-16 sm:w-32 bg-gradient-to-r from-[#F7F5FC] to-transparent z-10 pointer-events-none" />
        <div className="absolute right-0 top-0 bottom-0 w-16 sm:w-32 bg-gradient-to-l from-[#F7F5FC] to-transparent z-10 pointer-events-none" />

        <div className="animate-marquee-right flex gap-3 items-center">
          {[
            'Atenção Seletiva e Sustentada',
            'Consciência Fonológica e Rimas',
            'Memória de Trabalho Operacional',
            'Orientação Espacial e Lateralidade',
            'Termômetro das Emoções',
            'Rotina Visual para Sessão',
            'Labirintos Progressivos de Decisão',
            'Sondagem de Alfabetização',
            'Coordenação Visomotora Fina',
            'Previsibilidade e Menos Ansiedade',
            'Atenção Seletiva e Sustentada',
            'Consciência Fonológica e Rimas',
            'Memória de Trabalho Operacional',
            'Orientação Espacial e Lateralidade',
          ].map((item, i) => (
            <div
              key={i}
              className="bg-white/90 backdrop-blur-xs px-4 py-1.5 rounded-full border border-[#E9E5F8] shadow-2xs text-xs font-semibold text-[#30264D] flex items-center gap-2 whitespace-nowrap"
            >
              <span className="w-1.5 h-1.5 rounded-full bg-[#36B77A]" />
              <span>{item}</span>
            </div>
          ))}
        </div>
      </div>

      {/* Botão de Ação Central */}
      <div className="text-center px-4">
        <button
          onClick={onCtaClick}
          className="w-full sm:w-auto px-8 py-3.5 bg-[#6657C8] hover:bg-[#5545B3] text-white font-bold text-sm sm:text-base rounded-2xl shadow-lg hover:shadow-xl hover:-translate-y-0.5 transition-all cursor-pointer inline-flex items-center justify-center gap-2"
        >
          <span>QUERO RECEBER TODAS AS ATIVIDADES EM PDF</span>
          <ArrowRight className="w-4 h-4" />
        </button>
      </div>
    </section>
  );
};
