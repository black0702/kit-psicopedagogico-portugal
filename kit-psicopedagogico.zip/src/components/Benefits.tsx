import React from 'react';
import { CheckCircle2 } from 'lucide-react';
import { PROFESSIONAL_BENEFITS } from '../data/landingData';

export const Benefits: React.FC = () => {
  return (
    <section className="py-14 sm:py-20 px-4 bg-[#F1EFF9] border-y border-[#E9E5F8]">
      <div className="max-w-5xl mx-auto">
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-10 sm:mb-14">
          <span className="text-xs font-bold text-[#36B77A] uppercase tracking-wider bg-white px-3 py-1 rounded-full border border-[#E9E5F8] mb-3 inline-block">
            VANTAGENS PRÁTICAS
          </span>
          <h2 className="text-2xl sm:text-3xl md:text-4xl font-extrabold text-[#30264D] mb-3 font-display">
            Para quem quer mais praticidade no atendimento
          </h2>
          <p className="text-sm sm:text-base text-slate-600 leading-relaxed">
            Mais fluidez na sua rotina diária com materiais prontos para o consultório ou ambiente pedagógico.
          </p>
        </div>

        {/* 6 Cards with Green Check */}
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4 sm:gap-6">
          {PROFESSIONAL_BENEFITS.map((item) => (
            <div
              key={item.id}
              className="bg-white rounded-2xl p-5 border border-[#E9E5F8] shadow-xs hover:shadow-md transition-all duration-200 flex items-start gap-3.5"
            >
              <div className="w-8 h-8 rounded-full bg-[#36B77A]/15 text-[#36B77A] flex items-center justify-center shrink-0 mt-0.5">
                <CheckCircle2 className="w-5 h-5" />
              </div>
              <p className="text-sm font-semibold text-[#30264D] leading-snug">
                {item.text}
              </p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};
