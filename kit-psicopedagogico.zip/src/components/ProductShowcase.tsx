import React from 'react';
import { CheckCircle2, Layers, FileText, Sparkles } from 'lucide-react';
import { PRODUCT_INCLUDED_LIST } from '../data/landingData';

export const ProductShowcase: React.FC = () => {
  return (
    <section className="py-14 sm:py-20 px-4 bg-[#F1EFF9] border-y border-[#E9E5F8]">
      <div className="max-w-6xl mx-auto">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 sm:gap-12 items-center">
          
          {/* ESQUERDA: Grande Mockup da Biblioteca */}
          <div className="lg:col-span-6">
            <div className="bg-white rounded-3xl p-5 sm:p-8 border border-[#E9E5F8] shadow-lg relative">
              {/* Top Tag Label */}
              <div className="flex items-center justify-between pb-3 mb-4 border-b border-slate-100 text-xs font-bold text-[#6657C8]">
                <span className="flex items-center gap-1.5 font-mono">
                  <Layers className="w-4 h-4 text-[#6657C8]" />
                  [MOCKUP DA BIBLIOTECA]
                </span>
                <span className="bg-[#36B77A]/15 text-[#36B77A] text-[10px] px-2 py-0.5 rounded-full">
                  Acervo Completo
                </span>
              </div>

              {/* Graphic Multi-Document Stack Representation */}
              <div className="bg-gradient-to-br from-[#30264D] to-[#3C3060] rounded-2xl p-6 text-white shadow-md relative overflow-hidden mb-4">
                <div className="flex items-center justify-between mb-4">
                  <div className="w-8 h-8 rounded-lg bg-[#6657C8] flex items-center justify-center text-white">
                    <FileText className="w-4 h-4" />
                  </div>
                  <span className="text-[10px] uppercase font-bold text-yellow-300 tracking-wider">
                    BIBLIOTECA EM PDF
                  </span>
                </div>

                <div className="text-2xl font-bold font-display mb-1 text-white">
                  +200 Recursos Práticos
                </div>
                <div className="text-xs text-slate-300 mb-4">
                  Avaliação e Intervenção Psicopedagógica Estruturada
                </div>

                {/* Simulated Stacked Sheets */}
                <div className="grid grid-cols-2 gap-2 text-[10px] text-slate-300 pt-3 border-t border-white/10">
                  <div className="bg-white/10 p-2 rounded-lg border border-white/10">
                    <div className="font-bold text-white mb-0.5">8 Categorias</div>
                    <div className="text-[9px] text-slate-400">Objetivos claros</div>
                  </div>
                  <div className="bg-white/10 p-2 rounded-lg border border-white/10">
                    <div className="font-bold text-[#36B77A] mb-0.5">Pronto para uso</div>
                    <div className="text-[9px] text-slate-400">Padrão impressão A4</div>
                  </div>
                </div>
              </div>

              {/* Mini Sheet Samples Preview Strip */}
              <div className="grid grid-cols-3 gap-2">
                {['Fichas de Triagem', 'Pranchas de Foco', 'Cartões de Memória'].map((item, idx) => (
                  <div key={idx} className="bg-[#F7F5FC] p-2.5 rounded-xl border border-[#E9E5F8] text-center">
                    <div className="w-5 h-5 rounded-full bg-white shadow-xs mx-auto mb-1 flex items-center justify-center text-[#6657C8] text-[9px] font-bold">
                      0{idx + 1}
                    </div>
                    <div className="text-[10px] font-semibold text-[#30264D] truncate">{item}</div>
                    <div className="text-[8px] text-slate-400">PDF pronto</div>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* DIREITA: Título e Lista de Entregáveis */}
          <div className="lg:col-span-6 space-y-6">
            <div>
              <span className="text-xs font-bold text-[#6657C8] uppercase tracking-wider bg-white px-3 py-1 rounded-full border border-[#E9E5F8] mb-3 inline-block">
                VISÃO DETALHADA
              </span>
              <h2 className="text-2xl sm:text-3xl md:text-4xl font-extrabold text-[#30264D] leading-tight font-display mb-3">
                Do primeiro recurso à organização completa
              </h2>
              <p className="text-sm sm:text-base text-slate-600 leading-relaxed">
                Tudo o que você precisa para enriquecer seu repertório de atendimento, com materiais pensados para facilitar sua rotina diária.
              </p>
            </div>

            {/* Checklist */}
            <div className="space-y-3">
              {PRODUCT_INCLUDED_LIST.map((item, index) => (
                <div 
                  key={index}
                  className="flex items-center gap-3 bg-white p-3 sm:p-3.5 rounded-xl border border-[#E9E5F8] shadow-2xs"
                >
                  <div className="w-5 h-5 rounded-full bg-[#36B77A]/15 text-[#36B77A] flex items-center justify-center shrink-0">
                    <CheckCircle2 className="w-4 h-4" />
                  </div>
                  <span className="text-sm font-semibold text-[#30264D]">
                    {item}
                  </span>
                </div>
              ))}
            </div>
          </div>

        </div>
      </div>
    </section>
  );
};
