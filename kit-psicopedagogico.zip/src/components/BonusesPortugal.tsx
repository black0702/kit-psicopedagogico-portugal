import React from 'react';
import { Gift, FileText, Sparkles, BookOpen } from 'lucide-react';

export const BonusesPortugal: React.FC = () => {
  return (
    <section id="bonuses" className="py-16 sm:py-24 px-4 bg-[#F3EBDD]/60 border-b border-[#E2EBE8]">
      <div className="max-w-6xl mx-auto">
        
        <div className="max-w-3xl mx-auto text-center mb-14">
          <span className="text-xs font-bold text-[#D5AD68] uppercase tracking-wider bg-[#FFFFFF] px-3.5 py-1.5 rounded-full inline-block mb-3 border border-[#F3E7D0] shadow-2xs">
            BÓNUS DO COMBO PROFISSIONAL
          </span>
          <h2 className="font-heading font-black text-2xl sm:text-4xl text-[#123C4A] leading-tight mb-4">
            Bónus que complementam a sua prática educativa
          </h2>
          <p className="text-sm sm:text-base text-[#5D737E]">
            Disponíveis sem custos adicionais ao escolher o Combo Profissional Completo.
          </p>
        </div>

        {/* 3 Bónus Principais */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-12">
          
          {/* Bónus 1 */}
          <div className="bg-white rounded-3xl overflow-hidden border border-[#E2EBE8] shadow-sm flex flex-col justify-between group hover:-translate-y-1 transition-all">
            <div className="bg-[#FAFDFB] p-5 h-60 flex items-center justify-center border-b border-slate-100 relative">
              <img
                src="/site_images/site_img_2.jpg"
                alt="Drive Profissional — Sistema Completo de Aprendizagem"
                className="max-h-48 w-auto object-contain rounded-xl shadow-md transform -rotate-2 group-hover:rotate-0 transition-transform"
                loading="lazy"
              />
            </div>
            <div className="p-6">
              <span className="text-[11px] font-bold text-[#25A69A] uppercase tracking-wider bg-[#E8F4F2] px-2.5 py-1 rounded-full inline-block mb-2">
                BÓNUS 1 • FICHEIROS EDITÁVEIS
              </span>
              <h3 className="font-heading font-bold text-lg text-[#182B35] mb-2">
                Drive Profissional — Documentos em Word
              </h3>
              <p className="text-xs text-[#5D737E] leading-relaxed">
                Grelhas de triagem, modelos de PEI (Plano de Educação Individualizada), relatórios e fichas de anamnese 100% editáveis no computador.
              </p>
            </div>
          </div>

          {/* Bónus 2 */}
          <div className="bg-white rounded-3xl overflow-hidden border border-[#E2EBE8] shadow-sm flex flex-col justify-between group hover:-translate-y-1 transition-all">
            <div className="bg-[#FAFDFB] p-5 h-60 flex items-center justify-center border-b border-slate-100 relative">
              <img
                src="/site_images/site_img_3.jpg"
                alt="1.500 Atividades Infantis em PDF"
                className="max-h-48 w-auto object-contain rounded-xl shadow-md transform rotate-2 group-hover:rotate-0 transition-transform"
                loading="lazy"
              />
            </div>
            <div className="p-6">
              <span className="text-[11px] font-bold text-[#25A69A] uppercase tracking-wider bg-[#E8F4F2] px-2.5 py-1 rounded-full inline-block mb-2">
                BÓNUS 2 • ACERVO GIGANTE
              </span>
              <h3 className="font-heading font-bold text-lg text-[#182B35] mb-2">
                1.500 Atividades Infantis em PDF
              </h3>
              <p className="text-xs text-[#5D737E] leading-relaxed">
                Atividades complementares de linguagem, raciocínio lógico, coordenação motora fina, pré-alfabetização e estímulo cognitivo.
              </p>
            </div>
          </div>

          {/* Bónus 3 */}
          <div className="bg-white rounded-3xl overflow-hidden border border-[#E2EBE8] shadow-sm flex flex-col justify-between group hover:-translate-y-1 transition-all">
            <div className="bg-[#FAFDFB] p-5 h-60 flex items-center justify-center border-b border-slate-100 relative">
              <img
                src="/site_images/site_img_4.jpg"
                alt="Kit Visual de Hábitos, Comunicação e Regulação"
                className="max-h-48 w-auto object-contain rounded-xl shadow-md transform -rotate-1 group-hover:rotate-0 transition-transform"
                loading="lazy"
              />
            </div>
            <div className="p-6">
              <span className="text-[11px] font-bold text-[#25A69A] uppercase tracking-wider bg-[#E8F4F2] px-2.5 py-1 rounded-full inline-block mb-2">
                BÓNUS 3 • RECURSO VISUAL
              </span>
              <h3 className="font-heading font-bold text-lg text-[#182B35] mb-2">
                Kit Visual de Rotina e Regulação
              </h3>
              <p className="text-xs text-[#5D737E] leading-relaxed">
                Rotina diária visual com cartões de escolhas, termómetro das emoções, cantinho da calma e cartões de transição sem stress.
              </p>
            </div>
          </div>

        </div>

        {/* 3 E-books sobre Autismo e Inclusão */}
        <div className="bg-white rounded-3xl p-6 sm:p-8 border border-[#E2EBE8] shadow-sm">
          <div className="text-center mb-6">
            <h3 className="font-heading font-black text-xl text-[#123C4A]">
              + 3 Guias Temáticos sobre Apoio ao Autismo e Inclusão
            </h3>
            <p className="text-xs text-[#5D737E] mt-1">
              Manuais de apoio prático para pais e equipas pedagógicas:
            </p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div className="flex items-center gap-3 p-3.5 rounded-2xl bg-[#F8FAF9] border border-[#E2EBE8]">
              <img
                src="/site_images/site_img_5.jpg"
                alt="Foco e Concentração no Autismo"
                className="w-16 h-14 object-contain shrink-0"
                loading="lazy"
              />
              <div>
                <strong className="text-xs text-[#182B35] block leading-snug">Foco e Concentração no Autismo</strong>
                <span className="text-[11px] text-[#25A69A] font-semibold">Incluído no Combo</span>
              </div>
            </div>

            <div className="flex items-center gap-3 p-3.5 rounded-2xl bg-[#F8FAF9] border border-[#E2EBE8]">
              <img
                src="/site_images/site_img_6.jpg"
                alt="Guia de Estratégias Comportamentais"
                className="w-16 h-14 object-contain shrink-0"
                loading="lazy"
              />
              <div>
                <strong className="text-xs text-[#182B35] block leading-snug">Estratégias Comportamentais</strong>
                <span className="text-[11px] text-[#25A69A] font-semibold">Incluído no Combo</span>
              </div>
            </div>

            <div className="flex items-center gap-3 p-3.5 rounded-2xl bg-[#F8FAF9] border border-[#E2EBE8]">
              <img
                src="/site_images/site_img_7.jpg"
                alt="Manual Prático para Pais e Profissionais"
                className="w-16 h-14 object-contain shrink-0"
                loading="lazy"
              />
              <div>
                <strong className="text-xs text-[#182B35] block leading-snug">Manual Pais e Profissionais</strong>
                <span className="text-[11px] text-[#25A69A] font-semibold">Incluído no Combo</span>
              </div>
            </div>
          </div>
        </div>

      </div>
    </section>
  );
};
