import React, { useState, useEffect } from 'react';
import { ArrowRight, Sparkles } from 'lucide-react';
import { trackPixelEvent } from '../utils/pixelTracker';

interface FloatingCtaBarProps {
  onCtaClick: () => void;
}

export const FloatingCtaBar: React.FC<FloatingCtaBarProps> = ({ onCtaClick }) => {
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      // Mostra a barra fixa após rolar 500px para baixo
      if (window.scrollY > 500) {
        setIsVisible(true);
      } else {
        setIsVisible(false);
      }
    };

    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  if (!isVisible) return null;

  return (
    <div className="md:hidden fixed bottom-0 left-0 right-0 z-50 p-3 bg-white/95 backdrop-blur-md border-t border-[#E2EBE8] shadow-2xl animate-slideUp">
      <div className="flex items-center justify-between gap-3 max-w-md mx-auto">
        <div className="flex flex-col">
          <span className="text-[10px] text-[#25A69A] font-bold uppercase tracking-wider flex items-center gap-1">
            <Sparkles className="w-3 h-3 text-[#D5AD68]" />
            Acesso Digital
          </span>
          <span className="font-heading font-black text-xs text-[#123C4A] leading-tight">
            Kit Completo a partir de 4,90 €
          </span>
        </div>

        <button
          onClick={() => {
            trackPixelEvent('InitiateCheckout', { content_name: 'Mobile Floating Bar CTA' });
            onCtaClick();
          }}
          className="px-4 py-2.5 bg-[#25A69A] hover:bg-[#1E8E84] text-white text-xs font-bold rounded-full shadow-md flex items-center gap-1.5 shrink-0 transition-transform active:scale-95 cursor-pointer"
        >
          <span>Garantir Acesso</span>
          <ArrowRight className="w-3.5 h-3.5" />
        </button>
      </div>
    </div>
  );
};
