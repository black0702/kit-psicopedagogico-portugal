import React from 'react';
import { 
  GraduationCap, 
  BookOpenCheck, 
  Users, 
  HelpCircle, 
  Check, 
  ShieldAlert,
  Sparkles
} from 'lucide-react';

export const AudienceAndBenefitsPortugal: React.FC = () => {
  const audiences = [
    {
      title: 'Docentes do 1.º e 2.º Ciclo do Ensino Básico',
      desc: 'Para apoiar alunos com dificuldades de aprendizagem na leitura, escrita, cálculo e atenção em contexto de sala de aula.',
      icon: GraduationCap,
    },
    {
      title: 'Docentes de Educação Especial & Apoio Educativo',
      desc: 'Recursos estruturados para intervenção em pequenos grupos, planos de apoio individualizado e reforço de competências.',
      icon: BookOpenCheck,
    },
    {
      title: 'Psicólogos Escolares, Terapeutas e Técnicos',
      desc: 'Materiais complementares para enriquecer sessões de estimulação cognitiva, funções executivas e autorregulação.',
      icon: Users,
    },
    {
      title: 'Pais e Encarregados de Educação',
      desc: 'Famílias que procuram atividades de reforço lúdico e rotinas visuais organizadas para realizar em casa.',
      icon: HelpCircle,
    },
  ];

  return (
    <section id="publico" className="py-16 sm:py-24 px-4 bg-[#FAF6EE] border-t border-[#E8E1D3]">
      <div className="max-w-6xl mx-auto">
        
        {/* SECÇÃO 6 — Benefícios Objetivos */}
        <div className="max-w-3xl mx-auto text-center mb-14">
          <span className="text-xs font-bold text-[#25A69A] uppercase tracking-wider bg-[#E8F4F2] px-3.5 py-1.5 rounded-full inline-block mb-3 border border-[#C5E4DD]">
            BENEFÍCIOS REAIS
          </span>
          <h2 className="font-heading font-black text-2xl sm:text-4xl text-[#123C4A] leading-tight mb-4">
            Por que profissionais em Portugal escolhem este acervo
          </h2>
          <p className="text-sm sm:text-base text-[#5D737E]">
            Vantagens práticas para o seu dia a dia profissional, sem exageros ou falsas promessas.
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5 mb-20">
          <div className="bg-white p-6 rounded-3xl border border-[#E2EBE8] shadow-xs flex flex-col justify-between">
            <div>
              <div className="w-10 h-10 rounded-2xl bg-[#E8F4F2] text-[#25A69A] flex items-center justify-center font-bold mb-4">
                01
              </div>
              <h3 className="font-heading font-bold text-base text-[#182B35] mb-2">
                Organização Imediata
              </h3>
              <p className="text-xs text-[#5D737E] leading-relaxed">
                Tudo categorizado por pastas digitais e áreas de trabalho, sem perda de tempo à procura de ficheiros soltos.
              </p>
            </div>
          </div>

          <div className="bg-white p-6 rounded-3xl border border-[#E2EBE8] shadow-xs flex flex-col justify-between">
            <div>
              <div className="w-10 h-10 rounded-2xl bg-[#E8F4F2] text-[#25A69A] flex items-center justify-center font-bold mb-4">
                02
              </div>
              <h3 className="font-heading font-bold text-base text-[#182B35] mb-2">
                Ficheiros em PDF & Word
              </h3>
              <p className="text-xs text-[#5D737E] leading-relaxed">
                Abra no telemóvel, tablet ou computador. Imprima quantas vezes precisar para cada aluno ou paciente.
              </p>
            </div>
          </div>

          <div className="bg-white p-6 rounded-3xl border border-[#E2EBE8] shadow-xs flex flex-col justify-between">
            <div>
              <div className="w-10 h-10 rounded-2xl bg-[#E8F4F2] text-[#25A69A] flex items-center justify-center font-bold mb-4">
                03
              </div>
              <h3 className="font-heading font-bold text-base text-[#182B35] mb-2">
                Abordagem Respeitosa
              </h3>
              <p className="text-xs text-[#5D737E] leading-relaxed">
                Atividades lúdicas com ilustrações cuidadas que respeitam o ritmo e a autoestima da criança.
              </p>
            </div>
          </div>

          <div className="bg-white p-6 rounded-3xl border border-[#E2EBE8] shadow-xs flex flex-col justify-between">
            <div>
              <div className="w-10 h-10 rounded-2xl bg-[#E8F4F2] text-[#25A69A] flex items-center justify-center font-bold mb-4">
                04
              </div>
              <h3 className="font-heading font-bold text-base text-[#182B35] mb-2">
                Prático & Pronto a Aplicar
              </h3>
              <p className="text-xs text-[#5D737E] leading-relaxed">
                Materiais prontos para imprimir e levar diretamente para a sessão, poupando tempo na preparação semanal.
              </p>
            </div>
          </div>
        </div>

        {/* SECÇÃO 7 — Para quem é (com Enquadramento Profissional Correto) */}
        <div className="bg-white rounded-3xl p-6 sm:p-12 border border-[#E2EBE8] shadow-sm">
          <div className="max-w-3xl mx-auto text-center mb-10">
            <span className="text-xs font-bold text-[#D5AD68] uppercase tracking-wider bg-[#FBF7EE] px-3.5 py-1.5 rounded-full inline-block mb-3 border border-[#F3E7D0]">
              PÚBLICO-ALVO & ÉTICA PROFISSIONAL
            </span>
            <h2 className="font-heading font-black text-2xl sm:text-3xl text-[#123C4A] leading-tight mb-3">
              Para quem este material foi desenvolvido
            </h2>
            <p className="text-xs sm:text-sm text-[#5D737E]">
              Criado para apoiar quem trabalha com desenvolvimento infantil e apoio pedagógico em Portugal.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
            {audiences.map((aud, i) => {
              const Icon = aud.icon;
              return (
                <div key={i} className="flex items-start gap-4 p-5 rounded-2xl bg-[#F8FAF9] border border-[#E2EBE8]">
                  <div className="w-10 h-10 rounded-xl bg-[#E8F4F2] text-[#25A69A] flex items-center justify-center shrink-0">
                    <Icon className="w-5 h-5" />
                  </div>
                  <div>
                    <h3 className="font-bold text-sm sm:text-base text-[#182B35] mb-1">
                      {aud.title}
                    </h3>
                    <p className="text-xs text-[#5D737E] leading-relaxed">
                      {aud.desc}
                    </p>
                  </div>
                </div>
              );
            })}
          </div>

          {/* Aviso Ético e Regulamentar em Portugal */}
          <div className="p-4 sm:p-5 rounded-2xl bg-[#FFF9F8] border border-[#FADCD7] flex items-start gap-3.5 text-xs text-[#7A3626]">
            <ShieldAlert className="w-5 h-5 text-[#C2532F] shrink-0 mt-0.5" />
            <div className="leading-relaxed">
              <strong>Nota sobre regulamentação e habilitações em Portugal:</strong> Este kit é um recurso complementar de cariz pedagógico e prático. A aplicação de avaliações clínicas ou testes psicométricos formais reserva-se aos profissionais devidamente habilitados pelas respetivas ordens e associações profissionais em Portugal (ex.: Ordem dos Psicólogos Portugueses). O material serve de apoio e não substitui diagnósticos clínicos formais.
            </div>
          </div>
        </div>

      </div>
    </section>
  );
};
