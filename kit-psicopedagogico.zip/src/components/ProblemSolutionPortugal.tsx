import React from 'react';
import { Clock, Layers, FileSpreadsheet, AlertCircle, CheckCircle, ArrowRight } from 'lucide-react';

export const ProblemSolutionPortugal: React.FC = () => {
  return (
    <section id="solucao" className="py-16 sm:py-24 px-4 bg-[#FFFFFF] border-y border-[#E2EBE8]">
      <div className="max-w-6xl mx-auto">
        
        {/* SECÇÃO 2 — O Problema Real */}
        <div className="max-w-3xl mx-auto text-center mb-14 sm:mb-16">
          <span className="text-xs font-bold text-[#D5AD68] uppercase tracking-wider bg-[#FBF7EE] px-3.5 py-1.5 rounded-full inline-block mb-3 border border-[#F3E7D0]">
            O DESAFIO DA PREPARAÇÃO
          </span>
          <h2 className="font-heading font-black text-2xl sm:text-4xl text-[#123C4A] leading-tight mb-4">
            Horas gastas a pesquisar na internet, materiais dispersos e falta de estrutura prática
          </h2>
          <p className="text-sm sm:text-base text-[#5D737E] leading-relaxed">
            Profissionais dedicados ao apoio à aprendizagem enfrentam frequentemente a sobrecarga de preparar materiais do zero todas as semanas.
          </p>
        </div>

        {/* Comparação: Problema vs. Solução */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-16 items-stretch">
          
          {/* Card: Sem o Kit (Dificuldades Diárias) */}
          <div className="bg-[#FFF9F8] rounded-3xl p-6 sm:p-8 border border-[#FADCD7] flex flex-col justify-between">
            <div>
              <div className="flex items-center gap-2.5 mb-5 text-[#C2532F]">
                <div className="w-9 h-9 rounded-xl bg-[#FDECE8] flex items-center justify-center font-bold">
                  <AlertCircle className="w-5 h-5 text-[#C2532F]" />
                </div>
                <h3 className="font-heading font-black text-lg sm:text-xl text-[#C2532F]">
                  A rotina sem materiais organizados
                </h3>
              </div>

              <ul className="space-y-4 text-xs sm:text-sm text-[#5D737E]">
                <li className="flex items-start gap-3">
                  <span className="w-5 h-5 rounded-full bg-[#FADCD7] text-[#C2532F] flex items-center justify-center shrink-0 mt-0.5 text-xs font-bold">✕</span>
                  <span><strong>Falta de tempo:</strong> Noites e fins de semana perdidos a criar e formatar fichas de atividades.</span>
                </li>
                <li className="flex items-start gap-3">
                  <span className="w-5 h-5 rounded-full bg-[#FADCD7] text-[#C2532F] flex items-center justify-center shrink-0 mt-0.5 text-xs font-bold">✕</span>
                  <span><strong>Recursos dispersos:</strong> PDFs de baixa qualidade visual espalhados por pastas e pens USB.</span>
                </li>
                <li className="flex items-start gap-3">
                  <span className="w-5 h-5 rounded-full bg-[#FADCD7] text-[#C2532F] flex items-center justify-center shrink-0 mt-0.5 text-xs font-bold">✕</span>
                  <span><strong>Insegurança na estrutura:</strong> Falta de um roteiro sequencial que ligue a queixa inicial ao plano de intervenção.</span>
                </li>
                <li className="flex items-start gap-3">
                  <span className="w-5 h-5 rounded-full bg-[#FADCD7] text-[#C2532F] flex items-center justify-center shrink-0 mt-0.5 text-xs font-bold">✕</span>
                  <span><strong>Relatórios complexos:</strong> Dificuldade em redigir devolutivas claras para famílias e escolas.</span>
                </li>
              </ul>
            </div>

            <div className="mt-6 pt-4 border-t border-[#F5D0C9] text-xs font-semibold text-[#A4431F]">
              Resultado: cansaço, sobrecarga e menos tempo para o contacto direto com o aluno.
            </div>
          </div>

          {/* Card: Com o Kit Digital (A Solução Prática) */}
          <div className="bg-[#F0FAF7] rounded-3xl p-6 sm:p-8 border border-[#BCE5DC] flex flex-col justify-between shadow-xs">
            <div>
              <div className="flex items-center gap-2.5 mb-5 text-[#123C4A]">
                <div className="w-9 h-9 rounded-xl bg-[#DCF2ED] flex items-center justify-center font-bold">
                  <CheckCircle className="w-5 h-5 text-[#25A69A]" />
                </div>
                <h3 className="font-heading font-black text-lg sm:text-xl text-[#123C4A]">
                  Com o Kit Psicopedagógico Digital
                </h3>
              </div>

              <ul className="space-y-4 text-xs sm:text-sm text-[#182B35]">
                <li className="flex items-start gap-3">
                  <span className="w-5 h-5 rounded-full bg-[#25A69A] text-white flex items-center justify-center shrink-0 mt-0.5 text-xs font-bold">✓</span>
                  <span><strong>Economia de tempo imediata:</strong> Ficheiros prontos a imprimir no formato A4, basta abrir e imprimir.</span>
                </li>
                <li className="flex items-start gap-3">
                  <span className="w-5 h-5 rounded-full bg-[#25A69A] text-white flex items-center justify-center shrink-0 mt-0.5 text-xs font-bold">✓</span>
                  <span><strong>Tudo centralizado:</strong> Mais de 200 páginas organizadas por áreas de desenvolvimento e competências.</span>
                </li>
                <li className="flex items-start gap-3">
                  <span className="w-5 h-5 rounded-full bg-[#25A69A] text-white flex items-center justify-center shrink-0 mt-0.5 text-xs font-bold">✓</span>
                  <span><strong>Roteiro sequencial:</strong> Desde a primeira sessão de acolhimento até à devolutiva aos pais e docentes.</span>
                </li>
                <li className="flex items-start gap-3">
                  <span className="w-5 h-5 rounded-full bg-[#25A69A] text-white flex items-center justify-center shrink-0 mt-0.5 text-xs font-bold">✓</span>
                  <span><strong>Modelos editáveis em Word:</strong> Documentos administrativos que pode adaptar à sua realidade institucional.</span>
                </li>
              </ul>
            </div>

            <div className="mt-6 pt-4 border-t border-[#BCE5DC] text-xs font-semibold text-[#25A69A]">
              Resultado: sessões mais dinâmicas, preparação rápida e total tranquilidade profissional.
            </div>
          </div>

        </div>

        {/* SECÇÃO 3 — Como o Kit Organiza os Recursos */}
        <div className="bg-[#FAFDFB] rounded-3xl p-6 sm:p-10 border border-[#E2EBE8]">
          <div className="max-w-2xl mx-auto text-center mb-8">
            <span className="text-xs font-bold text-[#25A69A] uppercase tracking-wider bg-[#E8F4F2] px-3 py-1 rounded-full inline-block mb-2">
              ORGANIZAÇÃO ESTRUTURADA
            </span>
            <h3 className="font-heading font-black text-xl sm:text-2xl text-[#123C4A]">
              Como o kit organiza os seus recursos digitais
            </h3>
            <p className="text-xs sm:text-sm text-[#5D737E] mt-2">
              Não é apenas um aglomerado de folhas soltas, mas sim uma biblioteca prática dividida em etapas lógicas:
            </p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-6 text-center">
            <div className="p-4 rounded-2xl bg-white border border-[#E2EBE8] shadow-xs">
              <div className="w-10 h-10 rounded-xl bg-[#123C4A] text-white font-black text-sm flex items-center justify-center mx-auto mb-3">
                1
              </div>
              <h4 className="font-bold text-sm text-[#182B35] mb-1">Acolhimento & Rastreio</h4>
              <p className="text-xs text-[#5D737E]">
                Fichas de anamnese, registo de observação e grelhas de levantamento de hipóteses.
              </p>
            </div>

            <div className="p-4 rounded-2xl bg-white border border-[#E2EBE8] shadow-xs">
              <div className="w-10 h-10 rounded-xl bg-[#25A69A] text-white font-black text-sm flex items-center justify-center mx-auto mb-3">
                2
              </div>
              <h4 className="font-bold text-sm text-[#182B35] mb-1">Estimulação & Prática</h4>
              <p className="text-xs text-[#5D737E]">
                Atividades de linguagem, consciência fonológica, raciocínio lógico, atenção e memória.
              </p>
            </div>

            <div className="p-4 rounded-2xl bg-white border border-[#E2EBE8] shadow-xs">
              <div className="w-10 h-10 rounded-xl bg-[#D5AD68] text-white font-black text-sm flex items-center justify-center mx-auto mb-3">
                3
              </div>
              <h4 className="font-bold text-sm text-[#182B35] mb-1">Devolutiva & Plano</h4>
              <p className="text-xs text-[#5D737E]">
                Síntese diagnóstica, comunicação com a escola e estruturação do plano de apoio individual.
              </p>
            </div>
          </div>
        </div>

      </div>
    </section>
  );
};
