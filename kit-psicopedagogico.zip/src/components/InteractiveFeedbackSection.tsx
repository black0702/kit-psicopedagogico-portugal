import React, { useState } from 'react';
import { ChevronLeft, ChevronRight, MessageCircle, Star, CheckCircle2 } from 'lucide-react';

export const InteractiveFeedbackSection: React.FC = () => {
  // Feedbacks transparentes baseados no formato da referência (WhatsApp/Instagram print cards)
  const feedbacks = [
    {
      id: 1,
      sender: 'Psicopedagoga Clínica',
      context: 'Atendimento Individual',
      time: 'Ontem às 16:42',
      messages: [
        'Olá! Passando para agradecer pelo material dos +200 recursos.',
        'Me ajudou MUITO na preparação da sessão de hoje. A ficha de rastreio de atenção foi super clara e o aprendente engajou do começo ao fim!',
        'Economizei horas que antes passava procurando coisas soltas na internet.',
      ],
    },
    {
      id: 2,
      sender: 'Coordenadora de Apoio Pedagógico',
      context: 'Escola Particular',
      time: 'Hoje às 11:15',
      messages: [
        'Adotamos o Guia Prático e as pranchas aqui com nossa equipe de apoio.',
        'Os mapas visuais deram um direcionamento excelente para as devolutivas com os professores e famílias.',
        'Material impecável, muito bem diagramado em A4.',
      ],
    },
    {
      id: 3,
      sender: 'Especialista em Intervenção Precoce',
      context: 'Consultório Particular',
      time: 'Há 3 dias',
      messages: [
        'O kit de regulação e rotina visual é maravilhoso!',
        'Plastifiquei os cartões de emoções e o termômetro das pausas. As crianças adoram manipular durante as atividades.',
        'Valeu cada centavo, super recomendo para quem atende!',
      ],
    },
  ];

  const [activeFeedbackIndex, setActiveFeedbackIndex] = useState(0);

  const next = () => setActiveFeedbackIndex((prev) => (prev + 1) % feedbacks.length);
  const prev = () => setActiveFeedbackIndex((prev) => (prev - 1 + feedbacks.length) % feedbacks.length);

  const current = feedbacks[activeFeedbackIndex];

  return (
    <section className="py-14 sm:py-20 px-4 bg-[#F1EFF9] border-y border-[#E9E5F8]">
      <div className="max-w-4xl mx-auto text-center">
        
        <span className="text-xs font-bold text-[#6657C8] uppercase tracking-wider bg-white px-3.5 py-1.5 rounded-full border border-[#E9E5F8] inline-block mb-3">
          RETORNOS E VALIDAÇÃO
        </span>
        <h2 className="text-2xl sm:text-3xl font-extrabold text-[#30264D] font-display mb-2">
          Feedbacks de Profissionais da Área
        </h2>
        <p className="text-xs sm:text-sm text-slate-500 mb-8 max-w-md mx-auto">
          Veja a experiência de quem já utiliza os recursos na rotina de avaliação e intervenção.
        </p>

        {/* Mockup Interativo estilo conversa / feedback real */}
        <div className="relative max-w-md mx-auto bg-white rounded-3xl p-5 sm:p-6 border border-[#E9E5F8] shadow-xl text-left">
          {/* Header da Conversa */}
          <div className="flex items-center justify-between pb-3 mb-4 border-b border-slate-100">
            <div className="flex items-center gap-2.5">
              <div className="w-10 h-10 rounded-full bg-gradient-to-tr from-[#6657C8] to-[#36B77A] text-white flex items-center justify-center font-bold text-sm">
                <MessageCircle className="w-5 h-5" />
              </div>
              <div>
                <div className="text-xs font-bold text-[#30264D] flex items-center gap-1.5">
                  <span>{current.sender}</span>
                  <CheckCircle2 className="w-3.5 h-3.5 text-[#36B77A]" />
                </div>
                <div className="text-[10px] text-slate-400">
                  {current.context} • {current.time}
                </div>
              </div>
            </div>
            <div className="flex gap-0.5 text-yellow-400">
              {[...Array(5)].map((_, i) => (
                <Star key={i} className="w-3.5 h-3.5 fill-current" />
              ))}
            </div>
          </div>

          {/* Balões de Mensagem */}
          <div className="space-y-2.5 my-4">
            {current.messages.map((msg, i) => (
              <div
                key={i}
                className="bg-[#F7F5FC] p-3 rounded-2xl rounded-tl-xs border border-slate-100 text-xs text-slate-700 leading-relaxed"
              >
                {msg}
              </div>
            ))}
          </div>

          {/* Navegação */}
          <div className="pt-3 border-t border-slate-100 flex items-center justify-between text-xs text-slate-400">
            <span>Feedback {activeFeedbackIndex + 1} de {feedbacks.length}</span>
            <div className="flex items-center gap-1.5">
              <button
                onClick={prev}
                className="w-7 h-7 rounded-lg bg-slate-100 hover:bg-[#6657C8] hover:text-white flex items-center justify-center transition-colors cursor-pointer"
                aria-label="Feedback anterior"
              >
                <ChevronLeft className="w-4 h-4" />
              </button>
              <button
                onClick={next}
                className="w-7 h-7 rounded-lg bg-slate-100 hover:bg-[#6657C8] hover:text-white flex items-center justify-center transition-colors cursor-pointer"
                aria-label="Próximo feedback"
              >
                <ChevronRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>

      </div>
    </section>
  );
};
