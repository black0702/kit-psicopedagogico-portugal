import React from 'react';
import { CheckCircle2, ShieldCheck, Sparkles, Layers } from 'lucide-react';
import { CONFIG } from '../data/landingData';

interface OfferProps {
  onCheckout: () => void;
}

export const Offer: React.FC<OfferProps> = ({ onCheckout }) => {
  const offerItems = [
    '+200 recursos estruturados',
    '8 áreas organizadas por objetivos',
    'Materiais visuais de alta legibilidade',
    'Atividades práticas de intervenção',
    'Fichas de acompanhamento e checklists',
    'Todos os 5 bônus complementares inclusos',
    'Material digital em formato PDF A4',
  ];

  return (
    <section id="oferta" className="py-16 sm:py-24 px-4 bg-[#F7F5FC] relative">
      <div className="max-w-4xl mx-auto">
        {/* Section Header */}
        <div className="text-center max-w-2xl mx-auto mb-10 sm:mb-12">
          <span className="text-xs font-bold text-[#6657C8] uppercase tracking-wider bg-[#E9E5F8] px-3.5 py-1.5 rounded-full mb-3 inline-block">
            CONDIÇÃO ESPECIAL
          </span>
          <h2 className="text-2xl sm:text-3xl md:text-4xl font-extrabold text-[#30264D] mb-3 font-display">
            Tenha acesso à Biblioteca Visual Psicopedagógica
          </h2>
          <p className="text-sm sm:text-base text-slate-600 leading-relaxed">
            Acesso completo a mais de 200 recursos organizados para enriquecer suas avaliações e intervenções.
          </p>
        </div>

        {/* Main Offer Card */}
        <div className="bg-white rounded-3xl border-2 border-[#6657C8] shadow-2xl overflow-hidden relative">
          {/* Top Most Wanted Ribbon */}
          <div className="bg-[#6657C8] text-white py-2 px-4 text-center text-xs font-bold uppercase tracking-wider flex items-center justify-center gap-1.5">
            <Sparkles className="w-4 h-4 text-yellow-300" />
            <span>KIT COMPLETO + 5 BÔNUS EXCLUSIVOS</span>
          </div>

          <div className="p-6 sm:p-10">
            <div className="grid grid-cols-1 md:grid-cols-12 gap-8 items-center">
              
              {/* Left Column: Title, Deliverables */}
              <div className="md:col-span-7 space-y-4">
                <div>
                  <span className="text-xs font-bold uppercase tracking-wider text-[#36B77A] bg-[#36B77A]/10 px-2.5 py-1 rounded-full">
                    Acesso Digital
                  </span>
                  <h3 className="text-xl sm:text-2xl font-extrabold text-[#30264D] mt-2 font-display leading-tight">
                    {CONFIG.productName}
                  </h3>
                  <p className="text-xs text-slate-500 mt-1">
                    Acervo completo pronto para consulta e impressão em PDF.
                  </p>
                </div>

                {/* Items List */}
                <div className="space-y-2.5 pt-2 border-t border-slate-100">
                  {offerItems.map((item, idx) => (
                    <div key={idx} className="flex items-center gap-2.5 text-xs sm:text-sm text-[#30264D]">
                      <div className="w-4 h-4 rounded-full bg-[#36B77A]/15 text-[#36B77A] flex items-center justify-center shrink-0">
                        <CheckCircle2 className="w-3.5 h-3.5" />
                      </div>
                      <span className="font-medium">{item}</span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Right Column: Pricing & Checkout CTA */}
              <div className="md:col-span-5 bg-[#F7F5FC] p-6 sm:p-8 rounded-2xl border border-[#E9E5F8] text-center flex flex-col justify-between">
                <div>
                  <div className="text-xs text-slate-400 line-through mb-1">
                    De R$ {CONFIG.regularPrice}
                  </div>
                  
                  <div className="text-xs text-[#30264D] font-bold uppercase tracking-wider mb-2">
                    Por apenas
                  </div>

                  <div className="flex items-baseline justify-center gap-1 mb-2">
                    <span className="text-lg font-bold text-[#30264D]">R$</span>
                    <span className="text-4xl sm:text-5xl font-black text-[#6657C8] font-display">
                      {CONFIG.offerPrice}
                    </span>
                  </div>

                  <div className="text-xs font-semibold text-slate-600 bg-white py-1.5 px-3 rounded-lg border border-[#E9E5F8] inline-block mb-6">
                    Pagamento único
                  </div>
                </div>

                <div>
                  <button
                    onClick={onCheckout}
                    className="w-full py-4 px-6 text-base font-bold text-white bg-[#6657C8] hover:bg-[#5545B3] rounded-2xl shadow-lg hover:shadow-xl hover:-translate-y-0.5 active:translate-y-0 transition-all duration-200 cursor-pointer mb-3"
                  >
                    QUERO ACESSAR AGORA
                  </button>

                  <div className="flex items-center justify-center gap-1.5 text-[11px] text-slate-500 font-medium">
                    <ShieldCheck className="w-3.5 h-3.5 text-[#36B77A]" />
                    <span>7 dias de garantia incondicional</span>
                  </div>
                </div>
              </div>

            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
