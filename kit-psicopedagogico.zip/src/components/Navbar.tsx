import React, { useState } from 'react';
import { Menu, X, ArrowRight, ShieldCheck, Download } from 'lucide-react';

interface NavbarProps {
  onCtaClick: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({ onCtaClick }) => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  return (
    <header className="sticky top-0 z-40 bg-[#FAF6EE]/95 backdrop-blur-md border-b border-[#E8E1D3] transition-all">
      {/* Barra de Notificação Superior */}
      <div className="bg-[#123C4A] text-white text-xs py-2 px-4 text-center font-medium flex items-center justify-center gap-2">
        <span className="inline-block w-2 h-2 rounded-full bg-[#25A69A] animate-pulse"></span>
        <span>Acesso Digital Imediato para Portugal • Pagamento Único sem Mensalidades</span>
      </div>

      <nav className="max-w-6xl mx-auto px-4 py-3.5 flex items-center justify-between">
        {/* Logótipo e Identificador */}
        <a href="#" className="flex items-center gap-2.5 text-[#123C4A] group">
          <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-[#123C4A] to-[#25A69A] text-white flex items-center justify-center font-bold text-lg shadow-sm">
            KP
          </div>
          <div className="flex flex-col">
            <span className="font-heading font-black text-base text-[#123C4A] leading-tight">
              Kit Psicopedagógico
            </span>
            <span className="text-[10px] text-[#25A69A] font-semibold uppercase tracking-wider">
              Portugal 🇵🇹 Edição Digital
            </span>
          </div>
        </a>

        {/* Links Desktop */}
        <div className="hidden md:flex items-center gap-7 text-xs font-semibold text-[#182B35]">
          <a href="#solucao" className="hover:text-[#25A69A] transition-colors">A Solução</a>
          <a href="#conteudo" className="hover:text-[#25A69A] transition-colors">O que inclui</a>
          <a href="#galeria" className="hover:text-[#25A69A] transition-colors">Amostras Reais</a>
          <a href="#publico" className="hover:text-[#25A69A] transition-colors">Para quem é</a>
          <a href="#bonuses" className="hover:text-[#25A69A] transition-colors">Bónus</a>
          <a href="#planos" className="hover:text-[#25A69A] transition-colors">Planos & Preços</a>
          <a href="#faq" className="hover:text-[#25A69A] transition-colors">Dúvidas</a>
        </div>

        {/* CTA Principal Desktop */}
        <div className="hidden md:flex items-center gap-3">
          <button
            onClick={onCtaClick}
            className="px-5 py-2.5 bg-[#25A69A] hover:bg-[#1E8E84] text-white font-bold text-xs rounded-full shadow-md hover:shadow-lg transition-all duration-200 cursor-pointer flex items-center gap-1.5"
          >
            <span>Ver Planos a partir de 4,90 €</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>

        {/* Mobile Toggle */}
        <button
          onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
          className="md:hidden p-2 text-[#182B35] hover:text-[#25A69A] transition-colors focus:outline-hidden"
          aria-label={mobileMenuOpen ? 'Fechar menu' : 'Abrir menu'}
        >
          {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
        </button>
      </nav>

      {/* Menu Dropdown Mobile */}
      {mobileMenuOpen && (
        <div className="md:hidden bg-white border-b border-[#E2EBE8] px-4 pt-3 pb-6 flex flex-col gap-3.5 shadow-xl animate-fadeIn">
          <a 
            href="#solucao" 
            onClick={() => setMobileMenuOpen(false)}
            className="text-sm font-semibold text-[#182B35] py-1 border-b border-slate-100"
          >
            A Solução
          </a>
          <a 
            href="#conteudo" 
            onClick={() => setMobileMenuOpen(false)}
            className="text-sm font-semibold text-[#182B35] py-1 border-b border-slate-100"
          >
            O que inclui
          </a>
          <a 
            href="#galeria" 
            onClick={() => setMobileMenuOpen(false)}
            className="text-sm font-semibold text-[#182B35] py-1 border-b border-slate-100"
          >
            Amostras Reais
          </a>
          <a 
            href="#publico" 
            onClick={() => setMobileMenuOpen(false)}
            className="text-sm font-semibold text-[#182B35] py-1 border-b border-slate-100"
          >
            Para quem é
          </a>
          <a 
            href="#bonuses" 
            onClick={() => setMobileMenuOpen(false)}
            className="text-sm font-semibold text-[#182B35] py-1 border-b border-slate-100"
          >
            Bónus Exclusivos
          </a>
          <a 
            href="#planos" 
            onClick={() => setMobileMenuOpen(false)}
            className="text-sm font-semibold text-[#182B35] py-1 border-b border-slate-100"
          >
            Planos & Preços (a partir de 4,90 €)
          </a>
          <a 
            href="#faq" 
            onClick={() => setMobileMenuOpen(false)}
            className="text-sm font-semibold text-[#182B35] py-1 border-b border-slate-100"
          >
            Perguntas Frequentes
          </a>
          <button
            onClick={() => {
              setMobileMenuOpen(false);
              onCtaClick();
            }}
            className="w-full mt-2 py-3 bg-[#25A69A] text-white font-bold text-sm rounded-xl shadow-md flex items-center justify-center gap-2"
          >
            <Download className="w-4 h-4" />
            <span>Quero conhecer o Kit Completo</span>
          </button>
        </div>
      )}
    </header>
  );
};
