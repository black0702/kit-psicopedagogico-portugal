import React from 'react';
import { Layers } from 'lucide-react';

interface HeroProps {
  onCtaClick: () => void;
  onExploreClick: () => void;
}

export const Hero: React.FC<HeroProps> = ({ onCtaClick, onExploreClick }) => {
  return (
    <section className="pt-8 sm:pt-14 pb-10 sm:pb-16 px-4 bg-[#F7F5FC] text-center relative overflow-hidden">
      <div className="max-w-5xl mx-auto">
        {/* Rótulo superior */}
        <div className="inline-block mb-3.5">
          <span className="text-xs sm:text-sm font-bold uppercase tracking-wider text-[#6657C8] bg-[#E9E5F8] px-3.5 py-1.5 rounded-full">
            RECURSOS PSICOPEDAGÓGICOS PRÁTICOS
          </span>
        </div>

        {/* Título Principal */}
        <h1 className="text-3xl sm:text-4xl md:text-5xl font-extrabold text-[#30264D] leading-[1.15] mb-4 sm:mb-6 font-display text-balance">
          +200 Recursos Visuais para Avaliação e Intervenção Psicopedagógica
        </h1>

        {/* Subtítulo */}
        <p className="text-base sm:text-lg md:text-xl text-[#27243A]/85 max-w-2xl mx-auto mb-4 leading-relaxed text-balance">
          Tenha uma biblioteca organizada de materiais para consultar, selecionar e utilizar nos seus atendimentos — sem precisar começar cada atividade do zero.
        </p>

        {/* Linha de Apoio */}
        <div className="text-xs sm:text-sm font-medium text-slate-500 mb-8 flex items-center justify-center flex-wrap gap-2">
          <span>Mais organização</span>
          <span className="text-[#6657C8]">•</span>
          <span>Consulta rápida</span>
          <span className="text-[#6657C8]">•</span>
          <span>Materiais visuais</span>
          <span className="text-[#6657C8]">•</span>
          <span>PDF</span>
        </div>

        {/* CTAs */}
        <div className="flex flex-col sm:flex-row items-center justify-center gap-3 sm:gap-4 mb-8 sm:mb-12">
          <button
            onClick={onCtaClick}
            className="w-full sm:w-auto px-8 py-4 text-base sm:text-lg font-bold text-white bg-[#6657C8] hover:bg-[#5545B3] rounded-2xl shadow-lg hover:shadow-xl hover:-translate-y-0.5 active:translate-y-0 transition-all duration-200 cursor-pointer"
          >
            QUERO ACESSAR OS +200 RECURSOS
          </button>
          <button
            onClick={onExploreClick}
            className="w-full sm:w-auto px-7 py-4 text-sm sm:text-base font-semibold text-[#30264D] bg-white hover:bg-slate-50 border border-[#E9E5F8] rounded-2xl shadow-sm hover:shadow transition-all duration-200 cursor-pointer"
          >
            VER O QUE VEM NO KIT
          </button>
        </div>

        {/* HERO MOCKUP OFICIAL */}
        <div className="relative w-full max-w-4xl mx-auto my-6 select-none group">
          {/* Subtle soft glow backdrop */}
          <div className="absolute inset-0 bg-gradient-to-r from-[#6657C8]/20 via-[#36B77A]/15 to-[#6657C8]/20 rounded-3xl blur-2xl -z-10" />

          {/* Frame */}
          <div className="bg-white p-3 sm:p-5 rounded-2xl sm:rounded-3xl border border-[#E9E5F8] shadow-2xl overflow-hidden">
            <div className="flex items-center justify-between pb-3 mb-3 border-b border-slate-100 text-xs text-[#6657C8] font-bold">
              <span className="flex items-center gap-1.5 uppercase tracking-wider font-mono text-[11px]">
                <Layers className="w-4 h-4 text-[#6657C8]" />
                [HERO MOCKUP — +200 RECURSOS]
              </span>
              <span className="bg-[#36B77A]/15 text-[#36B77A] text-[10px] px-2.5 py-1 rounded-full font-semibold">
                PDF • Formato A4 Pronto para Impressão
              </span>
            </div>

            <div className="rounded-xl sm:rounded-2xl overflow-hidden bg-slate-50 border border-slate-100 shadow-inner">
              <img
                src="/src/assets/images/hero_psicopedagogica_1790619307468.jpg"
                alt="Kit de Recursos para Avaliação e Intervenção Psicopedagógica"
                referrerPolicy="no-referrer"
                className="w-full h-auto object-cover transform hover:scale-[1.01] transition-transform duration-300"
              />
            </div>

            {/* Bottom info strip */}
            <div className="mt-4 pt-3 border-t border-slate-100 flex flex-wrap items-center justify-between gap-2 text-xs text-slate-600">
              <div className="flex items-center gap-2">
                <span className="w-2 h-2 rounded-full bg-[#36B77A] animate-pulse" />
                <span className="font-semibold text-slate-700">Material completo:</span>
                <span className="text-slate-500">Avaliação • Intervenção • Fichas • Jogos • Bônus Exclusivos</span>
              </div>
              <button
                onClick={onExploreClick}
                className="text-[#6657C8] hover:text-[#5545B3] font-semibold text-xs flex items-center gap-1 transition-colors cursor-pointer"
              >
                Conhecer todos os recursos
                <span aria-hidden="true">&darr;</span>
              </button>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
