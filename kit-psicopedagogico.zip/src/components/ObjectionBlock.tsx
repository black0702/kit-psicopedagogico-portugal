import React from 'react';
import { Sparkles } from 'lucide-react';

interface ObjectionBlockProps {
  onCtaClick: () => void;
}

export const ObjectionBlock: React.FC<ObjectionBlockProps> = ({ onCtaClick }) => {
  return (
    <section className="py-12 sm:py-16 px-4 bg-[#F7F5FC]">
      <div className="max-w-4xl mx-auto">
        <div className="bg-gradient-to-br from-[#30264D] via-[#3C3060] to-[#261E3D] text-white rounded-3xl p-7 sm:p-12 shadow-xl border-2 border-[#6657C8]/40 relative overflow-hidden text-center">
          {/* Subtle glow accents */}
          <div className="absolute top-0 right-0 w-48 h-48 bg-[#6657C8]/25 rounded-full blur-2xl -mr-16 -mt-16 pointer-events-none" />
          <div className="absolute bottom-0 left-0 w-48 h-48 bg-[#36B77A]/20 rounded-full blur-2xl -ml-16 -mb-16 pointer-events-none" />

          <div className="relative z-10 max-w-2xl mx-auto">
            <div className="inline-flex items-center gap-1.5 bg-white/10 text-white text-xs font-semibold px-3 py-1 rounded-full uppercase tracking-wider mb-4 border border-white/15">
              <Sparkles className="w-3.5 h-3.5 text-yellow-300" />
              FOCO NA SUA ROTINA
            </div>

            <h2 className="text-2xl sm:text-3xl md:text-4xl font-extrabold mb-4 font-display leading-tight text-white text-balance">
              Pare de começar cada atendimento procurando materiais do zero.
            </h2>

            <p className="text-sm sm:text-base text-slate-200 leading-relaxed mb-8 max-w-xl mx-auto">
              A proposta da Biblioteca Visual Psicopedagógica é reunir recursos em uma estrutura organizada, para que você consiga localizar e selecionar materiais com mais praticidade.
            </p>

            <button
              onClick={onCtaClick}
              className="w-full sm:w-auto px-8 py-4 text-base font-bold text-white bg-[#36B77A] hover:bg-[#2EA36C] rounded-2xl shadow-lg hover:shadow-xl transition-all duration-200 cursor-pointer"
            >
              QUERO TER ACESSO À BIBLIOTECA
            </button>
          </div>
        </div>
      </div>
    </section>
  );
};
