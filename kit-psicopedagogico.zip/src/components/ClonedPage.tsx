import React, { useEffect, useState } from "react";

export function ClonedPage() {
  const [popupOpen, setPopupOpen] = useState(false);

  useEffect(() => {
    // Intercept clicks on #abrir-popup and modal close triggers
    const handleDocumentClick = (e: MouseEvent) => {
      const target = e.target as HTMLElement | null;
      if (!target) return;

      const triggerBtn = target.closest("#abrir-popup");
      if (triggerBtn) {
        e.preventDefault();
        setPopupOpen(true);
        return;
      }

      const closeBtn = target.closest("#fechar-popup");
      if (closeBtn) {
        e.preventDefault();
        setPopupOpen(false);
        return;
      }

      // Backdrop click
      const popupEl = document.getElementById("popup");
      if (popupEl && target === popupEl.firstElementChild) {
        setPopupOpen(false);
      }
    };

    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === "Escape") {
        setPopupOpen(false);
      }
    };

    document.addEventListener("click", handleDocumentClick);
    document.addEventListener("keydown", handleKeyDown);

    return () => {
      document.removeEventListener("click", handleDocumentClick);
      document.removeEventListener("keydown", handleKeyDown);
    };
  }, []);

  useEffect(() => {
    const popupEl = document.getElementById("popup");
    if (popupEl) {
      if (popupOpen) {
        popupEl.removeAttribute("hidden");
        document.body.style.overflow = "hidden";
      } else {
        popupEl.setAttribute("hidden", "true");
        document.body.style.overflow = "";
      }
    }
  }, [popupOpen]);

  return (
    <div
      dangerouslySetInnerHTML={{
        __html: `


<div style="font-family: 'Poppins', 'Segoe UI', system-ui, sans-serif; color: #5A4F63; font-size: 16px; line-height: 1.65; background: #FAF6EE">

<!-- Barra de oferta -->
<section style="padding: 64px 20px 72px">
<div style="max-width: 1100px; margin: 0 auto; display: flex; flex-direction: column; align-items: center; gap: 22px; text-align: center">
<span class="pill">Kit do Profissional Psicopedagógico</span>
<h1 class="h" style="font-size: clamp(36px, 5.4vw, 64px); max-width: 920px">Mais de 50 recursos de avaliação e 200 páginas de materiais visuais para <span style="color: #D2603A">apoiar</span> o seu trabalho</h1>
<p style="margin: 0; font-size: 19px; max-width: 720px">Manual completo, mapas mentais, fluxogramas, listas de verificação, documentos e modelos de relatório — tudo organizado para imprimir e utilizar, da queixa ao plano de intervenção.</p>

<div class="card" style="width: 100%; max-width: 980px; padding: 14px; box-sizing: border-box; margin-top: 12px; background: #FFFFFF"><img class="viva" src="/site_images/site_img_1.jpg" alt="Kit Psicopedagógica 2026 e 2027: material principal, cadernos de avaliação, intervenção, jogos, fichas e +3 bônus exclusivos em PDF" style="width: 100%; height: auto; border-radius: 14px"></div>

<div style="display: flex; flex-wrap: wrap; justify-content: center; gap: 14px; margin-top: 10px">
<a class="btn" href="#planos">Quero meu kit agora</a>
<a class="btn2" href="#amostras">Ver o que vem no kit</a>
</div>
<div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(250px, 1fr)); gap: 10px 32px; text-align: left; color: #2A1B3D; font-size: 15px; max-width: 600px; width: 100%">
<div class="chk"><svg width="22" height="22" viewBox="0 0 24 24"><circle cx="12" cy="12" r="11" fill="#3C9A5F"></circle><path d="m7.5 12.5 3 3 6-6.5" fill="none" stroke="#FFFFFF" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"></path></svg>+200 páginas visuais prontas</div>
<div class="chk"><svg width="22" height="22" viewBox="0 0 24 24"><circle cx="12" cy="12" r="11" fill="#3C9A5F"></circle><path d="m7.5 12.5 3 3 6-6.5" fill="none" stroke="#FFFFFF" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"></path></svg>Acesso imediato por e-mail</div>
<div class="chk"><svg width="22" height="22" viewBox="0 0 24 24"><circle cx="12" cy="12" r="11" fill="#3C9A5F"></circle><path d="m7.5 12.5 3 3 6-6.5" fill="none" stroke="#FFFFFF" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"></path></svg>Imprima sempre que precisar, de acordo com a licença de utilização</div>
<div class="chk"><svg width="22" height="22" viewBox="0 0 24 24"><circle cx="12" cy="12" r="11" fill="#3C9A5F"></circle><path d="m7.5 12.5 3 3 6-6.5" fill="none" stroke="#FFFFFF" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"></path></svg>Garantia incondicional de 7 dias</div>
</div>
<div style="font-size: 14px"><span style="color: #E8A317; letter-spacing: 2px">★★★★★</span> <strong style="color: #2A1B3D">+500 profissionais</strong> já usam o material</div>
</div>
</section><section style="background: #F3EBDD; padding: 96px 20px">
<div style="max-width: 1100px; margin: 0 auto; display: flex; flex-direction: column; gap: 44px">
<div style="display: flex; flex-direction: column; align-items: center; gap: 14px; text-align: center">
<span class="pill">Bônus exclusivos</span>
<h2 class="h" style="font-size: clamp(30px, 3.8vw, 44px)">Bónus exclusivos que complementam o seu kit</h2>
<p style="margin: 0">Inclusos gratuitamente no Combo Profissional.</p>
</div>
<div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(300px, 1fr)); gap: 22px">
<div class="card" style="overflow: hidden; display: flex; flex-direction: column"><div style="background: #FFFFFF; padding: 18px; height: 300px; box-sizing: border-box; display: flex; align-items: center; justify-content: center"><img class="viva" src="/site_images/site_img_2.jpg" alt="Sistema Completo de Aprendizagem — Drive Profissional" style="max-width: 88%; max-height: 250px; width: auto; height: auto; border-radius: 12px; border: 6px solid #FFFFFF; box-shadow: 0 18px 34px rgba(42,27,61,0.25); transform: rotate(-3deg)"></div><div style="padding: 24px; display: flex; flex-direction: column; gap: 8px"><span class="pill" style="align-self: flex-start">Bônus 1</span><h3 class="h" style="font-size: 21px">Drive Profissional — Sistema Completo de Aprendizagem</h3><p style="margin: 0; font-size: 15px">Triagem de dislexia, disgrafia, discalculia e TDAH, escalas, PEI e PDI, relatórios e anamnese editáveis em Word.</p></div></div>
<div class="card" style="overflow: hidden; display: flex; flex-direction: column"><div style="background: #FFFFFF; padding: 18px; height: 300px; box-sizing: border-box; display: flex; align-items: center; justify-content: center"><img class="viva" src="/site_images/site_img_3.jpg" alt="1.500 Atividades Infantis em PDF" style="max-width: 70%; max-height: 270px; width: auto; height: auto; border-radius: 12px; border: 6px solid #FFFFFF; box-shadow: 0 18px 34px rgba(42,27,61,0.25); transform: rotate(3deg)"></div><div style="padding: 24px; display: flex; flex-direction: column; gap: 8px"><span class="pill" style="align-self: flex-start">Bônus 2</span><h3 class="h" style="font-size: 21px">1.500 Atividades Infantis em PDF</h3><p style="margin: 0; font-size: 15px">Linguagem, raciocínio, alfabetização, coordenação motora e habilidades cognitivas.</p></div></div>
<div class="card" style="overflow: hidden; display: flex; flex-direction: column"><div style="background: #FFFFFF; padding: 18px; height: 300px; box-sizing: border-box; display: flex; align-items: center; justify-content: center"><img class="viva" src="/site_images/site_img_4.jpg" alt="Kit Visual de Hábitos, Comunicação e Regulação" style="max-width: 70%; max-height: 270px; width: auto; height: auto; border-radius: 12px; border: 6px solid #FFFFFF; box-shadow: 0 18px 34px rgba(42,27,61,0.25); transform: rotate(-3deg)"></div><div style="padding: 24px; display: flex; flex-direction: column; gap: 8px"><span class="pill" style="align-self: flex-start">Bônus 3</span><h3 class="h" style="font-size: 21px">Kit Visual de Hábitos, Comunicação e Regulação</h3><p style="margin: 0; font-size: 15px">Rotina visual, cartões de escolhas, emoções, cantinho calmo, transições e registro de observação.</p></div></div>
</div>
<div style="display: flex; flex-direction: column; gap: 18px">
<h3 class="h" style="font-size: 24px; text-align: center">+ 3 e-books sobre autismo</h3>
<div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(280px, 1fr)); gap: 16px">
<div class="card" style="padding: 16px; display: flex; gap: 14px; align-items: center"><img class="viva" src="/site_images/site_img_5.jpg" alt="Foco e Concentração no Autismo" style="flex: 0 0 96px; width: 96px; height: 84px; object-fit: contain"><div><strong style="color: #2A1B3D; font-size: 15px; line-height: 1.3; display: block">Foco e Concentração no Autismo</strong><div style="font-size: 13px"><s>17 €</s> · <strong style="color: #2B8A3E">Grátis</strong></div></div></div>
<div class="card" style="padding: 16px; display: flex; gap: 14px; align-items: center"><img class="viva" src="/site_images/site_img_6.jpg" alt="Guia Zero Comportamentos Críticos no Autismo" style="flex: 0 0 96px; width: 96px; height: 84px; object-fit: contain"><div><strong style="color: #2A1B3D; font-size: 15px; line-height: 1.3; display: block">Guia Zero Comportamentos Críticos</strong><div style="font-size: 13px"><s>22 €</s> · <strong style="color: #2B8A3E">Grátis</strong></div></div></div>
<div class="card" style="padding: 16px; display: flex; gap: 14px; align-items: center"><img class="viva" src="/site_images/site_img_7.jpg" alt="Manual Prático do Autismo para Pais e Profissionais" style="flex: 0 0 96px; width: 96px; height: 84px; object-fit: contain"><div><strong style="color: #2A1B3D; font-size: 15px; line-height: 1.3; display: block">Manual Prático do Autismo</strong><div style="font-size: 13px"><s>27 €</s> · <strong style="color: #2B8A3E">Grátis</strong></div></div></div>
</div>
</div>
</div>
</section><section style="padding: 80px 20px 0">
<div class="card" style="max-width: 760px; margin: 0 auto; padding: 44px 32px; text-align: center; display: flex; flex-direction: column; align-items: center; gap: 14px; border: 2px dashed #E9B9A3">
<span style="width: 56px; height: 56px; border-radius: 50%; background: #FFE8CC; display: flex; align-items: center; justify-content: center"><svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="#D9480F" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M6 2h12M6 22h12M7 2v4l5 6-5 6v4M17 2v4l-5 6 5 6v4"></path></svg></span>
<h2 class="h" style="font-size: 32px">Oferta por tempo limitado</h2>
<p style="margin: 0; max-width: 560px">Adquira hoje o Pack Completo com todos os bónus pelo valor promocional e use em todos os seus atendimentos futuros, <strong style="color: #2A1B3D">sem pagar de novo</strong>.</p>
<a class="btn" href="#planos" style="margin-top: 6px">Quero adquirir o meu kit</a>
</div>
</section><div style="background: #2A1B3D; color: #FFFFFF; text-align: center; padding: 11px 16px; font-size: 14px"><strong>Oferta especial por tempo limitado:</strong> Apostila + Guia Prático 2026 + bônus exclusivos com acesso imediato.</div>

<!-- HERO -->


<!-- Amostras -->
<section id="amostras" style="background: #F3EBDD; padding: 88px 0">
<div style="display: flex; flex-direction: column; align-items: center; gap: 14px; text-align: center; padding: 0 20px">
<h2 class="h" style="font-size: clamp(30px, 3.8vw, 44px)">Amostras reais do material</h2>
<p style="margin: 0; max-width: 560px">Páginas ilustradas que você recebe — prontas para imprimir e usar nos atendimentos.</p>
</div>
<div style="overflow: hidden; margin-top: 44px; padding: 10px 0 30px; -webkit-mask-image: linear-gradient(90deg, transparent, #000 6%, #000 94%, transparent); mask-image: linear-gradient(90deg, transparent, #000 6%, #000 94%, transparent)">
<div class="track">
<div class="page"><img class="viva" src="/site_images/site_img_8.jpg" alt="Avaliação Psicopedagógica 2026 e 2027"></div>
<div class="page"><img class="viva" src="/site_images/site_img_9.jpg" alt="Plano de Intervenção Psicopedagógico"></div>
<div class="page"><img class="viva" src="/site_images/site_img_10.jpg" alt="Atividades de Estímulo Cognitivo e Aprendizagem"></div>
<div class="page"><img class="viva" src="/site_images/site_img_11.jpg" alt="Recursos Lúdicos e Materiais Manipulativos"></div>
<div class="page"><img class="viva" src="/site_images/site_img_12.jpg" alt="Jogos Psicopedagógicos"></div>
<div class="page"><img class="viva" src="/site_images/site_img_13.jpg" alt="Sequência Didática para o Desenvolvimento das Habilidades"></div>
<div class="page"><img class="viva" src="/site_images/site_img_14.jpg" alt="Registro de Evolução e Acompanhamento"></div>
<div class="page"><img class="viva" src="/site_images/site_img_15.jpg" alt="Bônus 1: Kit Psicopedagógico Completo"></div>
<div class="page"><img class="viva" src="/site_images/site_img_16.jpg" alt="Planejamento Anual 2026 e 2027"></div>
<div class="page"><img class="viva" src="/site_images/site_img_17.jpg" alt="Cards de Estímulos Cognitivos"></div>
<div class="page"><img class="viva" src="/site_images/site_img_18.jpg" alt="Bônus 2: Técnicas de Intervenção"></div>
<div class="page"><img class="viva" src="/site_images/site_img_19.jpg" alt="Dinâmicas e Atividades em Grupo"></div>
<div class="page"><img class="viva" src="/site_images/site_img_20.jpg" alt="Bônus 3: Guia de Inclusão Escolar e AEE"></div>
<div class="page"><img class="viva" src="/site_images/site_img_21.jpg" alt="Projetos Psicopedagógicos"></div>
<div class="page"><img class="viva" src="/site_images/site_img_22.jpg" alt="Passo a passo"></div>
<div class="page" aria-hidden="true"><img class="viva" src="/site_images/site_img_23.jpg" alt=""></div>
<div class="page" aria-hidden="true"><img class="viva" src="/site_images/site_img_24.jpg" alt=""></div>
<div class="page" aria-hidden="true"><img class="viva" src="/site_images/site_img_25.jpg" alt=""></div>
<div class="page" aria-hidden="true"><img class="viva" src="/site_images/site_img_26.jpg" alt=""></div>
<div class="page" aria-hidden="true"><img class="viva" src="/site_images/site_img_27.jpg" alt=""></div>
<div class="page" aria-hidden="true"><img class="viva" src="/site_images/site_img_28.jpg" alt=""></div>
<div class="page" aria-hidden="true"><img class="viva" src="/site_images/site_img_29.jpg" alt=""></div>
<div class="page" aria-hidden="true"><img class="viva" src="/site_images/site_img_30.jpg" alt=""></div>
<div class="page" aria-hidden="true"><img class="viva" src="/site_images/site_img_31.jpg" alt=""></div>
<div class="page" aria-hidden="true"><img class="viva" src="/site_images/site_img_32.jpg" alt=""></div>
<div class="page" aria-hidden="true"><img class="viva" src="/site_images/site_img_33.jpg" alt=""></div>
<div class="page" aria-hidden="true"><img class="viva" src="/site_images/site_img_34.jpg" alt=""></div>
<div class="page" aria-hidden="true"><img class="viva" src="/site_images/site_img_35.jpg" alt=""></div>
<div class="page" aria-hidden="true"><img class="viva" src="/site_images/site_img_36.jpg" alt=""></div>
<div class="page" aria-hidden="true"><img class="viva" src="/site_images/site_img_37.jpg" alt=""></div>
</div>
</div>
<div style="text-align: center; margin-top: 16px; padding: 0 20px"><a class="btn" href="#planos">Quero receber todo o material</a></div>
</section>

<!-- Módulos -->
<section style="padding: 96px 20px">
<div style="max-width: 1100px; margin: 0 auto; display: flex; flex-direction: column; gap: 44px">
<div style="display: flex; flex-direction: column; align-items: center; gap: 14px; text-align: center">
<span class="pill">Conteúdo do material</span>
<h2 class="h" style="font-size: clamp(30px, 3.8vw, 44px); max-width: 720px">6 eixos para avaliar e intervir com segurança</h2>
<p style="margin: 0; max-width: 600px">Uma estrutura completa que cobre cada área investigada no processo diagnóstico.</p>
</div>
<div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(300px, 1fr)); gap: 20px">
<div class="card" style="padding: 28px; display: flex; flex-direction: column; gap: 10px"><span style="width: 46px; height: 46px; border-radius: 14px; background: #FFE8CC; display: flex; align-items: center; justify-content: center"><svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="#D9480F" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M9 5H7a2 2 0 0 0-2 2v12a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2V7a2 2 0 0 0-2-2h-2"></path><rect x="9" y="3" width="6" height="4" rx="1"></rect><path d="M9 12h6M9 16h4"></path></svg></span><h3 class="h" style="font-size: 20px">1. Anamnese e áreas avaliativas</h3><p style="margin: 0; font-size: 15px">Orientações para cada etapa do diagnóstico, cruzando dados da criança, da família e da escola.</p></div>
<div class="card" style="padding: 28px; display: flex; flex-direction: column; gap: 10px"><span style="width: 46px; height: 46px; border-radius: 14px; background: #D3F9D8; display: flex; align-items: center; justify-content: center"><svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="#2B8A3E" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M2 4h6a4 4 0 0 1 4 4v13a3 3 0 0 0-3-3H2z"></path><path d="M22 4h-6a4 4 0 0 0-4 4v13a3 3 0 0 1 3-3h7z"></path></svg></span><h3 class="h" style="font-size: 20px">2. Leitura, escrita e fonologia</h3><p style="margin: 0; font-size: 15px">Testes padronizados, consciência fonológica e protocolos de análise para dislexia e disortografia.</p></div>
<div class="card" style="padding: 28px; display: flex; flex-direction: column; gap: 10px"><span style="width: 46px; height: 46px; border-radius: 14px; background: #DBE4FF; display: flex; align-items: center; justify-content: center"><svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="#364FC7" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="4" y="2" width="16" height="20" rx="2"></rect><path d="M8 6h8M8 11h2M14 11h2M8 15h2M14 15h2M8 19h2M14 19h2"></path></svg></span><h3 class="h" style="font-size: 20px">3. Matemática e raciocínio</h3><p style="margin: 0; font-size: 15px">Mapas e instrumentos para investigar dificuldades matemáticas e discalculia.</p></div>
<div class="card" style="padding: 28px; display: flex; flex-direction: column; gap: 10px"><span style="width: 46px; height: 46px; border-radius: 14px; background: #F3D9FA; display: flex; align-items: center; justify-content: center"><svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="#9C36B5" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="9"></circle><circle cx="12" cy="12" r="5"></circle><circle cx="12" cy="12" r="1"></circle></svg></span><h3 class="h" style="font-size: 20px">4. Atenção, memória e funções executivas</h3><p style="margin: 0; font-size: 15px">Instrumentos para avaliar atenção, memória e organização do pensamento.</p></div>
<div class="card" style="padding: 28px; display: flex; flex-direction: column; gap: 10px"><span style="width: 46px; height: 46px; border-radius: 14px; background: #FFDEEB; display: flex; align-items: center; justify-content: center"><svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="#C2255C" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M19 14c1.5-1.5 3-3.2 3-5.5A5.5 5.5 0 0 0 16.5 3c-1.8 0-3 .5-4.5 2-1.5-1.5-2.7-2-4.5-2A5.5 5.5 0 0 0 2 8.5c0 2.3 1.5 4 3 5.5l7 7z"></path></svg></span><h3 class="h" style="font-size: 20px">5. TDAH, TEA e transtornos</h3><p style="margin: 0; font-size: 15px">Sinais relacionados ao TDAH, TEA e às dificuldades de aprendizagem, sem conclusões precipitadas.</p></div>
<div class="card" style="padding: 28px; display: flex; flex-direction: column; gap: 10px"><span style="width: 46px; height: 46px; border-radius: 14px; background: #C5F6FA; display: flex; align-items: center; justify-content: center"><svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="#0B7285" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M5 12h14M13 5l7 7-7 7"></path></svg></span><h3 class="h" style="font-size: 20px">6. Devolutiva e intervenção</h3><p style="margin: 0; font-size: 15px">Modelos de devolutiva, encaminhamentos e transformação dos achados em plano de intervenção.</p></div>
</div>
</div>
</section>



<!-- Para quem é -->
<section style="background: #F3EBDD; padding: 96px 20px">
<div style="max-width: 1000px; margin: 0 auto; display: flex; flex-direction: column; gap: 40px">
<div style="display: flex; flex-direction: column; align-items: center; gap: 14px; text-align: center">
<h2 class="h" style="font-size: clamp(30px, 3.8vw, 44px)">Para quem é o Kit</h2>
<p style="margin: 0">Feito para quem avalia dificuldades de aprendizagem e quer fazer isso com mais segurança.</p>
</div>
<div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(300px, 1fr)); gap: 16px; color: #2A1B3D">
<div class="card chk" style="padding: 20px 22px"><svg width="22" height="22" viewBox="0 0 24 24"><circle cx="12" cy="12" r="11" fill="#3C9A5F"></circle><path d="m7.5 12.5 3 3 6-6.5" fill="none" stroke="#FFFFFF" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"></path></svg><span>Psicopedagogos clínicos ou institucionais</span></div>
<div class="card chk" style="padding: 20px 22px"><svg width="22" height="22" viewBox="0 0 24 24"><circle cx="12" cy="12" r="11" fill="#3C9A5F"></circle><path d="m7.5 12.5 3 3 6-6.5" fill="none" stroke="#FFFFFF" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"></path></svg><span>Neuropsicopedagogos</span></div>
<div class="card chk" style="padding: 20px 22px"><svg width="22" height="22" viewBox="0 0 24 24"><circle cx="12" cy="12" r="11" fill="#3C9A5F"></circle><path d="m7.5 12.5 3 3 6-6.5" fill="none" stroke="#FFFFFF" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"></path></svg><span>Professores da educação infantil e fundamental</span></div>
<div class="card chk" style="padding: 20px 22px"><svg width="22" height="22" viewBox="0 0 24 24"><circle cx="12" cy="12" r="11" fill="#3C9A5F"></circle><path d="m7.5 12.5 3 3 6-6.5" fill="none" stroke="#FFFFFF" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"></path></svg><span>Estudantes de pedagogia e psicopedagogia</span></div>
<div class="card chk" style="padding: 20px 22px"><svg width="22" height="22" viewBox="0 0 24 24"><circle cx="12" cy="12" r="11" fill="#3C9A5F"></circle><path d="m7.5 12.5 3 3 6-6.5" fill="none" stroke="#FFFFFF" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"></path></svg><span>Profissionais que trabalham com dificuldades de aprendizagem</span></div>
<div class="card chk" style="padding: 20px 22px"><svg width="22" height="22" viewBox="0 0 24 24"><circle cx="12" cy="12" r="11" fill="#3C9A5F"></circle><path d="m7.5 12.5 3 3 6-6.5" fill="none" stroke="#FFFFFF" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"></path></svg><span>Quem atende crianças com sinais de TDAH ou TEA</span></div>
</div>
</div>
</section>

<!-- Oferta -->


<!-- Do primeiro ao último -->


<!-- Bônus -->


<!-- Passo a passo -->
<section style="padding: 96px 20px">
<div style="max-width: 1100px; margin: 0 auto; display: flex; flex-wrap: wrap; gap: 56px; align-items: center">
<div style="flex: 1 1 420px; min-width: 0"><img class="viva" src="/site_images/site_img_38.jpg" alt="Apostila Psicopedagógica 2026 e 2027 com cadernos de avaliação, atividades de estímulo, recursos lúdicos e jogos" style="width: 100%; border-radius: 26px; box-shadow: 0 26px 50px rgba(42,27,61,0.2)"></div>
<div style="flex: 1 1 440px; min-width: 0; display: flex; flex-direction: column; gap: 20px">
<span class="pill" style="align-self: flex-start">Tudo que você recebe</span>
<h2 class="h" style="font-size: clamp(30px, 3.8vw, 42px)">Do primeiro ao último recurso</h2>
<p style="margin: 0">Tudo organizado por área, pronto para imprimir e utilizar.</p>
<div style="display: flex; flex-direction: column; gap: 10px; color: #2A1B3D; font-size: 15px">
<div class="card chk" style="padding: 12px 18px; border-radius: 999px"><svg width="22" height="22" viewBox="0 0 24 24"><circle cx="12" cy="12" r="11" fill="#3C9A5F"></circle><path d="m7.5 12.5 3 3 6-6.5" fill="none" stroke="#FFFFFF" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"></path></svg><span><strong>+50</strong> testes psicopedagógicos sistematizados</span></div>
<div class="card chk" style="padding: 12px 18px; border-radius: 999px"><svg width="22" height="22" viewBox="0 0 24 24"><circle cx="12" cy="12" r="11" fill="#3C9A5F"></circle><path d="m7.5 12.5 3 3 6-6.5" fill="none" stroke="#FFFFFF" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"></path></svg><span><strong>127</strong> páginas de apostila teórica e prática</span></div>
<div class="card chk" style="padding: 12px 18px; border-radius: 999px"><svg width="22" height="22" viewBox="0 0 24 24"><circle cx="12" cy="12" r="11" fill="#3C9A5F"></circle><path d="m7.5 12.5 3 3 6-6.5" fill="none" stroke="#FFFFFF" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"></path></svg><span><strong>30+</strong> páginas visuais do Guia Prático 2026</span></div>
<div class="card chk" style="padding: 12px 18px; border-radius: 999px"><svg width="22" height="22" viewBox="0 0 24 24"><circle cx="12" cy="12" r="11" fill="#3C9A5F"></circle><path d="m7.5 12.5 3 3 6-6.5" fill="none" stroke="#FFFFFF" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"></path></svg><span>Mapas de funções executivas, leitura, escrita, matemática, TEA e TDAH</span></div>
<div class="card chk" style="padding: 12px 18px; border-radius: 999px"><svg width="22" height="22" viewBox="0 0 24 24"><circle cx="12" cy="12" r="11" fill="#3C9A5F"></circle><path d="m7.5 12.5 3 3 6-6.5" fill="none" stroke="#FFFFFF" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"></path></svg><span>Modelos de relatório para encarregados de educação e escola</span></div>
<div class="card chk" style="padding: 12px 18px; border-radius: 999px"><svg width="22" height="22" viewBox="0 0 24 24"><circle cx="12" cy="12" r="11" fill="#3C9A5F"></circle><path d="m7.5 12.5 3 3 6-6.5" fill="none" stroke="#FFFFFF" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"></path></svg><span>Fichas de acompanhamento e documentos administrativos</span></div>
<div class="card chk" style="padding: 12px 18px; border-radius: 999px"><svg width="22" height="22" viewBox="0 0 24 24"><circle cx="12" cy="12" r="11" fill="#3C9A5F"></circle><path d="m7.5 12.5 3 3 6-6.5" fill="none" stroke="#FFFFFF" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"></path></svg><span><strong>1.500</strong> atividades infantis e <strong>20</strong> jogos educativos</span></div>
</div>
</div>
</div>
</section><section style="padding: 96px 20px">
<div style="max-width: 1100px; margin: 0 auto; display: flex; flex-direction: column; gap: 40px">
<div style="display: flex; flex-direction: column; align-items: center; gap: 14px; text-align: center">
<h2 class="h" style="font-size: clamp(30px, 3.8vw, 44px)">Passo a passo do acesso</h2>
<p style="margin: 0">Da compra à utilização no seu gabinete em poucos minutos.</p>
</div>
<div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(180px, 1fr)); gap: 16px; text-align: center">
<div class="card" style="padding: 26px 18px; display: flex; flex-direction: column; align-items: center; gap: 10px"><span class="h" style="width: 44px; height: 44px; border-radius: 50%; background: #2A1B3D; color: #FFFFFF; display: flex; align-items: center; justify-content: center; font-size: 18px">1</span><strong style="color: #2A1B3D">Você garante o kit</strong><span style="font-size: 14px">Escolha o plano e conclua o pagamento.</span></div>
<div class="card" style="padding: 26px 18px; display: flex; flex-direction: column; align-items: center; gap: 10px"><span class="h" style="width: 44px; height: 44px; border-radius: 50%; background: #2A1B3D; color: #FFFFFF; display: flex; align-items: center; justify-content: center; font-size: 18px">2</span><strong style="color: #2A1B3D">Recebe por e-mail</strong><span style="font-size: 14px">O acesso chega logo após a confirmação.</span></div>
<div class="card" style="padding: 26px 18px; display: flex; flex-direction: column; align-items: center; gap: 10px"><span class="h" style="width: 44px; height: 44px; border-radius: 50%; background: #2A1B3D; color: #FFFFFF; display: flex; align-items: center; justify-content: center; font-size: 18px">3</span><strong style="color: #2A1B3D">Descarregue os ficheiros</strong><span style="font-size: 14px">PDFs e documentos editáveis no telemóvel ou computador.</span></div>
<div class="card" style="padding: 26px 18px; display: flex; flex-direction: column; align-items: center; gap: 10px"><span class="h" style="width: 44px; height: 44px; border-radius: 50%; background: #2A1B3D; color: #FFFFFF; display: flex; align-items: center; justify-content: center; font-size: 18px">4</span><strong style="color: #2A1B3D">Imprime à vontade</strong><span style="font-size: 14px">Quantas vezes precisar.</span></div>
<div class="card" style="padding: 26px 18px; display: flex; flex-direction: column; align-items: center; gap: 10px"><span class="h" style="width: 44px; height: 44px; border-radius: 50%; background: #C2532F; color: #FFFFFF; display: flex; align-items: center; justify-content: center; font-size: 18px">5</span><strong style="color: #2A1B3D">Aplica nas avaliações</strong><span style="font-size: 14px">Da anamnese à devolutiva.</span></div>
</div>
</div>
</section>

<!-- Depoimentos -->
<section style="background: #F3EBDD; padding: 96px 0">
<div style="display: flex; flex-direction: column; align-items: center; gap: 14px; text-align: center; padding: 0 20px">
<span class="pill">Depoimentos</span>
<h2 class="h" style="font-size: clamp(30px, 3.8vw, 44px)">Profissionais que já usam</h2>
<p style="margin: 0">Feedbacks reais de quem já comprou e aplica o material.</p>
</div>
<div style="overflow: hidden; margin-top: 44px; padding: 10px 0 30px; -webkit-mask-image: linear-gradient(90deg, transparent, #000 6%, #000 94%, transparent); mask-image: linear-gradient(90deg, transparent, #000 6%, #000 94%, transparent)">
<div class="track" style="align-items: center; animation-duration: 60s">
<figure class="card" style="margin: 0; flex: 0 0 340px; box-sizing: border-box; padding: 26px; display: flex; flex-direction: column; gap: 14px"><div style="color: #E8A317; letter-spacing: 2px">★★★★★</div><blockquote style="margin: 0; color: #2A1B3D">"Esse material salvou meus atendimentos. Os testes são super organizados e prontos para usar. Recomendo demais para quem quer agilidade no diagnóstico."</blockquote><figcaption style="margin-top: auto; display: flex; gap: 12px; align-items: center"><span class="h" style="width: 42px; height: 42px; border-radius: 50%; background: #D2603A; color: #FFFFFF; display: flex; align-items: center; justify-content: center; font-size: 17px">L</span><span style="font-size: 14px; line-height: 1.35"><strong style="color: #2A1B3D">Luciana M.</strong><br>Psicopedagoga clínica</span></figcaption></figure>
<figure class="card" style="margin: 0; flex: 0 0 250px; box-sizing: border-box; padding: 14px; display: flex; flex-direction: column; gap: 10px; align-items: center"><img src="/site_images/site_img_39.jpg" alt="Print real de uma cliente no Instagram dizendo que acabou de comprar e amou o material" style="width: 100%; display: block; border-radius: 16px"><figcaption style="display: flex; align-items: center; gap: 6px; font-size: 13px; font-weight: 600; color: #2A1B3D"><svg width="16" height="16" viewBox="0 0 24 24"><circle cx="12" cy="12" r="11" fill="#3C9A5F"></circle><path d="m7.5 12.5 3 3 6-6.5" fill="none" stroke="#FFFFFF" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"></path></svg>Print real de cliente</figcaption></figure>
<figure class="card" style="margin: 0; flex: 0 0 340px; box-sizing: border-box; padding: 26px; display: flex; flex-direction: column; gap: 14px"><div style="color: #E8A317; letter-spacing: 2px">★★★★★</div><blockquote style="margin: 0; color: #2A1B3D">"Eu não imaginava que existia um material tão completo assim. As fichas de acompanhamento e os modelos de devolutiva me poupam horas de trabalho."</blockquote><figcaption style="margin-top: auto; display: flex; gap: 12px; align-items: center"><span class="h" style="width: 42px; height: 42px; border-radius: 50%; background: #D2603A; color: #FFFFFF; display: flex; align-items: center; justify-content: center; font-size: 17px">C</span><span style="font-size: 14px; line-height: 1.35"><strong style="color: #2A1B3D">Carla S.</strong><br>Professora do Fundamental</span></figcaption></figure>
<figure class="card" style="margin: 0; flex: 0 0 340px; box-sizing: border-box; padding: 26px; display: flex; flex-direction: column; gap: 14px"><div style="color: #E8A317; letter-spacing: 2px">★★★★★</div><blockquote style="margin: 0; color: #2A1B3D">"O combo com o drive profissional é incrível. Tenho instrumentos para dislexia, TDAH, discalculia — tudo num só lugar. Vale cada centavo."</blockquote><figcaption style="margin-top: auto; display: flex; gap: 12px; align-items: center"><span class="h" style="width: 42px; height: 42px; border-radius: 50%; background: #D2603A; color: #FFFFFF; display: flex; align-items: center; justify-content: center; font-size: 17px">J</span><span style="font-size: 14px; line-height: 1.35"><strong style="color: #2A1B3D">Juliana L.</strong><br>Neuropsicopedagoga</span></figcaption></figure>
<figure class="card" style="margin: 0; flex: 0 0 340px; box-sizing: border-box; padding: 26px; display: flex; flex-direction: column; gap: 14px"><div style="color: #E8A317; letter-spacing: 2px">★★★★★</div><blockquote style="margin: 0; color: #2A1B3D">"Esse material salvou meus atendimentos. Os testes são super organizados e prontos para usar. Recomendo demais para quem quer agilidade no diagnóstico."</blockquote><figcaption style="margin-top: auto; display: flex; gap: 12px; align-items: center"><span class="h" style="width: 42px; height: 42px; border-radius: 50%; background: #D2603A; color: #FFFFFF; display: flex; align-items: center; justify-content: center; font-size: 17px">L</span><span style="font-size: 14px; line-height: 1.35"><strong style="color: #2A1B3D">Luciana M.</strong><br>Psicopedagoga clínica</span></figcaption></figure>
<figure class="card" style="margin: 0; flex: 0 0 250px; box-sizing: border-box; padding: 14px; display: flex; flex-direction: column; gap: 10px; align-items: center"><img src="/site_images/site_img_40.jpg" alt="Print real de uma cliente no Instagram dizendo que acabou de comprar e amou o material" style="width: 100%; display: block; border-radius: 16px"><figcaption style="display: flex; align-items: center; gap: 6px; font-size: 13px; font-weight: 600; color: #2A1B3D"><svg width="16" height="16" viewBox="0 0 24 24"><circle cx="12" cy="12" r="11" fill="#3C9A5F"></circle><path d="m7.5 12.5 3 3 6-6.5" fill="none" stroke="#FFFFFF" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"></path></svg>Print real de cliente</figcaption></figure>
<figure class="card" style="margin: 0; flex: 0 0 340px; box-sizing: border-box; padding: 26px; display: flex; flex-direction: column; gap: 14px"><div style="color: #E8A317; letter-spacing: 2px">★★★★★</div><blockquote style="margin: 0; color: #2A1B3D">"Eu não imaginava que existia um material tão completo assim. As fichas de acompanhamento e os modelos de devolutiva me poupam horas de trabalho."</blockquote><figcaption style="margin-top: auto; display: flex; gap: 12px; align-items: center"><span class="h" style="width: 42px; height: 42px; border-radius: 50%; background: #D2603A; color: #FFFFFF; display: flex; align-items: center; justify-content: center; font-size: 17px">C</span><span style="font-size: 14px; line-height: 1.35"><strong style="color: #2A1B3D">Carla S.</strong><br>Professora do Fundamental</span></figcaption></figure>
<figure class="card" style="margin: 0; flex: 0 0 340px; box-sizing: border-box; padding: 26px; display: flex; flex-direction: column; gap: 14px"><div style="color: #E8A317; letter-spacing: 2px">★★★★★</div><blockquote style="margin: 0; color: #2A1B3D">"O combo com o drive profissional é incrível. Tenho instrumentos para dislexia, TDAH, discalculia — tudo num só lugar. Vale cada centavo."</blockquote><figcaption style="margin-top: auto; display: flex; gap: 12px; align-items: center"><span class="h" style="width: 42px; height: 42px; border-radius: 50%; background: #D2603A; color: #FFFFFF; display: flex; align-items: center; justify-content: center; font-size: 17px">J</span><span style="font-size: 14px; line-height: 1.35"><strong style="color: #2A1B3D">Juliana L.</strong><br>Neuropsicopedagoga</span></figcaption></figure>
<figure aria-hidden="true" class="card" style="margin: 0; flex: 0 0 340px; box-sizing: border-box; padding: 26px; display: flex; flex-direction: column; gap: 14px"><div style="color: #E8A317; letter-spacing: 2px">★★★★★</div><blockquote style="margin: 0; color: #2A1B3D">"Esse material salvou meus atendimentos. Os testes são super organizados e prontos para usar. Recomendo demais para quem quer agilidade no diagnóstico."</blockquote><figcaption style="margin-top: auto; display: flex; gap: 12px; align-items: center"><span class="h" style="width: 42px; height: 42px; border-radius: 50%; background: #D2603A; color: #FFFFFF; display: flex; align-items: center; justify-content: center; font-size: 17px">L</span><span style="font-size: 14px; line-height: 1.35"><strong style="color: #2A1B3D">Luciana M.</strong><br>Psicopedagoga clínica</span></figcaption></figure>
<figure aria-hidden="true" class="card" style="margin: 0; flex: 0 0 250px; box-sizing: border-box; padding: 14px; display: flex; flex-direction: column; gap: 10px; align-items: center"><img src="/site_images/site_img_41.jpg" alt="Print real de uma cliente no Instagram dizendo que acabou de comprar e amou o material" style="width: 100%; display: block; border-radius: 16px"><figcaption style="display: flex; align-items: center; gap: 6px; font-size: 13px; font-weight: 600; color: #2A1B3D"><svg width="16" height="16" viewBox="0 0 24 24"><circle cx="12" cy="12" r="11" fill="#3C9A5F"></circle><path d="m7.5 12.5 3 3 6-6.5" fill="none" stroke="#FFFFFF" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"></path></svg>Print real de cliente</figcaption></figure>
<figure aria-hidden="true" class="card" style="margin: 0; flex: 0 0 340px; box-sizing: border-box; padding: 26px; display: flex; flex-direction: column; gap: 14px"><div style="color: #E8A317; letter-spacing: 2px">★★★★★</div><blockquote style="margin: 0; color: #2A1B3D">"Eu não imaginava que existia um material tão completo assim. As fichas de acompanhamento e os modelos de devolutiva me poupam horas de trabalho."</blockquote><figcaption style="margin-top: auto; display: flex; gap: 12px; align-items: center"><span class="h" style="width: 42px; height: 42px; border-radius: 50%; background: #D2603A; color: #FFFFFF; display: flex; align-items: center; justify-content: center; font-size: 17px">C</span><span style="font-size: 14px; line-height: 1.35"><strong style="color: #2A1B3D">Carla S.</strong><br>Professora do Fundamental</span></figcaption></figure>
<figure aria-hidden="true" class="card" style="margin: 0; flex: 0 0 340px; box-sizing: border-box; padding: 26px; display: flex; flex-direction: column; gap: 14px"><div style="color: #E8A317; letter-spacing: 2px">★★★★★</div><blockquote style="margin: 0; color: #2A1B3D">"O combo com o drive profissional é incrível. Tenho instrumentos para dislexia, TDAH, discalculia — tudo num só lugar. Vale cada centavo."</blockquote><figcaption style="margin-top: auto; display: flex; gap: 12px; align-items: center"><span class="h" style="width: 42px; height: 42px; border-radius: 50%; background: #D2603A; color: #FFFFFF; display: flex; align-items: center; justify-content: center; font-size: 17px">J</span><span style="font-size: 14px; line-height: 1.35"><strong style="color: #2A1B3D">Juliana L.</strong><br>Neuropsicopedagoga</span></figcaption></figure>
<figure aria-hidden="true" class="card" style="margin: 0; flex: 0 0 340px; box-sizing: border-box; padding: 26px; display: flex; flex-direction: column; gap: 14px"><div style="color: #E8A317; letter-spacing: 2px">★★★★★</div><blockquote style="margin: 0; color: #2A1B3D">"Esse material salvou meus atendimentos. Os testes são super organizados e prontos para usar. Recomendo demais para quem quer agilidade no diagnóstico."</blockquote><figcaption style="margin-top: auto; display: flex; gap: 12px; align-items: center"><span class="h" style="width: 42px; height: 42px; border-radius: 50%; background: #D2603A; color: #FFFFFF; display: flex; align-items: center; justify-content: center; font-size: 17px">L</span><span style="font-size: 14px; line-height: 1.35"><strong style="color: #2A1B3D">Luciana M.</strong><br>Psicopedagoga clínica</span></figcaption></figure>
<figure aria-hidden="true" class="card" style="margin: 0; flex: 0 0 250px; box-sizing: border-box; padding: 14px; display: flex; flex-direction: column; gap: 10px; align-items: center"><img src="/site_images/site_img_42.jpg" alt="Print real de uma cliente no Instagram dizendo que acabou de comprar e amou o material" style="width: 100%; display: block; border-radius: 16px"><figcaption style="display: flex; align-items: center; gap: 6px; font-size: 13px; font-weight: 600; color: #2A1B3D"><svg width="16" height="16" viewBox="0 0 24 24"><circle cx="12" cy="12" r="11" fill="#3C9A5F"></circle><path d="m7.5 12.5 3 3 6-6.5" fill="none" stroke="#FFFFFF" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"></path></svg>Print real de cliente</figcaption></figure>
<figure aria-hidden="true" class="card" style="margin: 0; flex: 0 0 340px; box-sizing: border-box; padding: 26px; display: flex; flex-direction: column; gap: 14px"><div style="color: #E8A317; letter-spacing: 2px">★★★★★</div><blockquote style="margin: 0; color: #2A1B3D">"Eu não imaginava que existia um material tão completo assim. As fichas de acompanhamento e os modelos de devolutiva me poupam horas de trabalho."</blockquote><figcaption style="margin-top: auto; display: flex; gap: 12px; align-items: center"><span class="h" style="width: 42px; height: 42px; border-radius: 50%; background: #D2603A; color: #FFFFFF; display: flex; align-items: center; justify-content: center; font-size: 17px">C</span><span style="font-size: 14px; line-height: 1.35"><strong style="color: #2A1B3D">Carla S.</strong><br>Professora do Fundamental</span></figcaption></figure>
<figure aria-hidden="true" class="card" style="margin: 0; flex: 0 0 340px; box-sizing: border-box; padding: 26px; display: flex; flex-direction: column; gap: 14px"><div style="color: #E8A317; letter-spacing: 2px">★★★★★</div><blockquote style="margin: 0; color: #2A1B3D">"O combo com o drive profissional é incrível. Tenho instrumentos para dislexia, TDAH, discalculia — tudo num só lugar. Vale cada centavo."</blockquote><figcaption style="margin-top: auto; display: flex; gap: 12px; align-items: center"><span class="h" style="width: 42px; height: 42px; border-radius: 50%; background: #D2603A; color: #FFFFFF; display: flex; align-items: center; justify-content: center; font-size: 17px">J</span><span style="font-size: 14px; line-height: 1.35"><strong style="color: #2A1B3D">Juliana L.</strong><br>Neuropsicopedagoga</span></figcaption></figure>
</div>
</div>
</section>

<!-- Planos -->
<section id="planos" style="padding: 96px 20px">
<div style="max-width: 1100px; margin: 0 auto; display: flex; flex-direction: column; gap: 48px">
<div style="display: flex; flex-direction: column; align-items: center; gap: 14px; text-align: center">
<span class="pill">Escolha seu plano</span>
<h2 class="h" style="font-size: clamp(30px, 3.8vw, 44px)">Acesso em pagamento único</h2>
<p style="margin: 0">Sem mensalidades. Pagamento único.</p>
</div>
<div style="display: flex; flex-wrap: wrap; gap: 28px; align-items: flex-start">
<div class="card" style="flex: 1 1 360px; min-width: 0; padding: 34px; display: flex; flex-direction: column; gap: 18px">
<div><div style="font-size: 13px; font-weight: 700; letter-spacing: 0.1em; text-transform: uppercase">Plano básico</div><h3 class="h" style="font-size: 24px">Apostila Completa</h3></div>
<div><span class="h" style="font-size: 46px">3</span><span class="h" style="font-size: 22px">,90 €</span> <span style="font-size: 14px">pagamento único</span></div>
<div style="font-size: 14px; color: #A4431F; font-weight: 600">Atenção: versão sem Guia, Kit Visual e bônus. Veja o que só vem no Combo:</div>
<div style="display: flex; flex-direction: column; gap: 10px; font-size: 15px; color: #2A1B3D">
<div class="chk"><svg width="22" height="22" viewBox="0 0 24 24"><circle cx="12" cy="12" r="11" fill="#3C9A5F"></circle><path d="m7.5 12.5 3 3 6-6.5" fill="none" stroke="#FFFFFF" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"></path></svg>Apostila completa em PDF</div>
<div class="chk"><svg width="22" height="22" viewBox="0 0 24 24"><circle cx="12" cy="12" r="11" fill="#3C9A5F"></circle><path d="m7.5 12.5 3 3 6-6.5" fill="none" stroke="#FFFFFF" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"></path></svg>Mais de 50 testes psicopedagógicos</div>
<div class="chk"><svg width="22" height="22" viewBox="0 0 24 24"><circle cx="12" cy="12" r="11" fill="#3C9A5F"></circle><path d="m7.5 12.5 3 3 6-6.5" fill="none" stroke="#FFFFFF" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"></path></svg>Protocolos de avaliação</div>
<div class="chk"><svg width="22" height="22" viewBox="0 0 24 24"><circle cx="12" cy="12" r="11" fill="#3C9A5F"></circle><path d="m7.5 12.5 3 3 6-6.5" fill="none" stroke="#FFFFFF" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"></path></svg>Conteúdo teórico e prático</div>
<div class="chk" style="color: #9B92A3"><svg width="22" height="22" viewBox="0 0 24 24"><circle cx="12" cy="12" r="11" fill="#E4DED7"></circle><path d="m8 8 8 8M16 8l-8 8" stroke="#9B92A3" stroke-width="2" stroke-linecap="round"></path></svg><s>Guia Prático 2026</s></div>
<div class="chk" style="color: #9B92A3"><svg width="22" height="22" viewBox="0 0 24 24"><circle cx="12" cy="12" r="11" fill="#E4DED7"></circle><path d="m8 8 8 8M16 8l-8 8" stroke="#9B92A3" stroke-width="2" stroke-linecap="round"></path></svg><s>Kit Visual de Hábitos e Regulação</s></div>
<div class="chk" style="color: #9B92A3"><svg width="22" height="22" viewBox="0 0 24 24"><circle cx="12" cy="12" r="11" fill="#E4DED7"></circle><path d="m8 8 8 8M16 8l-8 8" stroke="#9B92A3" stroke-width="2" stroke-linecap="round"></path></svg><s>Drive Profissional</s></div>
<div class="chk" style="color: #9B92A3"><svg width="22" height="22" viewBox="0 0 24 24"><circle cx="12" cy="12" r="11" fill="#E4DED7"></circle><path d="m8 8 8 8M16 8l-8 8" stroke="#9B92A3" stroke-width="2" stroke-linecap="round"></path></svg><s>1.500 atividades, 20 jogos e e-books de autismo</s></div>
</div>
<button type="button" class="btn2" id="abrir-popup" style="margin-top: 8px; background: transparent; font-family: inherit; cursor: pointer; width: 100%">Quero o plano básico</button>
</div>
<div class="card" style="flex: 1 1 420px; min-width: 0; padding: 34px; display: flex; flex-direction: column; gap: 18px; border: 2px solid #D2603A; position: relative; background: #FFFFFF">
<span style="position: absolute; top: -17px; left: 50%; transform: translateX(-50%); background: #C2532F; color: #FFFFFF; border-radius: 999px; padding: 6px 18px; font-size: 12px; font-weight: 700; letter-spacing: 0.1em; white-space: nowrap">MAIS ESCOLHIDO</span>
<div style="background: #FAF6EE; border-radius: 18px; padding: 10px"><img class="viva" src="/site_images/site_img_43.jpg" alt="Kit completo Psicopedagógica 2026 e 2027 com todos os cadernos e os 3 bônus exclusivos" style="width: 100%; height: auto; border-radius: 12px"></div>
<div><div style="font-size: 13px; font-weight: 700; letter-spacing: 0.1em; text-transform: uppercase; color: #A4431F">Combo Profissional</div><h3 class="h" style="font-size: 24px">Kit completo + todos os bônus</h3></div>
<div><span class="h" style="font-size: 46px; color: #C2532F">14</span><span class="h" style="font-size: 22px; color: #C2532F">,90 €</span> <span style="font-size: 14px">pagamento único</span></div>
<div style="display: flex; flex-direction: column; gap: 10px; font-size: 15px; color: #2A1B3D">
<div class="chk"><svg width="22" height="22" viewBox="0 0 24 24"><circle cx="12" cy="12" r="11" fill="#3C9A5F"></circle><path d="m7.5 12.5 3 3 6-6.5" fill="none" stroke="#FFFFFF" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"></path></svg>Apostila Completa com +50 testes</div>
<div class="chk"><svg width="22" height="22" viewBox="0 0 24 24"><circle cx="12" cy="12" r="11" fill="#3C9A5F"></circle><path d="m7.5 12.5 3 3 6-6.5" fill="none" stroke="#FFFFFF" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"></path></svg>Guia Prático 2026 — 30+ páginas de mapas e checklists</div>
<div class="chk"><svg width="22" height="22" viewBox="0 0 24 24"><circle cx="12" cy="12" r="11" fill="#3C9A5F"></circle><path d="m7.5 12.5 3 3 6-6.5" fill="none" stroke="#FFFFFF" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"></path></svg>Kit Visual de Hábitos, Comunicação e Regulação</div>
<div class="chk"><svg width="22" height="22" viewBox="0 0 24 24"><circle cx="12" cy="12" r="11" fill="#3C9A5F"></circle><path d="m7.5 12.5 3 3 6-6.5" fill="none" stroke="#FFFFFF" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"></path></svg>Drive Profissional com documentos editáveis</div>
<div class="chk"><svg width="22" height="22" viewBox="0 0 24 24"><circle cx="12" cy="12" r="11" fill="#3C9A5F"></circle><path d="m7.5 12.5 3 3 6-6.5" fill="none" stroke="#FFFFFF" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"></path></svg>1.500 atividades infantis e 20 jogos educativos</div>
<div class="chk"><svg width="22" height="22" viewBox="0 0 24 24"><circle cx="12" cy="12" r="11" fill="#3C9A5F"></circle><path d="m7.5 12.5 3 3 6-6.5" fill="none" stroke="#FFFFFF" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"></path></svg>3 e-books exclusivos sobre autismo</div>
</div>
<a class="btn" href="https://pay.hotmart.com/I107961239X?off=cijng3jw" style="margin-top: 8px">Quero o kit completo</a>
<div style="display: flex; flex-wrap: wrap; justify-content: center; gap: 16px; font-size: 13px"><span>Compra segura</span><span>·</span><span>Garantia de 7 dias</span><span>·</span><span>Acesso imediato</span></div>
</div>
</div>
</div>
</section>

<!-- Garantia -->
<section style="padding: 0 20px 96px">
<div class="card" style="max-width: 860px; margin: 0 auto; padding: 36px; display: flex; flex-wrap: wrap; gap: 30px; align-items: center">
<div style="flex: 0 0 132px; height: 132px; border-radius: 50%; background: #2A1B3D; display: flex; flex-direction: column; align-items: center; justify-content: center; box-shadow: inset 0 0 0 5px #2A1B3D, inset 0 0 0 7px #E8A317; transform: rotate(-10deg)"><span class="h" style="font-size: 44px; color: #F5C451; font-style: italic">7 dias</span><span style="font-size: 10px; font-weight: 700; letter-spacing: 0.2em; color: #FFFFFF; margin-top: 4px">GARANTIA</span></div>
<div style="flex: 1 1 380px; min-width: 0; display: flex; flex-direction: column; gap: 8px">
<span class="pill" style="align-self: flex-start; background: #D3F9D8; color: #2B6B3A">Garantia incondicional</span>
<h2 class="h" style="font-size: 30px">Teste sem risco por 7 dias</h2>
<p style="margin: 0">Se você não ficar satisfeito com o material, basta pedir o reembolso dentro de 7 dias e devolvemos 100% do seu dinheiro. Sem perguntas, sem burocracia.</p>
</div>
</div>
</section>

<!-- FAQ -->
<section style="background: #F3EBDD; padding: 96px 20px">
<div style="max-width: 780px; margin: 0 auto; display: flex; flex-direction: column; gap: 32px">
<div style="display: flex; flex-direction: column; align-items: center; gap: 12px; text-align: center">
<h2 class="h" style="font-size: clamp(30px, 3.8vw, 44px)">Perguntas frequentes</h2>
<p style="margin: 0">Tudo que você precisa saber antes de garantir seu kit.</p>
</div>
<div style="display: flex; flex-direction: column; gap: 12px">
<details><summary>Como recebo o material?</summary><p style="margin: 0 0 20px">Logo após a confirmação da compra, o acesso é enviado para o seu e-mail.</p></details>
<details><summary>O material é digital ou em formato físico?</summary><p style="margin: 0 0 20px">100% digital, em PDF. Os documentos do Drive Profissional estão em Word, totalmente editáveis.</p></details>
<details><summary>Posso imprimir?</summary><p style="margin: 0 0 20px">Sim, quantas vezes quiser.</p></details>
<details><summary>Destina-se apenas a profissionais de psicopedagogia?</summary><p style="margin: 0 0 20px">Não. Também atende professores, neuropsicopedagogos, estudantes e profissionais que trabalham com dificuldades de aprendizagem.</p></details>
<details><summary>E se o material não servir para mim?</summary><p style="margin: 0 0 20px">Você tem 7 dias de garantia incondicional: basta pedir o reembolso e devolvemos 100% do valor.</p></details>
<details><summary>O acesso é vitalício?</summary><p style="margin: 0 0 20px">[RESPOSTA]</p></details>
<details><summary>Funciona se eu estiver começando na área?</summary><p style="margin: 0 0 20px">[RESPOSTA]</p></details>
<details><summary>Existe apoio ao cliente em caso de dúvidas?</summary><p style="margin: 0 0 20px">[RESPOSTA — canal de suporte]</p></details>
</div>
</div>
</section>

<!-- Rodapé -->
<footer style="background: #2A1B3D; color: #C9BFD3; padding: 44px 20px; font-size: 13px; line-height: 1.6; text-align: center">
<div style="max-width: 780px; margin: 0 auto; display: flex; flex-direction: column; gap: 10px">
<strong class="h" style="color: #FFFFFF; font-size: 18px">Kit de Avaliação e Intervenção Psicopedagógica</strong>
<p style="margin: 0">Material protegido pela Lei de Direitos Autorais (Lei nº 9.610/98). A compra concede licença de uso individual e intransferível. O conteúdo tem caráter educativo e complementar e não substitui avaliação, diagnóstico ou conduta profissional.</p>
<p style="margin: 0">© 2026 Todos os direitos reservados.</p>
</div>
</footer>

<div id="popup" hidden>
<div role="dialog" aria-modal="true" aria-labelledby="pop-titulo" style="position: fixed; inset: 0; z-index: 1000; background: rgba(42,27,61,0.62); display: flex; align-items: center; justify-content: center; padding: 20px; box-sizing: border-box">
<div style="position: relative; width: 100%; max-width: 480px; max-height: 100%; overflow-y: auto; background: #FFFDF9; border-radius: 26px; padding: 34px 28px 26px; box-sizing: border-box; text-align: center; display: flex; flex-direction: column; align-items: center; gap: 14px; box-shadow: 0 30px 80px rgba(0,0,0,0.35)">
<button type="button" id="fechar-popup" aria-label="Fechar" style="position: absolute; top: 12px; right: 12px; width: 44px; height: 44px; border-radius: 50%; border: none; background: #F3EBDD; color: #2A1B3D; cursor: pointer; display: flex; align-items: center; justify-content: center"><svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round"><path d="M6 6l12 12M18 6 6 18"></path></svg></button>
<span class="pill" style="background: #FFE8CC; color: #A4431F">Espere! Oferta exclusiva</span>
<h2 id="pop-titulo" class="h" style="font-size: 28px">Leve o <span style="color: #C2532F">Kit Completo</span> por apenas 14,90 €</h2>
<div style="font-size: 15px">De <s>19,90 €</s> por <strong style="color: #C2532F; font-size: 20px">14,90 €</strong> · só nesta tela</div>
<img class="viva" src="/site_images/site_img_44.jpg" alt="Kit completo Psicopedagógica 2026 e 2027 com todos os bônus" style="width: 100%; border-radius: 14px">
<div style="display: flex; flex-direction: column; gap: 8px; width: 100%"><div class="chk" style="font-size: 14px; color: #2A1B3D; text-align: left"><svg width="20" height="20" viewBox="0 0 24 24"><circle cx="12" cy="12" r="11" fill="#3C9A5F"></circle><path d="m7.5 12.5 3 3 6-6.5" fill="none" stroke="#FFFFFF" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"></path></svg><span>Apostila Completa com +50 testes</span></div><div class="chk" style="font-size: 14px; color: #2A1B3D; text-align: left"><svg width="20" height="20" viewBox="0 0 24 24"><circle cx="12" cy="12" r="11" fill="#3C9A5F"></circle><path d="m7.5 12.5 3 3 6-6.5" fill="none" stroke="#FFFFFF" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"></path></svg><span>Guia Prático 2026 e Kit Visual</span></div><div class="chk" style="font-size: 14px; color: #2A1B3D; text-align: left"><svg width="20" height="20" viewBox="0 0 24 24"><circle cx="12" cy="12" r="11" fill="#3C9A5F"></circle><path d="m7.5 12.5 3 3 6-6.5" fill="none" stroke="#FFFFFF" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"></path></svg><span>Drive Profissional com documentos editáveis</span></div><div class="chk" style="font-size: 14px; color: #2A1B3D; text-align: left"><svg width="20" height="20" viewBox="0 0 24 24"><circle cx="12" cy="12" r="11" fill="#3C9A5F"></circle><path d="m7.5 12.5 3 3 6-6.5" fill="none" stroke="#FFFFFF" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"></path></svg><span>1.500 atividades, 20 jogos e 3 e-books de autismo</span></div></div>
<a class="btn" href="https://pay.hotmart.com/I107961239X?off=xqjdiku0" style="width: 100%; box-sizing: border-box">Quero o completo com desconto</a>
<a href="https://pay.hotmart.com/I107961239X?off=cijng3jw" style="font-size: 14px; color: #5A4F63; padding: 10px; min-height: 44px; box-sizing: border-box; display: inline-flex; align-items: center">Não, quero só o plano básico de 3,90 €</a>
<div style="font-size: 12px; display: flex; gap: 10px; flex-wrap: wrap; justify-content: center"><span>Compra segura</span><span>·</span><span>Garantia de 7 dias</span></div>
</div>
</div>
</div>
</div>


`,
      }}
    />
  );
}
