import React from 'react';
import { ShoppingBag, Mail, FolderDown, Printer, PlayCircle } from 'lucide-react';

export const HowItWorksPortugal: React.FC = () => {
  const steps = [
    {
      step: '1',
      title: 'Escolha o seu Plano',
      desc: 'Selecione entre o Plano Básico (€4,90) ou o Combo Profissional Completo (€9,90) no checkout seguro.',
      icon: ShoppingBag,
    },
    {
      step: '2',
      title: 'Receba o Acesso Imediato',
      desc: 'Assim que o pagamento for aprovado, o link de acesso aos ficheiros é enviado diretamente para o seu e-mail.',
      icon: Mail,
    },
    {
      step: '3',
      title: 'Descarregue para os seus Dispositivos',
      desc: 'Guarde os ficheiros em PDF e Word no seu computador, tablet ou telemóvel para consultar sempre que quiser.',
      icon: FolderDown,
    },
    {
      step: '4',
      title: 'Imprima e Aplique na Prática',
      desc: 'Imprima as folhas necessárias para a sua semana, organize as suas pastas e aplique com os seus alunos.',
      icon: Printer,
    },
  ];

  return (
    <section className="py-16 sm:py-24 px-4 bg-[#FFFFFF] border-b border-[#E2EBE8]">
      <div className="max-w-6xl mx-auto">
        
        <div className="max-w-3xl mx-auto text-center mb-14">
          <span className="text-xs font-bold text-[#25A69A] uppercase tracking-wider bg-[#E8F4F2] px-3.5 py-1.5 rounded-full inline-block mb-3 border border-[#C5E4DD]">
            PASSO A PASSO SIMPLES
          </span>
          <h2 className="font-heading font-black text-2xl sm:text-4xl text-[#123C4A] leading-tight mb-4">
            Como funciona o acesso ao material digital
          </h2>
          <p className="text-sm sm:text-base text-[#5D737E]">
            Processo 100% digital, automático e sem complicações.
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {steps.map((st, i) => {
            const Icon = st.icon;
            return (
              <div 
                key={i}
                className="bg-[#F8FAF9] rounded-3xl p-6 border border-[#E2EBE8] flex flex-col justify-between text-center relative group hover:border-[#25A69A] transition-all"
              >
                <div>
                  <div className="w-12 h-12 rounded-2xl bg-[#123C4A] text-white flex items-center justify-center font-black text-lg mx-auto mb-4 shadow-sm group-hover:bg-[#25A69A] transition-colors">
                    {st.step}
                  </div>
                  <h3 className="font-heading font-bold text-base text-[#182B35] mb-2">
                    {st.title}
                  </h3>
                  <p className="text-xs text-[#5D737E] leading-relaxed">
                    {st.desc}
                  </p>
                </div>

                <div className="mt-5 pt-3 border-t border-slate-100 flex items-center justify-center text-[#25A69A]">
                  <Icon className="w-4 h-4" />
                </div>
              </div>
            );
          })}
        </div>

        {/* Condições de Licença Ética */}
        <div className="mt-12 text-center text-xs text-[#5D737E] max-w-2xl mx-auto bg-[#FBF7EE] p-4 rounded-2xl border border-[#F3E7D0]">
          <strong>Condições de Utilização:</strong> A aquisição concede uma licença de uso individual e pessoal para aplicação profissional e educativa. Fica vedada a revenda, partilha pública em redes sociais ou distribuição não autorizada dos ficheiros.
        </div>

      </div>
    </section>
  );
};
