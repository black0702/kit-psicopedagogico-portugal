import React from 'react';
import { 
  ClipboardList, 
  BookOpen, 
  Calculator, 
  Brain, 
  HeartHandshake, 
  FolderCheck,
  CheckCircle2,
  FileText
} from 'lucide-react';

export const IncludedCurriculumPortugal: React.FC = () => {
  const axes = [
    {
      num: '1',
      title: 'Anamnese e Áreas de Avaliação',
      desc: 'Orientações estruturadas para cada etapa do levantamento de hipóteses, cruzando dados da criança, da família e do contexto escolar.',
      icon: ClipboardList,
      color: 'bg-[#EBF7F5] text-[#25A69A]',
      items: ['Roteiro de entrevista inicial', 'Marcos de desenvolvimento', 'Histórico pedagógico']
    },
    {
      num: '2',
      title: 'Leitura, Escrita e Consciência Fonológica',
      desc: 'Sondagens padronizadas, fichas de rimas, aliterações e protocolos de análise de dificuldades de alfabetização e disortografia.',
      icon: BookOpen,
      color: 'bg-[#FFF6E5] text-[#D5AD68]',
      items: ['Sondagem fonológica por níveis', 'Análise qualitativa de erros', 'Critérios de fluência leitora']
    },
    {
      num: '3',
      title: 'Matemática e Raciocínio Lógico',
      desc: 'Fichas práticas para investigar o sentido de número, seriação, conservação de quantidade e sinais associados à discalculia.',
      icon: Calculator,
      color: 'bg-[#E8F0FE] text-[#1D4ED8]',
      items: ['Raciocínio lógico-matemático', 'Noção de valor e grandeza', 'Resolução de problemas visuais']
    },
    {
      num: '4',
      title: 'Atenção, Memória e Funções Executivas',
      desc: 'Instrumentos práticos para observar foco sustentado, controlo inibitório, memória de trabalho e planeamento de tarefas.',
      icon: Brain,
      color: 'bg-[#F3E8FF] text-[#7E22CE]',
      items: ['Grelhas de rastreio de foco', 'Cartões de sequência temporal', 'Mapas cognitivos práticos']
    },
    {
      num: '5',
      title: 'Dificuldades Específicas & Sinais de Alerta',
      desc: 'Guias orientadores de observação comportamental e pedagógica para PHDA, perturbação do espetro do autismo e dislexia.',
      icon: HeartHandshake,
      color: 'bg-[#FCE7F3] text-[#BE185D]',
      items: ['Checklists de sinais de alerta', 'Observação de rotina e frustração', 'Sem conclusões precipitadas']
    },
    {
      num: '6',
      title: 'Devolutiva e Plano de Apoio Individual',
      desc: 'Modelos de síntese compreensíveis para diálogo com os pais, articulação com a escola e metas semanais de intervenção.',
      icon: FolderCheck,
      color: 'bg-[#E0F2FE] text-[#0369A1]',
      items: ['Relatório de devolutiva amigável', 'Recomendações para a sala de aula', 'Metas terapêuticas realistas']
    },
  ];

  return (
    <section id="conteudo" className="py-16 sm:py-24 px-4 bg-[#FAF6EE] border-b border-[#E8E1D3]">
      <div className="max-w-6xl mx-auto">
        
        {/* Título da Secção */}
        <div className="max-w-3xl mx-auto text-center mb-14 sm:mb-16">
          <span className="text-xs font-bold text-[#25A69A] uppercase tracking-wider bg-[#E8F4F2] px-3.5 py-1.5 rounded-full inline-block mb-3 border border-[#C5E4DD]">
            CONTEÚDO COMPLETO
          </span>
          <h2 className="font-heading font-black text-2xl sm:text-4xl text-[#123C4A] leading-tight mb-4">
            6 eixos para avaliar e intervir com segurança e método
          </h2>
          <p className="text-sm sm:text-base text-[#5D737E] leading-relaxed">
            Uma estrutura pedagógica que abrange cada área investigada no processo de apoio às dificuldades de aprendizagem.
          </p>
        </div>

        {/* Grade com os 6 Eixos */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-16">
          {axes.map((axis, idx) => {
            const Icon = axis.icon;
            return (
              <div
                key={idx}
                className="bg-white rounded-3xl p-6 sm:p-7 border border-[#E2EBE8] shadow-xs hover:shadow-md transition-all duration-300 flex flex-col justify-between group hover:-translate-y-1"
              >
                <div>
                  <div className="flex items-center justify-between mb-4">
                    <span className="text-xs font-bold text-[#123C4A] bg-[#F0F5F3] px-3 py-1 rounded-full">
                      Eixo {axis.num}
                    </span>
                    <div className={`w-10 h-10 rounded-2xl ${axis.color} flex items-center justify-center`}>
                      <Icon className="w-5 h-5" />
                    </div>
                  </div>

                  <h3 className="font-heading font-bold text-lg text-[#182B35] mb-2 leading-snug group-hover:text-[#25A69A] transition-colors">
                    {axis.title}
                  </h3>

                  <p className="text-xs sm:text-sm text-[#5D737E] leading-relaxed mb-5">
                    {axis.desc}
                  </p>
                </div>

                <div className="pt-4 border-t border-slate-100 space-y-1.5">
                  {axis.items.map((item, i) => (
                    <div key={i} className="flex items-center gap-2 text-xs text-[#182B35]">
                      <CheckCircle2 className="w-3.5 h-3.5 text-[#25A69A] shrink-0" />
                      <span>{item}</span>
                    </div>
                  ))}
                </div>
              </div>
            );
          })}
        </div>

        {/* Resumo da Entrega e Formato */}
        <div className="bg-[#123C4A] text-white rounded-3xl p-6 sm:p-10 flex flex-col md:flex-row items-center justify-between gap-6 shadow-xl">
          <div className="space-y-2 text-center md:text-left">
            <span className="text-xs font-bold uppercase tracking-widest text-[#25A69A]">
              PADRÃO DIGITAL INTERNACIONAL
            </span>
            <h4 className="font-heading font-black text-xl sm:text-2xl text-white">
              Tudo em formato A4 de alta definição, pronto para impressão
            </h4>
            <p className="text-xs sm:text-sm text-[#CBDAD5] max-w-xl">
              Os ficheiros foram desenhados com margens adequadas para encadernação em espiral ou arquivo em capa de argolas.
            </p>
          </div>

          <div className="flex flex-wrap gap-3 justify-center">
            <span className="px-4 py-2 rounded-xl bg-white/10 backdrop-blur-sm text-xs font-bold border border-white/15">
              📄 Formato PDF Universal
            </span>
            <span className="px-4 py-2 rounded-xl bg-white/10 backdrop-blur-sm text-xs font-bold border border-white/15">
              ✏️ Documentos em Word Editável
            </span>
            <span className="px-4 py-2 rounded-xl bg-white/10 backdrop-blur-sm text-xs font-bold border border-white/15">
              ⚡ Download Imediato
            </span>
          </div>
        </div>

      </div>
    </section>
  );
};
