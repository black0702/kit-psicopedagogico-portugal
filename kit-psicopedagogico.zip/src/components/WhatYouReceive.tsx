import React from 'react';
import { 
  Library, 
  FolderTree, 
  CheckSquare, 
  LayoutGrid, 
  ClipboardCheck,
  Layers
} from 'lucide-react';
import { WHAT_YOU_RECEIVE_BLOCKS } from '../data/landingData';

const iconMap: Record<string, React.FC<{ className?: string }>> = {
  Library,
  FolderTree,
  CheckSquare,
  LayoutGrid,
  ClipboardCheck,
};

export const WhatYouReceive: React.FC = () => {
  return (
    <section id="o-que-vem" className="py-14 sm:py-20 px-4 bg-[#F7F5FC]">
      <div className="max-w-6xl mx-auto">
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-10 sm:mb-14">
          <span className="text-xs font-bold text-[#6657C8] uppercase tracking-wider bg-[#E9E5F8] px-3 py-1 rounded-full mb-3 inline-block">
            ENTREGA COMPLETA
          </span>
          <h2 className="text-2xl sm:text-3xl md:text-4xl font-extrabold text-[#30264D] mb-3 font-display">
            Tudo organizado em uma única biblioteca
          </h2>
          <p className="text-sm sm:text-base text-slate-600 leading-relaxed">
            Estrutura planejada para que você encontre com rapidez exatamente o que precisa para cada atendimento.
          </p>
        </div>

        {/* 5 Blocks with mini mockups */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5 sm:gap-6">
          {WHAT_YOU_RECEIVE_BLOCKS.map((block, idx) => {
            const Icon = iconMap[block.iconName] || Library;
            return (
              <div
                key={idx}
                className="bg-white rounded-2xl p-5 border border-[#E9E5F8] shadow-xs hover:shadow-md transition-all duration-200 flex flex-col justify-between"
              >
                <div>
                  {/* Top Tag & Mini Mockup Header */}
                  <div className="flex items-center justify-between pb-3 mb-3 border-b border-slate-100">
                    <span className="text-[10px] font-bold text-[#6657C8] bg-[#E9E5F8] px-2 py-0.5 rounded uppercase">
                      {block.tag}
                    </span>
                    <span className="text-[10px] font-mono text-slate-400">
                      [BLOCO 0{idx + 1}]
                    </span>
                  </div>

                  {/* Mini Visual Placeholder Mockup */}
                  <div className="bg-gradient-to-br from-[#F7F5FC] to-[#F1EFF9] p-3.5 rounded-xl border border-[#E9E5F8] mb-4 flex items-center gap-3">
                    <div className="w-10 h-10 rounded-xl bg-white text-[#6657C8] shadow-xs border border-[#E9E5F8] flex items-center justify-center shrink-0">
                      <Icon className="w-5 h-5" />
                    </div>
                    <div>
                      <div className="text-xs font-bold text-[#30264D]">{block.highlight}</div>
                      <div className="text-[10px] text-[#36B77A] font-semibold">Formato PDF A4</div>
                    </div>
                  </div>

                  {/* Block Title */}
                  <h3 className="text-base font-bold text-[#30264D] mb-2 leading-snug">
                    {block.title}
                  </h3>

                  {/* Description */}
                  <p className="text-xs text-slate-600 leading-relaxed">
                    {block.description}
                  </p>
                </div>

                {/* Bottom Highlight */}
                <div className="mt-4 pt-3 border-t border-slate-100 flex items-center justify-between text-xs">
                  <span className="text-slate-400 text-[11px]">Material Digital</span>
                  <span className="text-[#36B77A] font-semibold flex items-center gap-1 text-[11px]">
                    ✓ Pronto para usar
                  </span>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
};
