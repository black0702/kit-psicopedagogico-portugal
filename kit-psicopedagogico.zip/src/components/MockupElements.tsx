import React from 'react';
import { 
  FileText, 
  CheckCircle2, 
  Folder, 
  Layers, 
  Sparkles, 
  Eye, 
  BrainCircuit, 
  Compass, 
  CheckSquare, 
  BookOpen, 
  BarChart3, 
  Target,
  Maximize2
} from 'lucide-react';
import { SampleItem } from '../types';

/**
 * Hero Mockup Component: Rich, high-volume visual representation
 * showing fanned pedagogical sheets, binders, cards, and checklists.
 */
export const HeroMockup: React.FC<{ onExplore?: () => void }> = ({ onExplore }) => {
  return (
    <div className="relative w-full max-w-4xl mx-auto my-6 select-none">
      {/* Background soft glow */}
      <div className="absolute inset-0 bg-gradient-to-r from-[#6657C8]/15 via-[#36B77A]/10 to-[#6657C8]/15 rounded-3xl blur-2xl -z-10" />

      {/* Main Container */}
      <div className="bg-gradient-to-b from-[#F1EFF9] to-white p-4 sm:p-7 md:p-9 rounded-2xl md:rounded-3xl border border-[#E9E5F8] shadow-xl">
        {/* Placeholder Tag Banner */}
        <div className="flex items-center justify-between mb-4 pb-3 border-b border-[#E9E5F8] text-xs font-semibold text-[#6657C8]">
          <span className="flex items-center gap-1.5 uppercase tracking-wider">
            <Layers className="w-4 h-4 text-[#6657C8]" />
            [HERO MOCKUP — +200 RECURSOS]
          </span>
          <span className="text-[#36B77A] bg-[#36B77A]/10 px-2.5 py-1 rounded-full">
            PDF • Formato A4
          </span>
        </div>

        {/* Layered Composition */}
        <div className="relative grid grid-cols-1 md:grid-cols-12 gap-4 items-center">
          
          {/* Left Fanned Document */}
          <div className="hidden md:block md:col-span-3 transform -rotate-3 hover:rotate-0 transition-transform duration-300">
            <div className="bg-white rounded-xl p-3.5 border border-[#E9E5F8] shadow-md">
              <div className="flex items-center justify-between border-b border-slate-100 pb-2 mb-2.5">
                <span className="text-[10px] font-bold text-[#6657C8] uppercase tracking-wider">01. Rastreio</span>
                <span className="text-[9px] text-slate-400">PDF A4</span>
              </div>
              <div className="space-y-1.5 mb-3">
                <div className="h-2 w-4/5 bg-[#6657C8]/20 rounded" />
                <div className="h-1.5 w-full bg-slate-100 rounded" />
                <div className="h-1.5 w-3/4 bg-slate-100 rounded" />
              </div>
              {/* Mini visual grid */}
              <div className="grid grid-cols-3 gap-1.5 p-2 bg-[#F7F5FC] rounded-lg">
                {[...Array(6)].map((_, i) => (
                  <div key={i} className="h-6 bg-white border border-[#E9E5F8] rounded flex items-center justify-center">
                    <span className="w-2 h-2 rounded-full bg-[#6657C8]/40" />
                  </div>
                ))}
              </div>
              <div className="mt-2.5 pt-2 border-t border-slate-100 text-[10px] text-slate-500 font-medium flex items-center justify-between">
                <span>Ficha de Triagem</span>
                <CheckCircle2 className="w-3 h-3 text-[#36B77A]" />
              </div>
            </div>
          </div>

          {/* Central Main Binder / Cover */}
          <div className="md:col-span-6 relative z-10">
            <div className="bg-gradient-to-br from-[#30264D] via-[#3C3060] to-[#261E3D] text-white rounded-2xl p-6 sm:p-8 shadow-2xl border-2 border-[#6657C8]/40 text-center relative overflow-hidden">
              {/* Subtle decorative background patterns */}
              <div className="absolute top-0 right-0 w-32 h-32 bg-[#6657C8]/20 rounded-full blur-xl -mr-10 -mt-10" />
              <div className="absolute bottom-0 left-0 w-32 h-32 bg-[#36B77A]/15 rounded-full blur-xl -ml-10 -mb-10" />
              
              <div className="inline-flex items-center gap-1.5 bg-[#6657C8] text-white text-[11px] font-bold px-3 py-1 rounded-full uppercase tracking-wider mb-4 shadow-sm">
                <Sparkles className="w-3.5 h-3.5 text-yellow-300" />
                Biblioteca Visual Psicopedagógica
              </div>

              <div className="text-3xl sm:text-4xl font-extrabold tracking-tight text-white mb-2 font-display">
                +200
              </div>

              <h3 className="text-lg sm:text-xl font-bold text-white mb-2 leading-tight">
                Recursos para Avaliação e Intervenção
              </h3>

              <p className="text-xs sm:text-sm text-slate-300 max-w-md mx-auto mb-5 leading-relaxed">
                Acervo visual completo em PDF organizado por eixos de desenvolvimento para psicopedagogos.
              </p>

              {/* Badges strip inside cover */}
              <div className="grid grid-cols-3 gap-2 pt-4 border-t border-white/10 text-center">
                <div className="bg-white/5 backdrop-blur-sm rounded-lg p-2 border border-white/10">
                  <div className="text-[11px] font-bold text-[#36B77A]">+200</div>
                  <div className="text-[9px] text-slate-300 uppercase">Recursos</div>
                </div>
                <div className="bg-white/5 backdrop-blur-sm rounded-lg p-2 border border-white/10">
                  <div className="text-[11px] font-bold text-white">8 ÁREAS</div>
                  <div className="text-[9px] text-slate-300 uppercase">Categorias</div>
                </div>
                <div className="bg-white/5 backdrop-blur-sm rounded-lg p-2 border border-white/10">
                  <div className="text-[11px] font-bold text-yellow-300">+5 BÔNUS</div>
                  <div className="text-[9px] text-slate-300 uppercase">Inclusos</div>
                </div>
              </div>
            </div>
          </div>

          {/* Right Fanned Document */}
          <div className="hidden md:block md:col-span-3 transform rotate-3 hover:rotate-0 transition-transform duration-300">
            <div className="bg-white rounded-xl p-3.5 border border-[#E9E5F8] shadow-md">
              <div className="flex items-center justify-between border-b border-slate-100 pb-2 mb-2.5">
                <span className="text-[10px] font-bold text-[#36B77A] uppercase tracking-wider">02. Atenção</span>
                <span className="text-[9px] text-slate-400">PDF A4</span>
              </div>
              <div className="space-y-1.5 mb-3">
                <div className="h-2 w-3/4 bg-[#36B77A]/30 rounded" />
                <div className="h-1.5 w-full bg-slate-100 rounded" />
                <div className="h-1.5 w-4/5 bg-slate-100 rounded" />
              </div>
              {/* Mini visual checklist */}
              <div className="space-y-1.5 p-2 bg-[#F7F5FC] rounded-lg">
                {[1, 2, 3].map((item) => (
                  <div key={item} className="flex items-center gap-2 text-[9px] text-slate-600 bg-white p-1 rounded border border-[#E9E5F8]">
                    <div className="w-2.5 h-2.5 rounded border border-[#36B77A] flex items-center justify-center text-[7px] text-[#36B77A]">✓</div>
                    <div className="h-1.5 w-12 bg-slate-200 rounded" />
                  </div>
                ))}
              </div>
              <div className="mt-2.5 pt-2 border-t border-slate-100 text-[10px] text-slate-500 font-medium flex items-center justify-between">
                <span>Rastreio e Foco</span>
                <CheckCircle2 className="w-3 h-3 text-[#36B77A]" />
              </div>
            </div>
          </div>

        </div>

        {/* Bottom Volume Indicator Strip */}
        <div className="mt-5 pt-4 border-t border-[#E9E5F8] flex flex-wrap items-center justify-between gap-3 text-xs text-[#27243A]">
          <div className="flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-[#36B77A] animate-pulse" />
            <span className="font-semibold text-slate-700">Sensação de grande volume:</span>
            <span className="text-slate-500">Fichas • Cartões • Pranchas • Checklists • Roteiros de Sessão</span>
          </div>
          {onExplore && (
            <button 
              onClick={onExplore}
              className="text-[#6657C8] hover:text-[#5545B3] font-semibold text-xs flex items-center gap-1 transition-colors"
            >
              Explorar mostruário visual
              <span aria-hidden="true">&darr;</span>
            </button>
          )}
        </div>
      </div>
    </div>
  );
};

/**
 * Sample Placeholder Card: Renders realistic pedagogical document preview
 * for [AMOSTRA 01] through [AMOSTRA 16]
 */
export const SamplePlaceholderCard: React.FC<{
  sample: SampleItem;
  onPreviewClick: (sample: SampleItem) => void;
}> = ({ sample, onPreviewClick }) => {
  return (
    <div 
      onClick={() => onPreviewClick(sample)}
      className="group bg-white rounded-2xl border border-[#E9E5F8] p-4 shadow-sm hover:shadow-md hover:border-[#6657C8]/40 transition-all duration-200 cursor-pointer flex flex-col justify-between"
    >
      <div>
        {/* Placeholder Label Header */}
        <div className="flex items-center justify-between text-[11px] font-bold text-[#6657C8] mb-2.5 pb-2 border-b border-slate-100">
          <span className="bg-[#E9E5F8] text-[#6657C8] px-2 py-0.5 rounded font-mono text-[10px]">
            [{sample.code}]
          </span>
          <span className="text-slate-400 font-normal text-[10px]">
            {sample.badge}
          </span>
        </div>

        {/* Visual Document Mockup Preview Container */}
        <div className="relative bg-gradient-to-b from-[#F7F5FC] to-[#F1EFF9] rounded-xl p-3 border border-[#E9E5F8] mb-3 group-hover:bg-[#F3EFFC] transition-colors">
          {/* Document Simulated Sheet */}
          <div className="bg-white rounded-lg p-3 shadow-sm border border-slate-100">
            {/* Sheet Title Bar */}
            <div className="flex items-center gap-2 mb-2 pb-1.5 border-b border-slate-100">
              <div className="w-5 h-5 rounded bg-[#6657C8]/10 text-[#6657C8] flex items-center justify-center">
                <FileText className="w-3 h-3" />
              </div>
              <div className="flex-1 min-w-0">
                <div className="text-[10px] font-bold text-[#30264D] truncate">
                  {sample.title}
                </div>
                <div className="text-[8px] text-slate-400 truncate">
                  {sample.category} • Eixo Prático
                </div>
              </div>
            </div>

            {/* Document Content Schema Simulation */}
            <div className="space-y-1.5 my-2">
              <div className="flex items-center gap-1.5">
                <span className="w-1.5 h-1.5 rounded-full bg-[#36B77A]" />
                <div className="h-1.5 w-4/5 bg-slate-200 rounded" />
              </div>
              <div className="grid grid-cols-2 gap-1.5 pt-1">
                <div className="p-1.5 bg-[#F7F5FC] rounded border border-slate-100 text-[8px] text-slate-600">
                  <div className="font-semibold text-[#6657C8] mb-0.5">Objetivo</div>
                  <div className="line-clamp-1">{sample.objectives[0]}</div>
                </div>
                <div className="p-1.5 bg-[#F7F5FC] rounded border border-slate-100 text-[8px] text-slate-600">
                  <div className="font-semibold text-[#36B77A] mb-0.5">Aplicação</div>
                  <div className="line-clamp-1">Avaliação / Intervenção</div>
                </div>
              </div>
            </div>

            {/* Simulated Checklist Lines */}
            <div className="space-y-1 mt-2 pt-1 border-t border-slate-100">
              <div className="flex items-center gap-1 text-[8px] text-slate-400">
                <span className="w-2 h-2 rounded border border-slate-300" />
                <span className="truncate">{sample.features[0]}</span>
              </div>
              <div className="flex items-center gap-1 text-[8px] text-slate-400">
                <span className="w-2 h-2 rounded border border-slate-300" />
                <span className="truncate">{sample.features[1] || 'Formato A4 pronto para impressão'}</span>
              </div>
            </div>
          </div>

          {/* Quick Hover Badge */}
          <div className="absolute inset-0 bg-[#30264D]/5 rounded-xl opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
            <span className="bg-white text-[#6657C8] text-[11px] font-bold px-3 py-1 rounded-full shadow-md flex items-center gap-1">
              <Maximize2 className="w-3 h-3" />
              Ver Detalhes
            </span>
          </div>
        </div>

        {/* Card Title & Info */}
        <h4 className="font-bold text-sm text-[#30264D] leading-snug mb-1 group-hover:text-[#6657C8] transition-colors">
          {sample.title}
        </h4>
        <p className="text-xs text-slate-600 line-clamp-2 leading-relaxed">
          {sample.description}
        </p>
      </div>

      {/* Card Footer */}
      <div className="mt-3 pt-2.5 border-t border-slate-100 flex items-center justify-between text-[11px] text-slate-500">
        <span className="text-[10px] text-slate-400 font-medium">PDF • Alta Resolução</span>
        <span className="text-[#36B77A] font-semibold flex items-center gap-1 text-[11px]">
          <CheckCircle2 className="w-3 h-3" />
          Incluso
        </span>
      </div>
    </div>
  );
};

/**
 * Bonus Mockup Card Component for [BÔNUS 01] to [BÔNUS 05]
 */
export const BonusMockupCard: React.FC<{
  number: number;
  title: string;
  subtitle: string;
  description: string;
  format: string;
}> = ({ number, title, subtitle, description, format }) => {
  return (
    <div className="bg-white rounded-2xl border border-[#E9E5F8] p-5 shadow-sm hover:shadow-md transition-all duration-200 flex flex-col justify-between relative overflow-hidden group">
      {/* Top Banner Tag */}
      <div className="flex items-center justify-between mb-3 pb-2 border-b border-slate-100">
        <span className="bg-[#36B77A] text-white text-[10px] font-bold px-2.5 py-0.5 rounded uppercase tracking-wider">
          BÔNUS
        </span>
        <span className="text-[11px] font-mono text-[#6657C8] font-bold">
          [BÔNUS 0{number}]
        </span>
      </div>

      {/* Visual Placeholder Graphic */}
      <div className="bg-gradient-to-br from-[#F7F5FC] to-[#E9E5F8] rounded-xl p-4 border border-[#E9E5F8] mb-4 text-center">
        <div className="w-12 h-12 mx-auto rounded-xl bg-white shadow-sm border border-[#E9E5F8] flex items-center justify-center text-[#6657C8] mb-2 group-hover:scale-105 transition-transform">
          <BookOpen className="w-6 h-6" />
        </div>
        <div className="text-[10px] font-bold text-[#6657C8] uppercase tracking-wider">
          {subtitle}
        </div>
        <div className="text-[9px] text-slate-500">
          {format}
        </div>
      </div>

      {/* Title & Description */}
      <div>
        <h4 className="font-bold text-[#30264D] text-base leading-snug mb-2 group-hover:text-[#6657C8] transition-colors">
          {title}
        </h4>
        <p className="text-xs text-slate-600 leading-relaxed mb-4">
          {description}
        </p>
      </div>

      {/* Bottom Tag */}
      <div className="pt-3 border-t border-slate-100 flex items-center justify-between text-xs">
        <span className="text-[11px] text-slate-400">Incluso no valor</span>
        <span className="text-xs font-bold text-[#36B77A]">GRATUITO</span>
      </div>
    </div>
  );
};
