import React from 'react';
import { HOW_IT_WORKS_STEPS } from '../data/landingData';

export const HowItWorks: React.FC = () => {
  return (
    <section className="py-14 sm:py-20 px-4 bg-[#F7F5FC]">
      <div className="max-w-6xl mx-auto">
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-10 sm:mb-14">
          <span className="text-xs font-bold text-[#6657C8] uppercase tracking-wider bg-[#E9E5F8] px-3 py-1 rounded-full mb-3 inline-block">
            PASSO A PASSO
          </span>
          <h2 className="text-2xl sm:text-3xl md:text-4xl font-extrabold text-[#30264D] mb-3 font-display">
            Como você recebe seu material?
          </h2>
          <p className="text-sm sm:text-base text-slate-600 leading-relaxed">
            Processo transparente e simplificado para acessar todos os recursos.
          </p>
        </div>

        {/* 5 Steps: horizontal on desktop, vertical on mobile */}
        <div className="grid grid-cols-1 md:grid-cols-5 gap-4 sm:gap-6 relative">
          {HOW_IT_WORKS_STEPS.map((step, idx) => (
            <div
              key={step.step}
              className="bg-white rounded-2xl p-5 border border-[#E9E5F8] shadow-xs hover:shadow-md transition-all duration-200 flex flex-col justify-between relative group"
            >
              <div>
                {/* Step Number Circle */}
                <div className="w-10 h-10 rounded-xl bg-[#6657C8] text-white font-extrabold text-sm flex items-center justify-center mb-4 shadow-xs">
                  {step.step}
                </div>

                {/* Step Title */}
                <h3 className="text-sm font-bold text-[#30264D] mb-2 leading-snug">
                  {step.title}
                </h3>

                {/* Description */}
                <p className="text-xs text-slate-600 leading-relaxed">
                  {step.description}
                </p>
              </div>

              {/* Status Indicator */}
              <div className="mt-4 pt-3 border-t border-slate-100 text-[10px] text-slate-400 font-medium">
                Etapa {idx + 1} de 5
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};
