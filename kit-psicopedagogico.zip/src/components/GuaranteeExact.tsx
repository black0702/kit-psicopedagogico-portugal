import React from 'react';
import { ShieldCheck } from 'lucide-react';

export const GuaranteeExact: React.FC = () => {
  return (
    <section className="py-14 sm:py-20 px-4 bg-white text-center">
      <div className="max-w-xl mx-auto">
        {/* Selo Dourado 7 Dias */}
        <div className="inline-flex items-center justify-center w-20 h-20 rounded-full bg-gradient-to-tr from-amber-400 via-yellow-300 to-amber-500 shadow-lg text-[#30264D] font-extrabold mb-4 border-2 border-white ring-4 ring-amber-100">
          <div className="text-center">
            <span className="block text-2xl leading-none">7</span>
            <span className="block text-[9px] uppercase font-bold tracking-wider">DIAS</span>
          </div>
        </div>

        <h3 className="text-xl sm:text-2xl font-extrabold text-[#30264D] font-display mb-2">
          Garantia Incondicional de <span className="text-[#36B77A]">7 Dias</span>
        </h3>

        <p className="text-xs sm:text-sm text-slate-500 leading-relaxed">
          Se você não ficar satisfeito com o material, basta solicitar o reembolso dentro de 7 dias e devolveremos <strong>100% do seu dinheiro</strong>. Sem perguntas, sem burocracia.
        </p>
      </div>
    </section>
  );
};
