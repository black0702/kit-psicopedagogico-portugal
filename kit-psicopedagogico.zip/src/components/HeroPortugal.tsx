import React from 'react';
import { CheckCircle2, ArrowRight, ShieldCheck, Download, Sparkles, FileText } from 'lucide-react';
import { trackPixelEvent } from '../utils/pixelTracker';

interface HeroPortugalProps {
  onCtaClick: () => void;
}

export const HeroPortugal: React.FC<HeroPortugalProps> = ({ onCtaClick }) => {
  const handlePrimaryClick = () => {
    trackPixelEvent('InitiateCheckout', { content_name: 'Hero CTA - Kit Completo' });
    onCtaClick();
  };

  return (
    <section className="relative pt-10 sm:pt-16 pb-16 sm:pb-24 px-4 overflow-hidden bg-gradient-to-b from-[#FAF6EE] via-[#FDFBF7] to-[#FAF6EE]">
      {/* Elementos Decorativos Sutis */}
      <div className="absolute top-10 left-1/2 -translate-x-1/2 w-[700px] h-[350px] bg-[#25A69A]/10 rounded-full blur-3xl pointer-events-none -z-10" />
      <div className="absolute top-40 right-10 w-[300px] h-[300px] bg-[#D5AD68]/10 rounded-full blur-2xl pointer-events-none -z-10" />

      <div className="max-w-6xl mx-auto flex flex-col items-center text-center">
        
        {/* Badge Institucional */}
        <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-[#E8F4F2] border border-[#C5E4DD] text-[#123C4A] text-xs font-bold uppercase tracking-wider mb-5 shadow-xs">
          <span className="w-2 h-2 rounded-full bg-[#25A69A]" />
          <span>Kit Digital de Apoio à Aprendizagem • Portugal 🇵🇹</span>
        </div>

        {/* Headline Master conforme especificação */}
        <h1 className="font-heading font-black text-3xl sm:text-5xl md:text-6xl text-[#123C4A] max-w-4xl leading-[1.12] mb-6 tracking-tight">
          Mais recursos para apoiar a aprendizagem. <br className="hidden sm:inline" />
          <span className="text-[#25A69A]">Menos tempo</span> a preparar materiais.
        </h1>

        {/* Subheadline Master */}
        <p className="text-base sm:text-xl text-[#4A606A] max-w-2xl font-normal leading-relaxed mb-8">
          Descubra um kit digital com atividades, fichas e recursos de apoio educativo, organizados para facilitar a preparação das suas sessões e atividades pedagógicas.
        </p>

        {/* Mockup Real com Imagem do Material */}
        <div className="w-full max-w-4xl bg-white p-3 sm:p-5 rounded-3xl border border-[#D8E6E2] shadow-2xl mb-8 relative group">
          <div className="overflow-hidden rounded-2xl relative bg-[#F0F5F3]">
            <img
              src="/site_images/site_img_1.jpg"
              alt="Kit Psicopedagógico: material principal, cadernos de avaliação, intervenção, jogos, fichas e bónus em PDF"
              className="w-full h-auto object-cover transform group-hover:scale-[1.01] transition-transform duration-500"
              loading="eager"
            />
            {/* Tag flutuante de qualidade */}
            <div className="absolute bottom-3 right-3 sm:bottom-5 sm:right-5 bg-[#123C4A]/90 backdrop-blur-md text-white px-3.5 py-1.5 rounded-xl text-xs font-semibold shadow-lg border border-white/10 flex items-center gap-2">
              <Sparkles className="w-3.5 h-3.5 text-[#D5AD68]" />
              <span>+200 Páginas Prontas para Imprimir</span>
            </div>
          </div>
        </div>

        {/* 3 Benefícios Objetivos Conforme Especificação */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 sm:gap-4 max-w-3xl w-full mb-8 text-left">
          <div className="bg-white p-4 rounded-2xl border border-[#E2EBE8] shadow-xs flex items-start gap-3">
            <div className="w-8 h-8 rounded-xl bg-[#E8F4F2] text-[#25A69A] flex items-center justify-center shrink-0">
              <FileText className="w-4 h-4" />
            </div>
            <div>
              <h4 className="font-bold text-xs sm:text-sm text-[#182B35] leading-tight mb-1">
                Recursos Práticos em PDF
              </h4>
              <p className="text-[11px] sm:text-xs text-[#5D737E] leading-normal">
                Mais de 50 testes e fichas prontas para aplicação direta.
              </p>
            </div>
          </div>

          <div className="bg-white p-4 rounded-2xl border border-[#E2EBE8] shadow-xs flex items-start gap-3">
            <div className="w-8 h-8 rounded-xl bg-[#E8F4F2] text-[#25A69A] flex items-center justify-center shrink-0">
              <Download className="w-4 h-4" />
            </div>
            <div>
              <h4 className="font-bold text-xs sm:text-sm text-[#182B35] leading-tight mb-1">
                Acesso Imediato por E-mail
              </h4>
              <p className="text-[11px] sm:text-xs text-[#5D737E] leading-normal">
                Descarregue no seu computador ou telemóvel sem esperar.
              </p>
            </div>
          </div>

          <div className="bg-white p-4 rounded-2xl border border-[#E2EBE8] shadow-xs flex items-start gap-3">
            <div className="w-8 h-8 rounded-xl bg-[#E8F4F2] text-[#25A69A] flex items-center justify-center shrink-0">
              <ShieldCheck className="w-4 h-4" />
            </div>
            <div>
              <h4 className="font-bold text-xs sm:text-sm text-[#182B35] leading-tight mb-1">
                Pagamento Único em Euros
              </h4>
              <p className="text-[11px] sm:text-xs text-[#5D737E] leading-normal">
                Sem assinaturas ou cobranças mensais. Acesso vitalício aos ficheiros.
              </p>
            </div>
          </div>
        </div>

        {/* CTA Principal Destacado e Botão Secundário */}
        <div className="flex flex-col sm:flex-row items-center justify-center gap-3 w-full max-w-md">
          <button
            onClick={handlePrimaryClick}
            className="w-full sm:w-auto px-8 py-4 bg-[#25A69A] hover:bg-[#1E8E84] text-white font-bold text-base rounded-full shadow-lg hover:shadow-xl hover:-translate-y-0.5 transition-all duration-200 cursor-pointer flex items-center justify-center gap-2 group"
          >
            <span>Quero conhecer o Kit Completo</span>
            <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
          </button>

          <a
            href="#galeria"
            className="w-full sm:w-auto px-6 py-4 bg-transparent hover:bg-white text-[#123C4A] font-bold text-sm rounded-full border-2 border-[#123C4A] transition-all text-center"
          >
            Ver Amostras dos Materiais
          </a>
        </div>

        {/* Nota de Confiança e Transparência */}
        <div className="flex items-center gap-4 mt-6 text-xs text-[#5D737E] flex-wrap justify-center">
          <span className="flex items-center gap-1.5">
            <CheckCircle2 className="w-4 h-4 text-[#25A69A]" />
            Entrega Digital Segura
          </span>
          <span>•</span>
          <span className="flex items-center gap-1.5">
            <CheckCircle2 className="w-4 h-4 text-[#25A69A]" />
            Garantia de 7 Dias
          </span>
          <span>•</span>
          <span className="flex items-center gap-1.5">
            <CheckCircle2 className="w-4 h-4 text-[#25A69A]" />
            Formato A4 pronto a imprimir
          </span>
        </div>

      </div>
    </section>
  );
};
